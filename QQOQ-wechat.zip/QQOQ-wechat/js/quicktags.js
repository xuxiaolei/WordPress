QTags.addButton( 'smilies', '表情', "", "" );//添加表情
QTags.addButton( 'user', '用户昵称', "[用户昵称]", "" );//用户名