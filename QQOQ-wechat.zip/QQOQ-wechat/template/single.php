<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title><?php bloginfo('name') ?></title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=0" />
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo plugin_dir_url( __FILE__ ) ?>img/favicon.ico">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="apple-mobile-web-app-status-bar-style" content="black">
        <meta name="format-detection" content="telephone=no">
        <link rel="stylesheet" type="text/css" href="<?php echo plugin_dir_url( __FILE__ ) ?>css/style.css">
        <link rel="stylesheet" type="text/css" href="<?php echo plugin_dir_url( __FILE__ ) ?>css/article.css">
    </head>
    <body>
    <?php while (have_posts()) : the_post(); ?>
        <div class="rich_media">
            <div class="rich_media_inner">
                <div id="page-content">
                    <div id="img-content" class="rich_media_area_primary">
                        <h2 id="activity-name" class="rich_media_title"><?php the_title() ?></h2>
                        <div class="rich_media_meta_list">
                            <span class="rich_media_meta rich_media_meta_tag">
                                <img class="icon_meta_copyright" alt="原创" src="<?php echo plugin_dir_url( __FILE__ ) ?>img/icon_copyright.png">原创
                            </span>
                            <em class="rich_media_meta rich_media_meta_text" id="post-date"><?php the_time('Y-m-d') ?></em>
                            <a id="post-user" href="javascript:void(0);" class="rich_media_meta rich_media_meta_link rich_media_meta_nickname"><?php bloginfo('name') ?></a>
                            <span class="rich_media_meta rich_media_meta_text rich_media_meta_nickname"><?php bloginfo('name') ?></span>
                        </div>
                        <div id="media" class="rich_media_thumb_wrp">
                            <?php the_content() ?>
                        </div>
                        <div id="js_toobar" class="rich_media_tool">
                            <a id="js_view_source" class="media_tool_meta meta_primary" href="<?php the_permalink() ?>">阅读原文</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endwhile; ?>
    </body>
</html>