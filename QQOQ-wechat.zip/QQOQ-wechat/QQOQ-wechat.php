<?php  
/*
Plugin Name: QQOQ微信公众平台
Plugin URI: http://www.qqoq.net
Description: 微信公众平台插件，支持自定义回复、第三方接口等
Author: 老萨
Version: 1.0
Author URI: http://www.qqoq.net
*/
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}
require plugin_dir_path( __FILE__ ) . 'wechat.class.php';
require plugin_dir_path( __FILE__ ) . 'functions.php';

add_filter( 'plugin_action_links_QQOQ-wechat/QQOQ-wechat.php', 'add_qqoq_wechat_action_links');
function add_qqoq_wechat_action_links ( $links) {
    $links[] = '<a href="' . admin_url( 'admin.php?page=qqoq_wechat' ) . '">设置</a>';
    return $links;
}
function qqoq_optionsframework_init() {
    $option_name = 'qqoq_wechat';
    //  If user can't edit theme options, exit
    if ( !current_user_can( 'edit_plugins' ) )
        return;

    // Load translation files
    load_plugin_textdomain( 'options-framework', false, dirname( plugin_basename( __FILE__ ) ) . 'QQOQ-option/languages/' );

    // Loads the required Options Framework classes.
    require plugin_dir_path( __FILE__ ) . 'QQOQ-option/includes/class-options-framework.php';
    require plugin_dir_path( __FILE__ ) . 'QQOQ-option/includes/class-options-framework-admin.php';
    require plugin_dir_path( __FILE__ ) . 'QQOQ-option/includes/class-options-interface.php';
    require plugin_dir_path( __FILE__ ) . 'QQOQ-option/includes/class-options-media-uploader.php';
    require plugin_dir_path( __FILE__ ) . 'QQOQ-option/includes/class-options-sanitization.php';

    // Instantiate the main plugin class.
    //$options_framework = new QQOQ_Options_Framework;
    //$options_framework->init();

    // Instantiate the options page.
    $options_framework_admin = new QQOQ_Options_Framework_Admin($option_name);
    $options_framework_admin->init();

    // Instantiate the media uploader class
    $options_framework_media_uploader = new QQOQ_Options_Framework_Media_Uploader;
    $options_framework_media_uploader->init();
}
add_action( 'init', 'qqoq_optionsframework_init', 20 );
function wechat_init(){
    if(isset($_REQUEST['qqoq']) && $_REQUEST['qqoq'] == 'wechat'){
        //wechat
        $weObj = new Wechat(qqoq_wechat_options());
        $weObj->valid();//明文或兼容模式可以在接口验证通过后注释此句，但加密模式一定不能注释，否则会验证失败
        //获取菜单操作:
        //$menu = $weObj->getMenu();
        //设置菜单
        $wechat_menu = qqoq_get_option('wechat_menu','qqoq_wechat');
        $menu_event = qqoq_menu_event();
        if(is_array($wechat_menu) && !empty($wechat_menu)){
            foreach ($wechat_menu as $key => $val) {
                if(!isset($val['submenu'])){
                    $newmenu['button'][$key]['type'] = $menu_event[$val['event']]['event'];
                    $newmenu['button'][$key]['name'] = $val['name'];
                    if($menu_event[$val['event']]['event'] == 'view'){
                        $newmenu['button'][$key]['url'] = $val['url'];
                    }elseif($val['event'] == 'category'){
                        $newmenu['button'][$key]['key'] = $val['taxonomy']."_QC_".$val['category']."_QC_".$val['post_type'];
                    }elseif($val['event'] == 'service'){
                        if(empty($val['service']))
                            $newmenu['button'][$key]['key'] = "KF_RAND".rand(1000,9999);
                        else
                            $newmenu['button'][$key]['key'] = "KF_".$val['service'];
                    }else{
                        $newmenu['button'][$key]['key'] = $val['event'];
                    }
                }else{
                    $newmenu['button'][$key]['name'] = $val['name'];
                    foreach ($val['submenu'] as $k => $v) {
                        $newmenu['button'][$key]['sub_button'][$k]['type'] = $menu_event[$v['event']]['event'];
                        $newmenu['button'][$key]['sub_button'][$k]['name'] = $v['name'];
                        if($menu_event[$v['event']]['event'] == 'view'){
                            $newmenu['button'][$key]['sub_button'][$k]['url'] = $v['url'];
                        }elseif($v['event'] == 'category'){
                            $newmenu['button'][$key]['sub_button'][$k]['key'] = $v['taxonomy']."_QC_".$v['category']."_QC_".$v['post_type'];
                        }elseif($v['event'] == 'service'){
                            if(empty($v['service']))
                                $newmenu['button'][$key]['sub_button'][$k]['key'] = "KF_RAND".rand(1000,9999);
                            else
                                $newmenu['button'][$key]['sub_button'][$k]['key'] = "KF_".$v['service'];
                        }else{
                            $newmenu['button'][$key]['sub_button'][$k]['key'] = $v['event'];
                        }
                    }
                }
            }
        }
        $result = $weObj->createMenu($newmenu);
        //获取消息类型
        $type = $weObj->getRev()->getRevType();
        //获取用户ID
        $openid = $weObj->getRevFrom();
        switch($type) {
            case Wechat::MSGTYPE_TEXT:
                $weObj->text("hello, I'm wechat")->reply();
                break;
            case Wechat::MSGTYPE_EVENT:
                $event = $weObj->getRevEvent();
                if($event['event'] == 'subscribe'){//用户关注
                    //qqoq_log('用户订阅');
                    do_action('qqoq_do_event_subscribe_action',$openid);
                    $msg = apply_filters('qqoq_do_event_subscribe_filters',$openid);
                    if(isset($msg['MsgType']) && isset($msg['Content'])){
                        switch ($msg['MsgType']) {
                            case 'text':
                                $weObj->text($msg['Content'])->reply();
                                break;
                            case 'news':
                                $weObj->news($msg['Content'])->reply();
                                break;
                        }
                    }
                }
                if($event['event'] == 'LOCATION'){//关注时地理位置
                    $location = $weObj->getRevEventGeo();
                    $msg = "x:".$location['x']."\n"."y:".$location['y']."\n"."precision:".$location['precision'];
                    $weObj->text($msg)->reply();
                    //qqoq_log('用户解除订阅');
                }
                if($event['event'] == 'unsubscribe'){//解除关注
                    //qqoq_log('用户解除订阅');
                }
                if($event['event'] == 'CLICK'){//点击菜单事件
                    $EventKey = $event['key'];
                    if(strstr($EventKey,'_QC_')){//获取分组栏目
                        $msg = apply_filters('qqoq_do_event_category',$openid,$EventKey);
                    }elseif(strstr($EventKey,'KF_')){
                        $msg = apply_filters('qqoq_do_event_service',$openid,$EventKey);
                    }else{
                        $msg = apply_filters('qqoq_do_event_'.$EventKey,$openid);
                    }
                    if(isset($msg['MsgType'])){
                        switch ($msg['MsgType']) {
                            case 'text':
                                $weObj->text($msg['Content'])->reply();
                                break;
                            case 'news':
                                $weObj->news($msg['Content'])->reply();
                                break;
                            case 'service'://客服
                                $weObj->transfer_customer_service($msg['Account'])->reply();
                                break;
                            default:
                                $weObj->text('事件类型：'.$msg['MsgType'].'不存在')->reply();
                                break;
                        }
                    }else{
                        $weObj->text('内容格式不正确')->reply();
                    }
                }
                if($event['event'] == 'VIEW'){//点击菜单外链事件
                    $EventKey = $event['key'];
                    //qqoq_log("你浏览了".$EventKey."网页");
                }
                break;
            case Wechat::MSGTYPE_IMAGE:
                break;
            case Wechat::MSGTYPE_LOCATION://地理位置
                $location = $weObj->getRevGeo();
                $weObj->text($location['label'])->reply();
                break;
            default:
                $weObj->text("help info")->reply();
        }
        exit;
    }
}
add_action( 'init', 'wechat_init', 10 );
//调用自制模板
function qqoq_single_template(){
    if(is_singular() && isset($_GET['qqoq_wechat'])){
        require plugin_dir_path( __FILE__ ) . '/template/single.php';
        exit;
    }
}
add_action("wp", "qqoq_single_template", 10, 1);
function QQOQ_optionsframework_options(){
    /*菜单一*/
    $options[] = array(
        'name' => '常规设置',
        'type' => 'heading');

    $options[] = array(
        'name' => '接口URL',
        'desc' => add_query_arg( array('qqoq'=>'wechat'), home_url('') ),
        'id' => '',
        'std' => '',
        'class' => '',
        'type' => 'info'
    );
    $options[] = array(
        'name' => 'Token',
        'desc' => '可随便输入英文字母，用于此服务器跟微信服务器对接验证',
        'id' => 'token',
        'std' => wp_generate_password(5, false),
        'class' => 'mini',
        'type' => 'text'
    );
    $options[] = array(
        'name' => '调试模式',
        'desc' => '不是开发人员建议不要开启，开启后会在插件目录生成一个以log_为前缀的.txt文件',
        'id' => 'debug',
        'std' => 0,
        'type' => 'checkbox');
    $options[] = array(
        'name' => '消息加密',
        'desc' => '用于加解密收发的消息，如果勾选，下面的“加密密钥”不能为空',
        'id' => 'is_encrypt',
        'std' => 0,
        'type' => 'checkbox');
    $options[] = array(
        'name' => '加密密钥EncodingAESKey',
        'desc' => '加密密钥由43位字符组成，可随便填写（字符范围为A-Z，a-z，0-9），注：只有“消息加密”勾选了才有效',
        'id' => 'encodingaeskey',
        'std' => wp_generate_password(43, false),
        'class' => '',
        'type' => 'text'
    );
    $options[] = array(
        'name' => 'AppID',
        'desc' => '请输入在微信公众平台申请的appID',
        'id' => 'appid',
        'std' => '',
        'class' => '',
        'type' => 'text'
    );
    $options[] = array(
        'name' => 'Appsecret',
        'desc' => '请输入在微信公众平台申请的appsecret',
        'id' => 'appsecret',
        'std' => '',
        'class' => '',
        'type' => 'text'
    );
    /*菜单二*/
    $options[] = array(
        'name' => '菜单设置',
        'type' => 'heading');

    $options[] = array(
        'name' => '自定义菜单说明',
        'desc' => '<p>一、订阅号的自定义菜单需要认证后才能使用，服务号可以直接使用。</p><p>二、自定义菜单最多包括3个一级菜单，每个一级菜单最多包含5个二级菜单。一级菜单最多4个汉字或8个英文字母，二级菜单最多8个汉字或16个英文字母，多出来的部分将会以“...”代替。请注意，创建自定义菜单后，由于微信客户端缓存，需要24小时微信客户端才会展现出来。建议测试时可以尝试取消关注公众账号后再次关注，则可以看到创建后的效果。 </p><p>三、如果设置有子菜单，那么一级菜单的菜单事件将无效，只会显示菜单名称。</p>',
        'id' => '',
        'std' => '',
        'class' => '',
        'type' => 'info'
    );
    $options[] = array(
        'name' => '微信自定义菜单',
        'desc' => '',
        'id' => 'wechat_menu',
        'std' => '',
        'class' => 'qqoq_wechat_menu',
        'type' => 'multimenu',
        'options' => array(
            array(
                'name' => '[一]菜单名称',
                'id'   => 'menu_1',
            ),
            array(
                'name' => '[二]菜单名称',
                'id'   => 'menu_2',
            ),
            array(
                'name' => '[三]菜单名称',
                'id'   => 'menu_3',
            )
        )
    );

    /*菜单三*/
    $options[] = array(
        'name' => '关注回复',
        'type' => 'heading');

    $options[] = array(
        'name' => '关注回复',
        'desc' => '关注回复既是指用户关注了你的微信公众号后给用户回复的信息。',
        'id' => '',
        'std' => '',
        'class' => '',
        'type' => 'info'
    );

    //添加编辑器快捷按钮
    add_action('admin_print_scripts', 'my_quicktags');
    function my_quicktags() {
        if(isset($_GET['page']) && $_GET['page'] == 'qqoq_wechat'){
            wp_enqueue_script(
                'my_quicktags',
                plugins_url( 'QQOQ-wechat' ).'/js/quicktags.js',
                array('quicktags')
            );
        }
    };

    $wp_editor_settings = array(
        'wpautop' => true, // Default
        'textarea_rows' => 5,
        'teeny' => true,
        'tinymce' => 0,
        'quicktags'=> array('buttons' => 'link'),
        //'tinymce' => array( 'plugins' => 'wordpress' )
    );
    $options[] = array(
        'name' => '回复文本内容',
        'desc' => '注：“用户昵称”需要微信公众平台的【获取用户基本信息】权限。',
        'id' => 'text_editor',
        'type' => 'editor',
        'settings' => $wp_editor_settings );

    return $options;
}
?>