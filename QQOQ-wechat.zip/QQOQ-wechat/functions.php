<?php
$option = qqoq_get_option('','qqoq_wechat');
define('W_TOKEN',$option['token']);//token
define('W_ENCRYPT',$option['is_encrypt']);//是否加密
define('W_KEY',$option['encodingaeskey']);//加密密钥
define('W_APPID',$option['appid']);//appid
define('W_APPSECRET',$option['appsecret']);//appsecret
define('W_DEBUG',$option['debug']);//是否开启DEBUG模式
function qqoq_wechat_options(){
    $w_options = array(
        'token'=>W_TOKEN,
    );
    if(W_DEBUG){
        $w_options['debug'] = true;
        $w_options['logcallback'] = 'qqoq_log';
    }
    if(W_APPID != '' && W_APPSECRET != ''){
        $w_options['appid'] = W_APPID;
        $w_options['appsecret'] = W_APPSECRET;
    }
    if(W_ENCRYPT && W_KEY != '')
        $w_options['encodingaeskey'] = W_KEY;
    return $w_options;
}
/**
 * 生成日志
 * @param string $log 日志内容
 */
function qqoq_log($log){
    $fine_name = 'log_'.date('Ymd')."_".wp_create_nonce(home_url()).'.txt';
    file_put_contents(plugin_dir_path( __FILE__ ).$fine_name,$log."\r\n\r\n",FILE_APPEND);
}

/**
 * 获取设置参数
 * @param string $name 选项名，$option_name 选项保存key，本例为qqoq_wechat
 * @return string or array
 */
function qqoq_get_option( $name,$option_name, $default = false ) {
    $options = get_option( $option_name );

    if ( isset( $options[$name] ) ) {
        return $options[$name];
    }elseif(!isset( $options[$name] ) && $name == ''){
        return $options;
    }

    return $default;
}

/**
 * 添加菜单事件（系统默认，不要更改，如需增加请使用'qqoq_menu_event'钩子增加相应参数）
 * @return array
 */
function qqoq_menu_event(){
    $args['url'] = array(
        'name'=>'链接',
        'event'=>'view'
    );
    $args['category'] = array(
        'name'=>'文章分类',
        'event'=>'click'
    );
    $args['new'] = array(
        'name'=>'最新文章',
        'event'=>'click'
    );
    $args['service'] = array(
        'name'=>'在线客服',
        'event'=>'click'
    );
    $menu_event = apply_filters( 'qqoq_menu_event', $args);
    return $menu_event;
}

/**
 * 获取微信用户信息
 * @param string $openid
 * @return array {subscribe,openid,nickname,sex,city,province,country,language,headimgurl,subscribe_time,[unionid]}
 */
function qqoq_get_userinfo($openid){
    $weObj = new Wechat(qqoq_wechat_options());
    $user = $weObj->getUserInfo($openid);
    return $user;
}

/**
 * 处理菜单事件(最新文章)
 * @param string $openid 用户ID
 * @return array
 */
function qqoq_do_event_new($openid){
    $args['MsgType'] = 'news';
    $p = array(
        'posts_per_page' => 10
    );
    $posts = get_posts($p);
    if(!empty($posts)){
        foreach ($posts as $key => $post) {
            if (has_post_thumbnail($post->ID)) {
                $first_img = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'thumbnail');
                $first_img = $first_img[0];
            }else{
                $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i',$post->post_content, $matches);
                $first_img = $matches[1][0];
            }
            $args['Content'][$key] = array(
                'Title'        => $post->post_title,
                'Description'  => $post->post_excerpt,
                //'PicUrl'     => 'http://www.domain.com/1.jpg',
                'Url'          => qqoq_wechat_get_permalink($post->ID)
            );
            if($first_img)
                $args['Content'][$key]['PicUrl'] = $first_img;
        }
    }
    return $args;
}
add_filter('qqoq_do_event_new','qqoq_do_event_new');

/**
 * 处理客服事件
 * @param string $openid 用户ID
 * @return array
 */
function qqoq_do_event_service($openid,$EventKey){
    $args['MsgType'] = 'service';
    if(strstr($EventKey,'KF_RAND')){
        $args['Account'] = '';
    }else{
        $kf_id = explode("KF_",$EventKey);
        $kf_id = $kf_id[1];
        $weObj = new Wechat(qqoq_wechat_options());
        $kf_list = $weObj->getCustomServiceKFlist();
        if(!empty($kf_list) && isset($kf_list['kf_list'])){
            foreach ($kf_list['kf_list'] as $kf_k => $kf_v) {
                if($kf_v["kf_id"] == $kf_id){
                    $args['Account'] = $kf_v['kf_account'];
                    break;
                }
            }
        }else{
            $args['Account'] = '';
        }
    }
    return $args;
}
add_filter('qqoq_do_event_service','qqoq_do_event_service',10,2);
/**
 * 处理菜单事件(分类文章)
 * @param string $openid 用户ID，$EventKey 事件KEY
 * @return array
 */
function qqoq_do_event_category($openid,$EventKey){
    $cats = explode("_QC_",$EventKey);
    $taxonomy = $cats[0];
    $cid = $cats[1];
    $post_type = $cats[2];
    $args['MsgType'] = 'news';
    $arg = array(
        'post_type' => $post_type,
        'posts_per_page' => 10,
        'tax_query' => array(
            array(
              'taxonomy' => $taxonomy,
              'field' => 'id',
              'terms' => $cid,
            )
        )
    );
    $myposts = get_posts( $arg );
    foreach ($myposts as $key => $post) {
        if (has_post_thumbnail($post->ID)) {
            $first_img = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'thumbnail');
            $first_img = $first_img[0];
        }else{
            $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i',$post->post_content, $matches);
            $first_img = $matches[1][0];
        }
        $args['Content'][$key] = array(
            'Title'        => $post->post_title,
            'Description'  => $post->post_excerpt,
            'Url'          => qqoq_wechat_get_permalink($post->ID)
        );
        if($first_img)
            $args['Content'][$key]['PicUrl'] = $first_img;
    }
    return $args;
}
add_filter('qqoq_do_event_category','qqoq_do_event_category',10,2);

/**
 * 构造自定义模板链接
 * @param string $postid
 * @return string URL
 */
function qqoq_wechat_get_permalink($postid){
    $purl = get_permalink($postid);
    $url = add_query_arg( array('qqoq_wechat'=>'1'),$purl);
    return $url;
}

/**
 * 回复用户订阅事件
 * @param string $openid
 * @return array
 */
function qqoq_do_event_subscribe_filter($openid){
    $userinfo = qqoq_get_userinfo($openid);
    $nickname = $userinfo['nickname'];
    $con = qqoq_get_option('text_editor','qqoq_wechat');
    if(empty($con))
        return false;
    $args['Content'] = str_replace('[用户昵称]',$nickname,$con);
    $args['MsgType'] = 'text';
    return $args;
}
add_filter('qqoq_do_event_subscribe_filters','qqoq_do_event_subscribe_filter');

/**
 * 执行用户订阅事件
 * @param string $openid
 * @return none
 */
function qqoq_do_event_subscribe_action($openid){
    return ture;
}
add_action('qqoq_do_event_subscribe_action','qqoq_do_event_subscribe_action');
?>