<?php  
ini_set("display_errors", "On"); 
include('../../../wp-load.php'); 
include_once('class/Sinaconnect.class.php');
$sina = new Sinaconnect();
$token = $sina->getAccessToken();
$openid = $token->uid;
$uinfo = $sina->getUsrInfo();
if(!$openid){
	exit('<meta charset="utf-8" />ErrorCode:QQOQ0001<br/>ErrorMessage:openid is empty <a href="javascript:close();">Click to close</a><br/>Contact QQ:<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=236056471&site=qq&menu=yes">236056471</a>');
}
//头像
$img = $uinfo->avatar_large;
if(!$img)
$img = $uinfo->profile_image_url;
$userinfo = array(
    'avatar' => $img,
    'nickname' => $uinfo->screen_name
);
qqoq_connect($openid,$userinfo,'sina');
?>