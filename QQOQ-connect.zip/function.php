<?php
add_filter('get_avatar','qqoq_avatar', 1,5);
function qqoq_avatar($avatar,$id_or_email, $size, $default, $alt){
    if($id_or_email != ''){
        if(is_numeric($id_or_email)){
            $id = (int)$id_or_email;
            $username = get_user_meta( $id, 'nickname', 1 ); 
        }elseif ( is_object($id_or_email) ){
            if ( ! empty( $id_or_email->comment_type ) && ! in_array( $id_or_email->comment_type, (array) $allowed_comment_types ) )
            return false;
            if ( ! empty( $id_or_email->user_id ) ) {
                $id = (int) $id_or_email->user_id;
            }
            $username = get_user_meta( $id, 'nickname', 1 ); 
        }else{
            $email = $id_or_email;
            $user = get_user_by('email',$email);
            $id = $user->ID;
            $username = $user->user_nicename;
        }
        $qquserimg = get_user_meta($id, 'qquserimg', true);
        $sinauserimg = get_user_meta($id, 'sinauserimg', true);
        if($alt == ''){
            $alt = $username;
        }
        if($qquserimg == '' && $sinauserimg == ''){
            return $avatar;
        }elseif($qquserimg != ''){
            $avatar = '<img width="'.$size.'" height="'.$size.'" class="avatar" src="'.$qquserimg.'" alt="'.$alt.'">';
            return $avatar;
        }elseif($sinauserimg != ''){
            $avatar = '<img width="'.$size.'" height="'.$size.'" class="avatar" src="'.$sinauserimg.'" alt="'.$alt.'">';
            return $avatar;
        }
    }
    return $avatar;
}
/**
 * 创建数据库字段，在user表中增加一个`openid`和 `uid`两个字段
 * openid字段用于记录QQ返回的用户openid
 * uid用于记录新浪微博返回的用户uid
 * @author 老萨
 * @version  1.0
 */
if(!function_exists('qqoq_plugin_activation')){
	function qqoq_plugin_activation() {   
	    global $wpdb;
        // 创建openid字段(QQ)
        $var = $wpdb->query("SELECT openid FROM $wpdb->users");
        if(!$var){
            $wpdb->query("ALTER TABLE $wpdb->users ADD openid varchar(50)");
        }
        // 创建uid字段(新浪)
        $var1 = $wpdb->query("SELECT uid FROM $wpdb->users");
        if(!$var1){
         	$wpdb->query("ALTER TABLE $wpdb->users ADD uid varchar(50)");
        }
	}
}
add_action( 'activated_plugin', 'qqoq_plugin_activation' );
/**
 * QQOQ解绑
 * @param string $type 解绑类型，两个参数qq或者sina
 * @author 老萨
 * @version  1.0
 */
if(!function_exists('qqoq_jb')){
    function qqoq_jb($type){
        if(!is_user_logged_in())
            exit('<meta charset="utf-8" />ErrorCode:QQOQ0002<br/>ErrorMessage:请登录后再进行解绑。<br/>Contact QQ:<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=236056471&site=qq&menu=yes">236056471</a>');
        global $wpdb;
        $userid = get_current_user_id();
        if($type == 'qq'){
            $r = $wpdb->query("UPDATE `{$wpdb->users}` SET openid = '' WHERE ID = '{$userid}'");
            delete_user_meta($userid,'qquserimg');
        }else if($type == 'sina'){
            $r = $wpdb->query("UPDATE `{$wpdb->users}` SET uid = '' WHERE ID = '{$userid}'");
            delete_user_meta($userid,'sinauserimg');
        }
        return $r;
    }
}
/**
 * 构造登录链接
 * @author 老萨
 * @version  1.0
 * @param string $type 登录链接类型，接受4个固定参数，登陆参数为:'qq'和'sina','qqjb'和'sinajb'
 * @param boole $echo 结果是否直接输出，1（默认）输出值，0返回值
 * @return string (url)
 */
if(!function_exists('qqoq_login_url')){
	function qqoq_login_url($type,$echo=1){
		$login_url = home_url("/").'?qqoq_connect='.$type;
		if ($echo == 1)
			echo $login_url;
		else
			return $login_url;
	}
}
add_filter( 'plugin_action_links_QQOQ-connect/index.php', 'add_qqoq_connect_action_links');
function add_qqoq_connect_action_links ( $links) {
	$links[] = '<a href="' . admin_url( 'admin.php?page=qqoq_connect' ) . '">设置</a>';
	return $links;
}
add_action('admin_menu','qqoq_connect_menu');
function qqoq_connect_menu() {  
    $icon_url = plugins_url( '/img/favicon.ico', __FILE__ ); 
    add_menu_page( 'QQOQ微博QQ登录插件设置页面', 'QQOQ登录设置', 'administrator', 'qqoq_connect', 'display_qqoq_connect_menu',$icon_url); 
}

function display_qqoq_connect_menu(){
	echo '<h2>QQOQ微博和QQ登录插件设置</h2>';
	echo '<table class="form-table">';
	echo '<form method="post" action="options.php">';
	settings_fields( 'qqoq_connect');
	//QQ APPID
	echo '<tr valign="top">';
	echo '<th scope="row"><label for="qqoq_connect_qq_appid">QQ APPID:</label></th>';
	echo '<td><input type="text" class="regular-text" value="'.get_option('qqoq_connect_qq_appid').'" id="qqoq_connect_qq_appid" name="qqoq_connect_qq_appid"><p class="description">填入<a href="http://connect.qq.com" target="_blank">QQ互联</a>里申请到的APPID。</p></td>';
	echo '</tr>';
	//QQ APPKEY
	echo '<tr valign="top">';
	echo '<th scope="row"><label for="qqoq_connect_qq_appkey">QQ APPKEY:</label></th>';
	echo '<td><input type="text" class="regular-text" value="'.get_option('qqoq_connect_qq_appkey').'" id="qqoq_connect_qq_appkey" name="qqoq_connect_qq_appkey"><p class="description">填入<a href="http://connect.qq.com" target="_blank">QQ互联</a>里申请到的APPKEY。</p></td>';
	echo '</tr>';
	//sina APPKEY
	echo '<tr valign="top">';
	echo '<th scope="row"><label for="qqoq_connect_sina_appkey">新浪App Key:</label></th>';
	echo '<td><input type="text" class="regular-text" value="'.get_option('qqoq_connect_sina_appkey').'" id="qqoq_connect_sina_appkey" name="qqoq_connect_sina_appkey"><p class="description">填入<a href="http://open.weibo.com" target="_blank">新浪微博开放平台</a>里申请到的APPKEY。</p></td>';
	echo '</tr>';
	//sina App Secret
	echo '<tr valign="top">';
	echo '<th scope="row"><label for="qqoq_connect_sina_appsecret">新浪App Secret:</label></th>';
	echo '<td><input type="text" class="regular-text" value="'.get_option('qqoq_connect_sina_appsecret').'" id="qqoq_connect_sina_appsecret" name="qqoq_connect_sina_appsecret"><p class="description">填入<a href="http://open.weibo.com" target="_blank">新浪微博开放平台</a>里申请到的App Secret。</p></td>';
	echo '</tr>';
	echo '</table>';

    echo '<hr>';
    echo '<table class="form-table">';
    echo '<tr valign="top">';
    echo '<th scope="row"><label>QQ登录回调地址:</label></th>';
    echo '<td><input type="text" class="regular-text" readonly="readonly" value="'.plugins_url('qqcallback.php', __FILE__).'"><p class="description">请在<a target="_blank" href="http://connect.qq.com/manage/index">QQ互联管理中心</a>填上此回调地址</p></td>';
    echo '</tr>';
    echo '</table>';
	submit_button();
	echo '</form>';
	echo '<h2>使用说明</h2><pre>
/******************<b style="color:#e14d43">获取用户头像</b>********************/
函数：get_avatar()
参数说明：此函数为官方函数，具体参数请查阅官方相关文档<a target="_blank" href="http://codex.wordpress.org/Function_Reference/get_avatar">get_avatar()</a>

/******************* <b style="color:#e14d43">登录链接</b> *********************/
函数：qqoq_login_url($type,$echo=1)
参数说明：$type（此参数必填）为登录方类型，接受四个固定参数，登陆参数为:"qq"和"sina". 绑定参数为:"qqjd"和"sinajd"
	 $echo（此参数可选）此函数是作为返回值还是输出值，默认是输出，值为0即返回
返回格式：登录url
例子：qqoq_login_url("qq") //QQ登录链接
      qqoq_login_url("sina") //新浪微博登录链接
      qqoq_login_url("qqjd") //QQ解绑链接(用户必须登陆)
      qqoq_login_url("sinajd") //新浪微博解绑链接(用户必须登陆)

/******************* <b style="color:#e14d43">绑定(解绑)功能</b> *********************/
在 <a href="'.get_edit_user_link().'">我的个人资料</a> 这里可以进行绑定账号和解绑账号。同时里面有QQ头像和新浪头像的地址栏，
可以输入你喜欢的图片地址作为头像。头像的优先级是 QQ头像 > 新浪头像 > Gravatar头像

/******************** <b style="color:#e14d43">小工具</b> **********************/
自带登陆状态显示小工具，请到小工具里设置使用

/******************* <b style="color:#e14d43">关于插件</b> *********************/
本插件由老萨(QQ:<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=236056471&site=qq&menu=yes">236056471</a>)开发，由于时间仓促，所以你看到的这个后台非常简陋，有木有毁三观，无所谓了，能用就好。
有BUG可以联系我。
</pre>';
}
function register_qqoq_connect_setting() {
	register_setting( 'qqoq_connect', 'qqoq_connect_qq_appid');
	register_setting( 'qqoq_connect', 'qqoq_connect_qq_appkey');
	register_setting( 'qqoq_connect', 'qqoq_connect_sina_appkey');
	register_setting( 'qqoq_connect', 'qqoq_connect_sina_appsecret');
}
add_action( 'admin_init', 'register_qqoq_connect_setting' );
//自定义登录框内容
if(!function_exists('qqoq_custom_login_img')){
	function qqoq_custom_login_img() {
	    echo '<a class="qqck" style="margin-right:10px;" href="'.qqoq_login_url('qq',home_url(),0).'" title="QQ登录"><img src="'.plugins_url('img/qtn.png',__FILE__).'" alt="QQ登录"></a>';
	    echo '<a class="qqck" href="'.qqoq_login_url('sina',home_url(),0).'" title="新浪微博登录"><img alt="新浪微博登录" src="'.plugins_url('img/sinatn.png',__FILE__).'"></a>';
	}
}
add_action('login_form', 'qqoq_custom_login_img');
//增加用户信息字段
function modify_user_contact_methods( $user_contact ){
    $user_contact['qquserimg'] = 'QQ头像';
    $user_contact['sinauserimg'] = '新浪头像';
    return $user_contact;
}
add_filter('user_contactmethods', 'modify_user_contact_methods');
//小工具
class QQOQ_login_Widget extends WP_Widget { 
    function QQOQ_login_Widget() {
        $widget_ops = array('description' => 'QQOQ登陆插件小工具，可以显示用户登陆状态。');
        parent::WP_Widget(false,$name='QQOQ社会化登录',$widget_ops); 
    }
    function form($instance) {
        $defaults = array( 'title' => 'QQOQ社会化登录');  
        $instance = wp_parse_args( (array) $instance, $defaults ); ?>  
        <p>  
            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:'); ?></label>  
            <input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" class="widefat" type="text"/>  
        </p>  
    <?php 
    }
    function update($new_instance, $old_instance) {
        return $new_instance;
    }
    function widget($args, $instance) {
        $title = apply_filters('widget_title', $instance['title'] );
        
        echo $args['before_widget'];
        if ( $title ) {
            echo $args['before_title'] . $title . $args['after_title'];
        }
        include('widget.php');
        echo $args['after_widget'];
    }
}
add_action( 'widgets_init', 'QQOQ_load_widgets' );
function QQOQ_load_widgets() {  
    register_widget('QQOQ_login_Widget');  
}  
//css
add_action( 'init', 'QQOQ_css' );
function QQOQ_css(){
    wp_register_style( 'QQOQ_css', WP_PLUGIN_URL."/".dirname(plugin_basename(__FILE__)).'/widget.css' ); 
    wp_enqueue_style( 'QQOQ_css' );
    wp_enqueue_script("jquery"); 
    wp_register_script('login_script', plugins_url('login.js', __FILE__));
    wp_enqueue_script('login_script');
}
/**
 * 判断是否绑定
 * @author 老萨
 * @version  1.0
 * @param string $type 需要检查的类型，只接受两个固定参数，即:'qq'和'sina'.
 * @return boole/string 存在返回值，不存在返回false
 */
function is_QQOQ_bd($type){
    global $wpdb;
    if($type == 'qq'){
        $field = 'openid';
    }elseif ($type == 'sina'){
        $field = 'uid';
    }
    $user_ID = get_current_user_id();
    $query = "SELECT {$field} FROM `{$wpdb->users}` where ID='{$user_ID}'";
    $openid_db = $wpdb->get_var($query);
    if($openid_db)
        return $openid_db;
    else
        return false;
}
//绑定
add_action('show_user_profile','QQOQ_bd');
function QQOQ_bd() { 
?>
    <table class="form-table"><tr>
        <th scope="row"><label>QQOQ登陆绑定</label></th>
        <td>
            <?php 
                if(is_QQOQ_bd('qq')){ 
                    $qq_jburl = add_query_arg('qqoq_connect','qqjb',get_edit_user_link());
                    echo '<a title="QQ解绑" style="margin-right:10px;" href="'.$qq_jburl.'"><img src="'.plugins_url("img/qjb.png",__FILE__).'" alt="QQ解绑" /></a>';
                }else{ ?>
                <a class="qqck" href="<?php qqoq_login_url('qq') ?>" title="QQ登录绑定"><img src="<?php echo plugins_url('img/qtn.png',__FILE__);?>" alt="QQ登录绑定" /></a>
            <?php }if(is_QQOQ_bd('sina')){
                $sina_jburl = add_query_arg('qqoq_connect','sinajb',get_edit_user_link());
                    echo '<a title="新浪微博解绑" href="'.$sina_jburl.'"><img src="'.plugins_url("img/sinajb.png",__FILE__).'" alt="新浪微博解绑" /></a>';
                }else{
            ?>
            <a class="qqck" href="<?php qqoq_login_url('sina') ?>" title="新浪微博登录绑定"><img src="<?php echo plugins_url('img/sinatn.png',__FILE__);?>" alt="新浪微博登录绑定" /></a>
            <?php }?>
        </td>
    </tr></table>
<?php 
}
/* 
* QQ微博登录处理 
* $type 处理类型 qq或sina
*/
function qqoq_connect($openid,$userinfo,$type){
    global $wpdb;
    $is_login = is_user_logged_in();
    $uid = get_current_user_id();
    if(empty($openid) || empty($userinfo) || empty($type)){
        return false;
    }
    if($type == 'qq'){
        $query = "SELECT ID FROM `{$wpdb->users}` where openid='{$openid}'";
    }elseif($type == 'sina'){
        $query = "SELECT ID FROM `{$wpdb->users}` where uid='{$openid}'";
    }
    $userID = $wpdb->get_var($query);
    if($userID){//存在open id
        if(!$uid){//未登录
            $user = get_user_by( 'id', $userID );
            wp_set_current_user($userID,$user->user_login);
            wp_set_auth_cookie($userID);
            do_action('wp_login', $user->user_login);
            echo '<script type="text/javascript"> 
                    window.onunload = function(){ 
                        window.opener.location.reload(); 
                    }
                    close();
                    </script>';
            exit;
        }else{
            exit('<meta charset="utf-8" />ErrorCode:QQOQ0005<br/>ErrorMessage:当前'.$type.'已经存在,不能再绑定<a href="javascript:close();">Click to close</a><br/>Contact QQ:<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=236056471&site=qq&menu=yes">236056471</a>');
        }
    }else{//不存在open id
        if(!$uid){//未登录
            $login_name = wp_create_nonce($openid);
            $pass = wp_create_nonce(microtime());
            $username = $userinfo['nickname'];
            $http = is_ssl()?"https://":"http://";
            $userdata=array(
                'user_login' => $login_name,
                'display_name' => $username,
                'user_pass' => $pass,
                'role' => get_option('default_role'),
                'nickname' => $username,
                'first_name' => $username,
                //'user_email' => $login_name."@".str_replace($http,"",home_url()),
                'qquserimg' => $userinfo['avatar']
            );
            $user_id = wp_insert_user( $userdata );
            if ( is_wp_error( $user_id ) ) {
                exit('<meta charset="utf-8" />ErrorCode:QQOQ0005<br/>ErrorMessage:'.$user_id->get_error_message().'<a href="javascript:close();">Click to close</a><br/>Contact QQ:<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=236056471&site=qq&menu=yes">236056471</a>');
            }else{
                if($type == 'qq'){
                    $ff = $wpdb->query("UPDATE `{$wpdb->users}` SET openid = '{$openid}' WHERE ID = '$user_id'");
                }elseif ($type == 'sina') {
                    $ff = $wpdb->query("UPDATE `{$wpdb->users}` SET uid = '{$openid}' WHERE ID = '$user_id'");
                }
                if ($ff) {
                    wp_set_current_user($user_id);
                    wp_set_auth_cookie($user_id,true,false);
                    echo '<script type="text/javascript"> 
                    window.onunload = function(){ 
                        window.opener.location.reload(); 
                    }
                    close();
                    </script>';
                    exit();
                }          
            }
        }else{
            $img = $userinfo['avatar'];
            if($type == 'qq'){
                $wpdb->query("UPDATE `{$wpdb->users}` SET openid = '{$openid}' WHERE ID = '{$uid}'");
                $data = update_user_meta($uid,'qquserimg',$img);
            }elseif ($type == 'sina') {
                $wpdb->query("UPDATE `{$wpdb->users}` SET uid = '{$openid}' WHERE ID = '{$uid}'");
                $data = update_user_meta($uid,'sinauserimg',$img);
            }
            echo '<script type="text/javascript"> 
                    window.onunload = function(){ 
                        window.opener.location.reload(); 
                    }
                    close();
                    </script>';
            exit();
        }
    }
}
?>