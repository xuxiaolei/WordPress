jQuery(document).ready(function($) {
	$(".qqck").click(function(){
		var t = $(this);
		var qqoq_url = t.attr('href');
		var qqoq_iheight = 450;
		var qqoq_iwidth = 500;
		var qqoq_top = (window.screen.availHeight - qqoq_iheight) * 0.5;
		var qqoq_left = (window.screen.availWidth - qqoq_iwidth) * 0.5;
		window.open(qqoq_url,'QQOQ用户登陆','width='+qqoq_iwidth+',height='+qqoq_iheight+',top='+qqoq_top+',left='+qqoq_left+',innerHeight='+qqoq_iheight+',innerWidth='+qqoq_iwidth+',menubar=0,scrollbars=1, resizable=1,status=1,titlebar=0,toolbar=0,location=1');
		return false;
	});
});