<?php  
include('../../../wp-load.php'); 
include_once('class/Sinaconnect.class.php');
$qq = new Qqconnect();
$openid = $qq->getOpenID();
$uinfo = $qq->getUsrInfo();
if(!$openid){
	exit('<meta charset="utf-8" />ErrorCode:QQOQ0001<br/>ErrorMessage:openid is empty <a href="javascript:close();">Click to close</a><br/>Contact QQ:<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=236056471&site=qq&menu=yes">236056471</a>');
}
//头像
$img = $uinfo->figureurl_qq_2;
if(!$img)
    $img = $uinfo->figureurl_qq_1;
$userinfo = array(
    'avatar' => $img,
    'nickname' => $uinfo->nickname
);
qqoq_connect($openid,$userinfo,'qq');
?>