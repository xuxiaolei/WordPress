<?php
/*
Plugin Name: QQOQ微博QQ登录
Plugin URI: http://www.qqoq.net
Description: QQ和新浪微博登录插件
Author: 老萨
Version: 2.0
Author URI: http://www.qqoq.net
*/
session_start();
if(!function_exists('wp_get_current_user')) {
    include(ABSPATH . "wp-includes/pluggable.php"); 
}
include_once('function.php');
include_once('class/Qqconnect.class.php');
include_once('class/Sinaconnect.class.php');
function qqoq_connect_login(){
	//QQ
	if ($_GET['qqoq_connect'] == 'qq') {
		$qq = new Qqconnect();
		$qq->getAuthCode();
		exit;
	}
	//QQ解绑
	if ($_GET['qqoq_connect'] == 'qqjb') {
		qqoq_jb('qq');
	}
	//SINA
	if ($_GET['qqoq_connect'] == 'sina') {
		$sina = new Sinaconnect();
		$sina->getAuthCode();
		exit;
	}
	//SINA解绑
	if ($_GET['qqoq_connect'] == 'sinajb') {
		qqoq_jb('sina');
	}
}
add_action( 'init', 'qqoq_connect_login' );
?>