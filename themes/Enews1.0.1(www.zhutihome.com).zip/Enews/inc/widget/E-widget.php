<?php  

include('E-text.php');
include('E-list.php');
include('E-adhtml.php');
include('E-tags.php');
?>