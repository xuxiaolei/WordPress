				<footer class="footer-outer-wrapper">
					<div class="footer-widget-wrapper clearfix">
						<div class="footer-sidebar-r">
							<?php dynamic_sidebar('sidebar-footer-r'); ?>
						</div>
						<div class="footer-sidebar-l">
							<?php dynamic_sidebar('sidebar-footer-l'); ?>
						</div>
					</div>
					<!-- END .footer-widget-wrapper -->
					<div class="footer-copyright-wrapper">
						<div class="copyright">
							<?php echo wn_theme_setting('copyright');  ?>
						</div>
					</div>
					<!-- END .footer-copyright-wrapper -->
				</footer>
				<!-- END .footer-outer-wrapper -->
			</div>
			<!-- END .main-outer-wrapper -->
		</div>
		<div id="back-top">
			<i class="fa fa-angle-up"></i>
		</div>
		<?php wp_footer(); ?>
	</body>
</html>