<?php  
	//Prevent the direct loading of this file
	if( !empty($_SERVER['SCRIPT-FILENAME']) && basename($_SERVER['SCRIPT-FILENAME']) == 'comments.php') {
		die(__('You cannot access this file directly.','whatnew-theme'));
	}
	//Check if post is pwd protected
	if(post_password_required()) : ?>
		<p><?php _e('This post is password protected,please enter the password to view the comments','whatnew-theme');return; ?></p>
	<?php endif;
	?>
    <div id="comments" class="post-comments">
		<header class="comment-header clearfix">
			<h3 class="comment-title"><?php comments_number(__('暂无评论','whatnew-theme'),__('1 条评论','whatnew-theme'),__('% 条评论','whatnew-theme')); ?></h3>
		</header>
	<?php

	if(have_comments()) : ?>
        <ul class="media-list">
			
			<?php  wp_list_comments('callback=wn_comments');?>
			
		</ul>

		<?php if(get_comment_pages_count() >1 && get_option('page_comments')) : ?>
		
		<div class="comments-nav clearfix">
			
			<p class="fl"><a href=""><?php previous_comments_link(__('&larr; 较旧的评论','whatnew-theme')); ?></a></p>
			<p class="fr"><a href=""><?php next_comments_link(__('新的评论 &rarr;','whatnew-theme')); ?></a></p>
			
		</div>

		<?php endif; ?>
		<?php
		elseif (!comments_open() && !is_page() && post_type_supports(get_post_type(),'comments')) : ?>
			<p><?php _e('评论功能已关闭.','whatnew-theme'); ?></p>

		<?php endif;?>
		</ul>
	<?php
	//Display Comments Form
	comment_form();
?>
	</div>
	<!-- END .post-comments -->