<?php
global $post;
the_post();

$post_details_class = 'post-details-right';
if( !has_post_thumbnail() ) {
	$post_details_class = 'post-details-full';
}
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'single-post' ) ?>>
	<header class="single-header clearfix">
		<?php if( has_post_thumbnail() ) : ?>
		<div class="post-thumb">
			<?php the_post_thumbnail( '120x140' ) ?>
		</div>
		<?php endif; ?>

		<div class="<?php echo $post_details_class; ?>">
			<h1 class="single-title"><?php the_title(); ?></h1>
			<div class="light-post-meta">
				<span><?php printf(__( '作者: %s', 'whatnew-theme'), wn_post_author()); ?></span>
				<span><?php printf( __( '日期: %s', 'whatnew-theme'), wn_post_date()); ?></span>
				<span class="post-category"><?php printf( __( '分类: %s', 'whatnew-theme'), get_the_category_list(',')); ?></span>
				<span class="post-comments"><?php comments_popup_link( __( '暂无评论', 'whatnew-theme' ), __( '1 条评论', 'whatnew-theme' ), __( '% 条评论', 'whatnew-theme' ) ); ?></span>
			</div>
			<div class="post-utility">
				<ul id="wn-utility-<?php the_ID();?>" class="wn-utility wn-utility-default">
					<li>
						<span class="wn-views"><?php printf(__('浏览次数 <span>%s</span>','whatnew-theme'),WN_LikeRating::get_views() ) ?></span>
					</li>
					<li>
						<a class="wn-likes" href="#"><?php printf(__('喜欢 <span>%s</span>','whatnew-theme'),WN_LikeRating::get_likes() ) ?></a>
					</li>
					<li>
						<span class="wn-rates wn-rating-default">评分 <span data-rate="<?php echo WN_LikeRating::get_stars(); ?>"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span></span></span>
					</li>
				</ul>
			</div>
			<div class="post-share-tools clearfix">
	            <!-- JiaThis Button BEGIN -->
	            <div class="jiathis clearfix">
	                <a class="jiathis_button_qzone"></a>
	                <a class="jiathis_button_tsina"></a>
	                <a class="jiathis_button_tqq"></a>
	                <a class="jiathis_button_weixin"></a>
	                <a class="jiathis_button_renren"></a>
	                <a href="http://www.jiathis.com/share" class="jiathis jiathis_txt jtico jtico_jiathis" target="_blank"></a>
	            </div>
	            <script type="text/javascript" src="http://v3.jiathis.com/code/jia.js?uid=1394170583019786" charset="utf-8"></script>
	            <!-- JiaThis Button END -->
	        </div>
	        <!-- END .post-share-tools -->
			<?php  
				wn_post_edit_link();
			?>
		</div>
	</header>
	<div class="post-body clearfix">
		<?php the_content(); ?>
	</div>
	<footer class="single-footer clearfix">
		<div class="post-share-tools-bottom clearfix">
            <!-- JiaThis Button BEGIN -->
            <div class="jiathis clearfix">
                <a class="jiathis_button_qzone"></a>
                <a class="jiathis_button_tsina"></a>
                <a class="jiathis_button_tqq"></a>
                <a class="jiathis_button_weixin"></a>
                <a class="jiathis_button_renren"></a>
                <a href="http://www.jiathis.com/share" class="jiathis jiathis_txt jtico jtico_jiathis" target="_blank"></a>
            </div>
            <script type="text/javascript" src="http://v3.jiathis.com/code/jia.js?uid=1394170583019786" charset="utf-8"></script>
            <!-- JiaThis Button END -->
        </div>
        <!-- END .post-share-tools -->
		<div class="post-tags">
				<?php the_tags( __('<b>标签:</b>','whatnew-theme'), '','' ) ?>   
		</div>
		<!-- END .post-share -->
		<?php if(wn_theme_setting('author_box')) {
			wn_author_box();
		} ?>
		<?php 
		if(wn_theme_setting('related_posts')) { 
			wn_related_posts();	
		} ?>
	</footer>
</article>
<!-- END .single-post -->
<?php
// If enable comments and have one comment at least
if ( comments_open() || '0' != get_comments_number() )
    comments_template( '', true );
?>