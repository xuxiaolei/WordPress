<?php
global $post;

?>

<section id="post-search">
	<header class="box-header clearfix">
		<h2 class="box-title"><span class="bc blue"><?php _e('搜索:', 'whatnew-theme' ); ?></span><?php echo get_search_query();?></h2>
	</header>
	<div class="post-body clearfix">
		<?php if(have_posts()): while(have_posts()): the_post(); 
			
			get_template_part( 'templates/loop/classic-list', '' );
			
		endwhile;endif;
		?>
	</div>
	<nav role="navigation" id="nav-below" class="navigation-paging">
		<?php wp_pagenavi(); ?>
	</nav>
</section>
<!-- END #post-search -->