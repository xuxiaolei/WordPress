<?php  
global $post;
$review_score = wn_get_review_score();
?>

<article id="article" class="classic-list clearfix">
	<?php if(has_post_thumbnail()): ?>							
	<div class="classic-list-left">
		<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
			<?php the_post_thumbnail( '210x160' ); ?>
		</a>
		<?php if( $review_score ) : ?>
		<span class="classic-review-score"><?php echo $review_score; ?></span>
		<?php endif; ?>
	</div>
	<?php endif; ?>
	<div class="<?php if(has_post_thumbnail()){ echo 'classic-list-right'; }else{ echo 'classic-list-full';}?>">
			<h3 class="classic-list-title">
				<a href="<?php the_permalink() ?>"><?php the_title(); ?></a>
			</h3>
			
			<div class="light-post-meta">
				<span><?php printf(__( '作者: %s', 'whatnew-theme'), wn_post_author()); ?></span>
				<span><?php printf( __( '日期: %s', 'whatnew-theme'), wn_post_date()); ?></span>
				<span class="post-category"><?php printf( __( '分类: %s', 'whatnew-theme'), get_the_category_list(',')); ?></span>
				<span class="post-comments"><?php comments_popup_link( __( '暂无评论', 'whatnew-theme' ), __( '1 条评论', 'whatnew-theme' ), __( '% 条评论', 'whatnew-theme' ) ); ?></span>
			</div>
			<div class="m-post-excepert">
				<?php echo wn_get_the_excerpt('300'); ?>
			</div>
	</div>
	
</article>
<!-- End #article -->