<?php  
global $post;
$review_score = wn_get_review_score();
?>
<article id="article-<?php the_ID(); ?>" class="small-list col-sm-6 col-md-6">			
	<div class="small-list-left">
		<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
			<?php the_post_thumbnail( '120x85' ); ?>
		</a>
	</div>
	
	<div class="small-list-right">
			<h4 class="small-list-title">
				<a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php echo wn_get_the_title('80'); ?></a>
			</h4>
			
			<div class="light-post-meta">
				<span><?php printf(__( '作者: %s - %s', 'whatnew-theme'), wn_post_author(), get_the_date()); ?></span>
			</div>
			<?php if( $review_score ) : ?>
			<div class="small-list-review">
				<span class="review-score"><?php echo $review_score; ?></span>
			</div>
			<?php endif; ?>
	</div>
	
</article>
<!-- End #article -->