<?php  
global $post;
$review_score = wn_get_review_score();
?>
<article id="article-<?php the_ID(); ?>" class="col2-list col-sm-6 col-md-6 clearfix">
	<div class="cols-thumb">
		<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
			<?php the_post_thumbnail( '470x220' ); ?>
		</a>
		<?php if( $review_score ) : ?>
		<span class="classic-review-score"><?php echo $review_score; ?></span>
		<?php endif; ?>
	</div>
	<div class="cols-details">
		<div class="cols-post-meta clearfix">
			<span class="views">
				<i class="view-icon"></i><?php echo WN_LikeRating::get_views(); ?>
			</span>
			<span class="comments">
				<i class="comment-icon"></i><?php comments_number( '0', '1', '%' );?>
			</span>
			<span class="cols-cat">
				<i class="cube small red"></i>
				<?php echo get_the_category_list(','); ?>
			</span>
		</div>
		<h3 class="cols-post-title">
			<a href="<?php the_permalink() ?>"><?php the_title(); ?></a>
		</h3>
		<div class="light-post-meta clearfix">
			<span class="featured-date"><?php echo get_the_date(); ?></span>
			<span class="featured-author"><?php printf(__( '作者: %s', 'whatnew-theme'), wn_post_author()); ?></span>
			<span class="featured-category"><?php printf( __( '分类: %s', 'whatnew-theme'), get_the_category_list(',')); ?></span>
		</div>
		<div class="m-post-excepert">
			<?php echo wn_get_the_excerpt('120'); ?>
		</div>
	</div>
</article>