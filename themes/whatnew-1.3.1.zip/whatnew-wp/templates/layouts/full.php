<?php
global $post;
$custom_m_sidebar = 'sidebar-m';
$enable_featured_slider = false;

if(is_singular()) {
$custom_m_sidebar = get_post_meta( $post->ID, 'wn_m_sidebar', true );
$custom_m_sidebar = (isset($custom_m_sidebar) && !empty($custom_m_sidebar)) ? $custom_m_sidebar : 'sidebar-m';
$enable_featured_slider = get_post_meta( $post->ID, 'wn_enable_featured_slider', true );
}
?>
<div class="main-outer-wrapper clearfix">	
	<div class="content clearfix">
		<?php  
			//if page enable featured slider, show it here
			if( $enable_featured_slider ) {
				wn_featured_slider($post->ID);
			}
		?>
		<section id="articles" class="full-content-wrapper clearfix">
			<?php 
				$file = wn_get_page(); 
				get_template_part( 'templates/' . $file , '' );
			?>
		</section>
		<!-- END .l-articles-wrapper -->
	</div>
	<!-- END .content -->