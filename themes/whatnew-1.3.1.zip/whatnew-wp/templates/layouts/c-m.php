<?php
global $post;

$custom_m_sidebar = 'sidebar-m';
$enable_featured_slider = false;

if(is_singular()) {
  if(is_single() && is_active_sidebar('sidebar-single')) {
    $custom_m_sidebar = 'sidebar-single';
  }
$enable_featured_slider = get_post_meta( $post->ID, 'wn_enable_featured_slider', true );
}
?>
<div class="main-outer-wrapper clearfix"> 

  <div class="content clearfix">

    <div  class="m-articles-outer-wrapper col2-l">
      <?php  
        //if page open 640 featured slider,show it here
        if($enable_featured_slider) {
          wn_featured_slider($post->ID);
        }
      ?>
      <section id="articles" class="m-articles-wrapper">
        <?php 
          $file = wn_get_page(); 
          get_template_part( 'templates/' . $file , '' );
        ?>
      </section>
      <!-- END .m-articles-wrapper -->
    </div>
    <!-- END .m-articles-outer-wrapper -->
  
    <aside class="m-sidebar-wrapper col2-r">
      <?php dynamic_sidebar( $custom_m_sidebar ); ?>
    </aside>
    <!-- END .s-sidebar-wrapper -->

  </div>
  <!-- END .content -->