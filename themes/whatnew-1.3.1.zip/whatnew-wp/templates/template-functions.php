<?php

/**
 * WARNING! DO NOT EDIT THIS FUNCTION!
 *
 * Get page custom layout,$default is 'c-s-m'
 * 'c-s-m':c->content,s->small sidebar,m->medium sidebar
 *
 * This function will check layout again,
 * in case you guys edit some code i have
 * waring that can not be edited. XD
 * 
 */
function wn_get_layout( $layout = 'c-m' ) {

	$file    = wn_theme_setting( 'default_layout' );	
	$layouts = array( 'c-m', 'full');
	 
	if(in_array( $layout, $layouts) ) {
    	$file = $layout ;
 	}

	return $file;
}

/**
 * Get title in <head>
 */
function wn_title() {

    global $page;
    wp_title( '|', true, 'right' );
    // Add the blog name.
    bloginfo( 'name' );

    // Add the blog description for the home/front page.
    $site_description = get_bloginfo( 'description', 'display' );

    if ( $site_description && ( is_home() || is_front_page() ) ) :
    	echo " | $site_description";
	endif;

}

/**
 * Get theme option
 */
function wn_theme_setting( $option ) {

	global $NHP_Options;
	$option = $NHP_Options->get( $option );   
   	return $option;
}
/**
 * Favicon
 */
function wn_favicon() {
  $favicon = wn_theme_setting( 'favicon' );
  
  if(empty($favicon)){
    $favicon = THEMEURL.'/img/favicon.ico';
  }
  return $favicon;
}
/**
 * Header Logo
 */
function wn_header_logo() {
  $logo = wn_theme_setting( 'header-logo' );
  
  if(empty($logo)){
    $logo = THEMEURL.'/img/header-logo.png';
  }
  return $logo;
}
/**
 * Footer Logo
 */
function wn_footer_logo() {
  $logo = wn_theme_setting( 'footer-logo' );
  
  if(empty($logo)){
    $logo = THEMEURL.'/img/footer-logo.png';
  }
  return $logo;
}
/**
 * Footer CopyRight Info
 */
function wn_copyright() {
  $copyright = wn_theme_setting( 'copyright' );
  if(empty($copyright)){
    $copyright = 'COPYRIGHT &copy; 2013 20THEME | POWERED BY WORDPRESS | DESIGNED BY MOYUS';
  }
  return $copyright;
}

/**
 * Main Content Page Load
 */
function wn_get_page() {

  $file = 'home';
  if(is_singular()) {
    if(is_page()) {
      $file = 'page';
    }else {
      $file = 'single';
    }
  }elseif ( is_category() || is_archive() || is_date() || is_day() || is_month() || is_year() || is_tag() ) {
    $file = 'archive';
  }elseif( is_search() ) {
    $file = 'search';
  }elseif( is_404() ) {
    $file = '404';
  }

  return $file;

}
/**
 * get post date
 */
function wn_post_date() {
  global $post;
  $date = get_the_date();
  $title = get_the_time();
  $url = get_permalink();
  $html = '<a href="'. $url .'" title="' . $title . '" >' . $date . '</a>';
  return $html;
}
/**
 * get post author
 */
function wn_post_author() {
  global $post;
  $url =  get_author_posts_url(get_the_author_meta('ID'));
  $title = get_the_author();
  $author = get_the_author();
  $html = "<a href='{$url}' title='{$title}'>{$author}</a>";

  return $html;
}

/**
 * Page Link
 */
function wn_page_link() {
	$args = array(
		'before'           => '<p>',
		'after'            => __('页','whatenw-theme').'</p>',
		'link_before'      => '',
		'link_after'       => '',
		'next_or_number'   => 'number',
		'nextpagelink'     => __('下一页','whatenw-theme'),
		'previouspagelink' => __('上一页','whatenw-theme'),
		'pagelink'         => '%',
		'echo'             => 1
	);
	wp_link_pages($args);
}

/**
 * Custom Post Excerpt
 */
 function wn_get_the_title($limit) {
  global $post;
  $title = sysSubStr( get_the_title(), $limit, true );
  return $title;
}
function wn_get_the_excerpt($limit) {
  global $post;
  $excerpt = sysSubStr( get_the_excerpt(), $limit, true );
  return $excerpt;
}
function wn_get_the_content($limit) {
  global $post;
  $content = sysSubStr( get_the_content(), $limit, true );
  return $content;
}
// set the excerpt length
function custom_excerpt_length(){
  return 100;
 }
add_filter( 'excerpt_length', 'custom_excerpt_length' );
// set the excerpt more text
function custom_excerpt_more( $more ) {
  return '...';
}
add_filter( 'excerpt_more', 'custom_excerpt_more' );

function sysSubStr($string,$length,$append = false) 
{ 
    if(strlen($string) <= $length ) 
    { 
        return $string; 
    } 
    else 
    { 
        $i = 0; 
        while ($i < $length) 
        { 
            $stringTMP = substr($string,$i,1); 
            if ( ord($stringTMP) >=224 ) 
            { 
                $stringTMP = substr($string,$i,3); 
                $i = $i + 3; 
            } 
            elseif( ord($stringTMP) >=192 ) 
            { 
                $stringTMP = substr($string,$i,2); 
                $i = $i + 2; 
            } 
            else 
            { 
                $i = $i + 1; 
            } 
            $stringLast[] = $stringTMP; 
        } 
        $stringLast = implode("",$stringLast); 
        if($append) 
        { 
            $stringLast .= "..."; 
        } 
        return $stringLast; 
    } 
} 

/**
 * Post Edit Link
 */
function wn_post_edit_link() {
  global $post;
  if(get_current_user_id() == get_the_author_meta('ID') || is_user_admin()) {
    ?>
    <span class="post-edit">
      <a href="<?php echo get_edit_post_link(); ?>" ><?php _e( '[Edit]','whatnew-theme' ); ?></a>
    </span>
    <?php
  }
}
/**
 * Review Box
 */
function wn_review_box() {
  global $post;
  $total = $n = 0;
  $values = get_post_meta( $post->ID, 'wn_page_review', true );
  if( $values['enable'] && !empty($values['ratting_data']['label']) ) {
  
    if(empty($values['postion'])){
    	$values['postion'] ='tl';
    }
       
    $box_title = (isset($values['title'])) ?  esc_attr($values['title']) : __('Review Overview','whatnew-theme');
	$score_label = (isset($values['score_label'])) ? esc_attr($values['score_label']) : __('Total Score', 'whatnew-theme');
	
	$html = $review = '';
	$total = $n = 0;
	
    foreach($values['ratting_data']['label']  as $i => $lable) {
		$score  = floatval($values['ratting_data']['score'][$i]);
		if($lable==''  &&  $score<=0){
			continue;
		}
		$total += $score;
		$n+=1;
		$review .='<li>'.
		            '<div class="review-criteria-score clearfix">'.
		              '<span class="left">'.esc_attr($lable).'</span>'.
		              '<span class="right">'.esc_attr($score).'</span>'.
		            '</div>'.
		            '<div class="review-criteria-bar-container">'.
		              '<div class="review-criteria-bar" style="width:'.esc_attr($score).'%"></div>'.
		            '</div>'.
		          '</li>';
    } 
    if($n == 0) $n = 1;
    $html .= '<div id="review-box" class="'.$values['postion'].'">'.
      			'<h5>'.$box_title.'</h5>'.
	  			'<ul>'.$review.'</ul>'.
	  			'<div class="review-total-score clearfix">'.
	  				'<span class="left align-right">'.$score_label.'</span>'.
	  				'<span class="right review-total-score-box type-percent">'.round(($total/$n),1).'</span>'.
	  			'</div>'.
	  		 '</div><!-- END #review-box -->';
	  		 
	 return $html;
    
  }
}

/**
 * Get Review Score
 */
function wn_get_review_score($post_id = '') {
	global $post;
	if(empty($post_id)) {
		$post_id = $post->ID;
	}
	$values = get_post_meta( $post_id, 'wn_page_review', true );
	if( isset($values['enable']) && $values['enable'] ) {
		$total = array_sum($values['ratting_data']['score']);
		$num = count($values['ratting_data']['score']);
		if($num > 1 ) {
			$num-=1;
		}
		$score = round(($total/$num),1);
		return $score;
	}else {
		return 0;
	}
	
}

function wn_add_review_box($content) {
  global $post;
  if(!is_single()) {
    return $content;
  } 
  $data = get_post_meta($post->ID,'wn_page_review',true);
  if(!isset($data) || !isset($data['enable']) || $data['enable']!=1 ){  
    return $content;
  }
  
  $box_content = wn_review_box();
  if(!isset($data['postion'])){
    $data['postion'] ='';
  }
  switch(strtolower($data['postion'])) {
    case 'bottom':
      $content = $content.$box_content;
	  break;
    default:
      $content = $box_content.$content;
      break;
  }

  return $content;
}
add_filter('the_content','wn_add_review_box',99,1);

/**
 * Page Featured Slider
 */
function wn_featured_slider( $post_id ) {
	
  
  //$args['cats'] = get_post_meta( $post_id, 'wn_featured_slider_cats', false );
  $args['posts_per_page'] = get_post_meta( $post_id, 'wn_featured_slider_num', true );
  $args['order'] = get_post_meta( $post_id, 'wn_featured_slider_order', true );
  $args['orderby'] = get_post_meta( $post_id, 'wn_featured_slider_orderby', true );
  $args['post__not_in'] = get_post_meta( $post_id, 'wn_featured_slider_exclude', false );
  
  $args['cat'] = '';
  $cats = rwmb_meta( 'wn_featured_slider_cats', 'type=taxonomy&taxonomy=category', $post_id);
  foreach($cats as $cat) {
	  $args['cat'].=intval($cat->term_id).',';
  }
  
  array_merge( array(
    'post_type' => 'post',
    'cat' => '',
    'posts_per_page'=> 6,
    'post__not_in'=>array(),
    'orderby'=>'ID',
    'order'=>'DESC',
  ), $args);
  
  // The Query
  global $post;
  $the_query = new WP_Query( $args );
  // The Loop
  $temp_post = $post;//temp global $post fore later recover

  if ( $the_query->have_posts() ) : ?>
  <section class="wn-content-top">
  <div class="featured">
    <div id="featured-slider-<?php echo $post_id; ?>" class="featured-slider">
      <ul class="slides">
  <?php
    while ( $the_query->have_posts() ) : $the_query->the_post();
      setup_postdata($post);
      ?>
        <li>
          <figure class="featured-img">
           <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"> <?php the_post_thumbnail( '600x250'); ?></a>
          </figure>
          <div class="featured-post-details-wrapper">
            <div class="featured-post-details clearfix">
              <h3 class="featured-post-title">
                <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php echo wn_get_the_title('80'); ?></a>
              </h3>
              <div class="featured-post-meta clearfix">
                <span class="featured-date"><?php echo get_the_date(); ?></span>
                <span class="featured-author"><?php printf(__( '作者: %s', 'whatnew-theme'), wn_post_author()); ?></span>
                <span class="featured-category"><?php printf( __( '分类: %s', 'whatnew-theme'), get_the_category_list(',')); ?></span>
              </div>
              <span class="featured-post-divider"></span>
              <div class="featured-post-excepert">
                <?php echo wn_get_the_excerpt('150'); ?>
              </div>
            </div>
          </div>
        </li>
      <?php
    endwhile;
  ?>
      </ul>
    </div>
    <div class="featured-slider-nav"></div>
    <script type="text/javascript">
      jQuery(document).ready( function($) {
        $('#featured-slider-<?php echo $post_id; ?>').flexslider({
          animation: "slide",
          easing:"swing",
          animationSpeed:600,
          slideshowSpeed:6000,
          useCSS:false,
          controlsContainer: ".featured-slider-nav",
          selector: ".slides > li",
          animationLoop: true,
          controlNav: false,
          directionNav: true,
        });
      });
    </script>
  </div>
  </section>
  <!-- END .wn-content-top -->
  <?php
  endif;

  // Restore original Post Data
  wp_reset_postdata();wp_reset_query();
  $post = $temp_post;
}

/**
 * Single Post Author Box
 */
function wn_author_box() {
	global $post;
	?>
	<div class="author-box">
		<header class="box-header clearfix">
		<h4 class="box-title"><?php _e( '关于作者', 'whatnew-theme' ); ?></h4>
		</header>
		<div class="author-body clearfix">
			<div class="author-avatar">
				<?php echo get_avatar( get_the_author_meta( 'user_email' ), '128' ) ?>
			</div>
			<div class="author-details-right">
				<h4 class="author-name"><a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>" title="<?php printf(__('View all posts by %s', 'whatnew-theme'), get_the_author()); ?>"><?php the_author(); ?></a></h4>
				<div class="author-desc">
					<?php the_author_meta( 'description' ); ?>
				</div>
			</div>
		</div>
	</div>
	<!-- END .author-box -->
	<?php
}
/**
 * Single Post Related Posts
 */
function wn_related_posts() {
	global $post;
	$temp_post = $post;
	$tags = array();
	$post_tags = wp_get_post_tags( $post->ID );
	
	if ( $post_tags ) {
		foreach ( $post_tags as $tag )
			$tags[] = $tag->term_id;
	}
	
	$args = array(
		'tag__in' 				=> $tags,
		'post__not_in' 			=> array( $post->ID ),
		'posts_per_page'		=> 4,
		'orderby' 				=> 'id',
		'ignore_sticky_posts'	=> 1
	);
	
	$the_query = new WP_Query($args);
	
	?>
	<div class="related-box">
		<header class="box-header clearfix">
			<h4 class="box-title"><?php _e('猜你喜欢', 'whatnew-theme'); ?></h4>
		</header>
		<div class="related-body clearfix">
			<div class="wn-grid">
			<?php
				if($the_query->have_posts()): while($the_query->have_posts()): $the_query->the_post();
					setup_postdata($post);
			?>
				<article class="related-item span3">
					<?php if(has_post_thumbnail()): ?>
					<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
						<?php the_post_thumbnail('210x140'); ?>
					</a>
					<?php endif; ?>
					<div class="entry-content">
						<h5 class="item-title">
							<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php echo wn_get_the_title('80'); ?></a>
						</h5>
						<div class="light-post-meta">
							<span><?php printf(__( '%s - %s', 'whatnew-theme'), wn_post_author(), get_the_date()); ?></span>
						</div>
					</div>
				</article>
			<?php
				endwhile;endif;wp_reset_postdata();wp_reset_query();
				$post = $temp_post;
			?>
			</div>
		</div>
	</div>
	<!-- END .related-box -->
	<?php
}

/**
 * Edit the_content link mockup
 */
/*
//this is ver 1.0 try to use RegEXR,but it's fucking complicated,so i give up :(
function wn_link_mockup($content) {
  if(!is_single()) {
    return $content;
  }
  $replace = array();
  $pats    = array();

  preg_match_all('/<a.*?>(.*?)<\/a>/', $content, $matches);
  foreach($matches[1] as $key=>$value) {
    $pats[] = "/>{$value}<\/a>/";
    $replace[] = "><span data-hover='{$value}'>{$value}</span></a>";
  }
  $content = preg_replace($pats,$replace,$content);
  return $content;
}
add_filter('the_content','wn_link_mockup',99,1);
*/
//this is ver 1.1
function wn_link_mockup( $content ) {
  
    if(!is_single()) {
        return $content;
    }
    $dom = new DOMDocument;
    
    $dom->loadHTML('<meta http-equiv="content-type" content="text/html; charset=utf-8">'.$content);
    foreach ($dom->getElementsByTagName('a') as $node) {
      //check if link value is pure text
      if($node->hasChildNodes()) {
        $innerHTML= ''; 
        $children = $node->childNodes; 
        foreach ($children as $child) { 
            $innerHTML .= $child->ownerDocument->saveXML( $child ); 
        }
        if($node->nodeValue != $innerHTML) {
          continue;
        }
      }
      //add 'roll-link' class
      $class = $node->getAttribute( 'class' );
      $class_array = array();
      $class_array = explode(',',$class);
      if(!in_array( $class_array, array('roll-link'))) {
        $class .= ' roll-link';
        $node->setAttribute( 'class',$class );
      }
      //add '<span>' tags
      $span = $node->getElementsByTagName('span')->item(0);
      if( !empty($span) && !$span->hasAttribute( 'data-hover' )) {
        $span->setAttribute('data-hover',$node->nodeValue);
      }
      if( empty($span) ) {
        $span = $dom->createElement('span',$node->nodeValue);
        $span->setAttribute('data-hover',$node->nodeValue);
        $node->nodeValue = '';
        $node->appendChild($span);
      }
    }
  $content = substr($dom->saveXML($dom->getElementsByTagName('body')->item(0)),6,-7);
  
    return $content;
}
//add_filter('the_content','wn_link_mockup',9,1);


/**
 * Change avatar class
 */
function change_avatar_css($class) {
$class = str_replace("class='avatar avatar-128 photo", "class='uk-comment-avatar", $class) ;
return $class;
}
add_filter('get_avatar','change_avatar_css');
/**
 * Post Comments
 * @param  string $comment    
 * @param  string $args     
 * @param  string $depth     
 * @return string           
 */
function wn_comments( $comment , $args , $depth ) {

    $GLOBALS['comment'] = $comment;
    
    ?>
    <!-- commment -->
    <li class="media">
    	<?php 
          $avatar_size = 64;
        ?>
    	<div class="pull-left">
    		<div class="media-object comment-avatar">
    			<?php echo get_avatar($comment,$avatar_size); ?>
    		</div>
    	</div>
    	<div class="media-body">
      		<h4 class="media-heading"><?php comment_author(); ?></h4>
      		<div class="comment-meta"><?php printf( __('%s at %s', 'whatnew-theme'), get_comment_date(), get_comment_time() ); ?></div>
      		<div class="comment-reply">
	          <?php comment_reply_link(array_merge($args,array('depth' => $depth, 'max_depth' => $args['max_depth']))); ?><span>&darr;</span>       
	        </div>
      		<p>
	      		<?php if ($comment->comment_approved == '0') : ?>
	            <div class="alert alert-info"><?php _e('你的评论正在等待审核.','whatnew-framework');?></div>
	        	<?php endif; ?>
	          	<?php comment_text(); ?>
          	</p>
    	</div>
    </li>
    <!-- End commment -->
    <?php
}

function wn_comment_form($defaults) {
    $defaults['comment_notes_before'] = '';
    $defaults['comment_notes_after'] = '';
    $defaults['id_form'] = 'form';
    $defaults['comment_field'] = '<div class="form-group">
									<label for="comment">评论</label>
									<textarea placeholder="评论内容.." required name="comment" id="comment" class="form-control form-message" rows="6"></textarea>
								  </div>';
    return $defaults;
}
add_filter('comment_form_defaults','wn_comment_form');

function wn_comment_fields() {
    $commenter = wp_get_current_commenter();
    $req       = get_option('require_name_email');
    $aria_req  = ($req ? "aria-required='true'" : ' ');
    
    $fields = array(
        'author' => '<div class="form-group">
        				<label for="author">姓名</label>
        				<input type="text" id="author" placeholder="请输入姓名" name="author" value="' . esc_attr($commenter['comment_author']) . '" '.$aria_req .'class="form-control" />
        			</div>',
        'email'  => '<div class="form-group">
        				<label for="email">Email</label>
        				<input type="text" id="email" placeholder="请输入Email地址" name="email" value="' . esc_attr($commenter['comment_author_email']) . '" '.$aria_req .' class="form-control" />
        			</div>',
        'url'    => '<div class="form-group">
        				<label for="url">网站</label>
        				<input type="text"id="url" placeholder="请输入你的网站" name="url" value="' . esc_attr($commenter['comment_author_url']) . '" '.$aria_req .' class="form-control" />
        			</div>'
    );
    
    return $fields;
}
add_filter('comment_form_default_fields','wn_comment_fields');

/**
 * Custom Background
 */
function wn_custom_bg() {

    if(wn_theme_setting('background') == 'fullbg') { 
	    
	    wp_enqueue_script( 'backstretch', THEMEURL . '/js/jquery.backstretch.min.js', array('jquery'), false, true );
	    
    ?>
            <script type="text/javascript">
                jQuery(document).ready(function($) {
                    $.backstretch("<?php echo wn_theme_setting('bgimg'); ?>");
                });
            </script>
        <?php }

    if(wn_theme_setting('background') == 'patternbg') { ?>
            <style type="text/css">
                    body {
                        background-image: url('<?php echo wn_theme_setting('bgimg'); ?>');
                        background-position: <?php echo wn_theme_setting('bgpos'); ?>;
                        background-repeat: <?php echo wn_theme_setting('bgrepeat'); ?>;
                    }
                    
                </style>
               <?php }

    if(wn_theme_setting('background') == 'custom') { ?>
           <style type="text/css">
               body { background-color: <?php echo wn_theme_setting('bgcolor'); ?>; }
            </style>
    <?php }
    
}

//add_action('wp_head', 'wn_custom_bg',99);

/**
 * Tracking Code before </head>
 */
function wn_tracking_head() {
	$code = wn_theme_setting( 'head_js' );
	if(!empty($code)) {
		?>
		<script type="text/javascript">
			<?php echo $code; ?>
		</script>
		<?php
	}
}
add_action('wp_head', 'wn_tracking_head',99);

/**
 * Tracking Code before </body>
 */
function wn_tracking_body() {
	$code = wn_theme_setting( 'body_js' );
	if(!empty($code)) {
		?>
		<script type="text/javascript">
			<?php echo $code; ?>
		</script>
		<?php
	}
}
add_action('wp_footer', 'wn_tracking_body',99);

/**
 * Some custom hooks
 */
add_action( 'wn_before_post_content', 'wn_before_post_content' );
add_action( 'wn_after_post_content', 'wn_after_post_content' );