<?php
global $post;
$display_style = wn_theme_setting('archive_style');  
?>

<section id="post-search">
	<header class="box-header clearfix">
		<?php if (is_category()) { ?>
        <?php $category = get_category( get_query_var('cat') ); ?>
            <h2 class="box-title"><?php printf(__("分类: %s", 'whatnew-theme'), single_cat_title('', false)); ?></h2>
        <?php } elseif( is_tag() ) { ?>
        	 <h2 class="box-title"><?php printf( __("标签: %s", 'whatnew-theme'), single_tag_title('', false) ); ?></h2>
   		<?php } elseif (is_day()) { ?>
   			<h2 class="box-title"><?php _e('归档', 'whatnew-theme') ?> <?php the_time('F jS, Y'); ?></h2>
         <?php } elseif (is_month()) { ?>
            <h2 class="box-title"><?php _e('归档', 'whatnew-theme') ?> <?php the_time('F, Y'); ?></h2>
        <?php } elseif (is_year()) { ?>
            <h2 class="box-title"><?php _e('归档', 'whatnew-theme') ?> <?php the_time('Y'); ?></h2>
		<?php } elseif (is_author()) { ?>
			<?php global $author; $userdata = get_userdata($author); ?>
			<div class="author-box">
				<div class="author-body clearfix">
					<div class="author-avatar">
						<?php echo get_avatar( $userdata->user_email, '128' ) ?>
					</div>
					<div class="author-details-right">
						<h4 class="author-name"><a href="<?php echo get_author_posts_url($userdata->ID); ?>" title="<?php printf(__('查看 %s 的所有文章', 'whatnew-theme'), $userdata->display_name); ?>"><?php echo $userdata->display_name; ?></a></h4>
						<div class="author-desc">
							<?php echo $userdata->description; ?>
						</div>
					</div>
				</div>
			</div>
			<!-- END .author-box -->
		<?php } else { ?>
			<h2 class="box-title"><?php _e('归档', 'whatnew-theme');?></h2>
        <?php } ?>
	</header>
	<div class="post-body clearfix">
		<?php if(in_array($display_style, array('col2-list','col3-list','small-list'))){ echo '<div class="wn-grid">'; } ?>
			<?php if(have_posts()): while(have_posts()): the_post(); 
				
				get_template_part( 'templates/loop/'.$display_style, '' );
				
			endwhile;endif;
			?>
		<?php if(in_array($display_style, array('col2-list','col3-list','small-list'))){ echo '</div>'; } ?>
	</div>
	<nav role="navigation" id="nav-below" class="navigation-paging">
		<?php wp_pagenavi(); ?>
	</nav>
</section>
<!-- END #post-search -->