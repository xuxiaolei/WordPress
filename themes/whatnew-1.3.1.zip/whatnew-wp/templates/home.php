<article id="post-home" class="single-post">
	<div class="post-body clearfix">
		<?php do_shortcode( '[insert_posts show_title="true" title="最新文章" sub_title="Top News" show_paging="true"]' ); ?>
	</div>
</article>
<!-- END .single-post -->