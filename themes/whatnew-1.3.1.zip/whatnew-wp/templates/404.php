<article id="page-404" class="single-post">
	<div class="post-body clearfix">
		<div class="center-content">
			<img class="center" src="<?php echo get_template_directory_uri().'/img/404.png' ?> " >
			<p>
				<?php _e('<h2>Oops, 页面没找到.</h2>','whatnew-theme'); ?>
			</p>
		</div>
	</div>
</article>
<!-- END .single-post -->