<?php
global $post;
the_post();
$enable_title = get_post_meta( $post->ID, 'wn_enable_page_title', true );
$enable_custom_title = get_post_meta( $post->ID, 'wn_enable_custom_page_title', true );
$custom_title = get_post_meta( $post->ID, 'wn_custom_page_title', true );
$bg_color = get_post_meta( $post->ID, 'wn_custom_page_title_bg', true );
$cusom_sub_title = get_post_meta( $post->ID, 'wn_custom_page_sub_title', true );
?>

<article id="post-<?php the_ID(); ?>" class="<?php post_class('single-post'); ?>">
	<header class="single-header clearfix">
		<div class="post-details-full">
			<?php if($enable_title && !$enable_custom_title) { ?>
			<h1 class="single-title"><?php the_title(); ?></h1>
			<?php 
			} 
			if($enable_custom_title) { ?>
			<header class="box-header clearfix">
				<h2 class="box-title"><span class="bc" style="background:<?php echo $bg_color; ?>"><?php echo $custom_title; ?></span><?php echo $cusom_sub_title; ?></h2>
			</header>
			<?php
			}
			?>
		</div>
	</header>
	<div class="post-body clearfix">
		<?php the_content(); ?>
	</div>
	<footer class="single-footer clearfix">
	</footer>
</article>
<!-- END .single-post -->