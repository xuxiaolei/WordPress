(function($) {
	"use strict";
	//subMenu
	jQuery('#primary-menu').superfish({
		 hoverClass:   'hasSubMenu',  
		 delay:         200,
	});
	
	//Responsive navigation
	$('#menu-trigger').sidr({
		name: 'sidr-main',
		source: '#secondary'
    });
    
	/* show search form */
	var cform = jQuery('.nav-search-wrapper').find('.sb-search');
	
    jQuery('.sb-icon-search').click(function () {

        jQuery(this).closest('div.nav-search-wrapper').removeClass('active');

        jQuery(cform).animate({
        	opacity: "toggle",
            height: "toggle"
        }, 400, function () {
            // Animation complete.

            jQuery(this).closest('div.nav-search-wrapper').toggleClass('active');
        });

        return false;
    });
    
    // hide #back-top first
  	$("#back-top").hide();
  
  	// fade in #back-top
  	$(function () {
   	 $(window).scroll(function () {
      	if ($(this).scrollTop() > 200) {
       	 $('#back-top').fadeIn();
     	} else {
       	 $('#back-top').fadeOut();
      	}
    });

    // scroll body to 0px on click
    $('#back-top').click(function () {
      $('body,html').animate({
        scrollTop: 0
      }, 400);
      return false;
    });
  });
})(jQuery);