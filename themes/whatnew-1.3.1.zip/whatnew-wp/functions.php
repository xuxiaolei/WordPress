<?php

#-----------------------------------------------------------------
# Define Variables
#-----------------------------------------------------------------
define( 'THEMEDIR', get_template_directory() );
define( 'THEMEURL', get_template_directory_uri() );
define( 'LIB_DIR', THEMEDIR . '/lib' );
define( 'LIB_URL', THEMEURL . '/lib' );
define( 'IMGURL', THEMEURL . '/img' );

#-----------------------------------------------------------------
# Require Liberary
#-----------------------------------------------------------------
include_once( 'templates/template-functions.php' );
require_once( LIB_DIR . '/load.php' );
#-----------------------------------------------------------------
# Basic Theme Functions
#-----------------------------------------------------------------
/**
 *Post Thumbnails Support
 */
add_theme_support( 'automatic-feed-links' );
add_theme_support( 'post-thumbnails' );
add_theme_support( 'custom-background' );
set_post_thumbnail_size( 325, 225, true );
add_image_size( '80', 80, 80, true );
add_image_size( '100x60', 100, 60, true );
add_image_size( '120x140', 120, 140, true );
add_image_size( '120x85', 120, 85, true );
add_image_size( '210x160', 210, 160, true );
add_image_size( '210x140', 210, 140, true );
add_image_size( '280x180', 280, 180, true );
add_image_size( '280x100', 280, 100, true );
add_image_size( '360x220', 360, 220, true );
add_image_size( '470x220', 470, 220, true );
add_image_size( '600x250', 600, 250, true );

if ( ! isset( $content_width ) ) {
	$content_width = 970;
}
/**
 * This theme uses wp_nav_menu() in one location.
 */
register_nav_menus( array(
	'primary' => __( 'Primary Menu', 'whatnew-theme' ),
) );

//global $locale;
$locale = get_locale();
load_theme_textdomain( 'whatnew-theme', get_template_directory(). '/lang' );
/**
 *Script Enqueue
 */
function wn_enqueue_custom_scripts() {
	
	wp_enqueue_style( 'bootstrap', THEMEURL . '/css/bootstrap.css' );
	wp_enqueue_style( 'font-awesome', THEMEURL . '/css/font-awesome.css' );
	wp_enqueue_style( 'sidr-dark', THEMEURL . '/css/jquery.sidr.dark.css' );
	wp_enqueue_style( 'grid', THEMEURL . '/css/grid.css' );
	wp_enqueue_style( 'style', get_stylesheet_uri() );
	
	wp_enqueue_script( 'jquery' );
	wp_enqueue_script( 'bootstrap-js', THEMEURL . '/js/bootstrap.min.js', array('jquery'), false, true );
	wp_enqueue_script( 'wn-hoverIntent', THEMEURL . '/js/hoverIntent.js', array('jquery'), false, true );
	wp_enqueue_script( 'flexslider', THEMEURL . '/js/jquery.flexslider.js', array('jquery'));
	wp_enqueue_script( 'carouFredSel', THEMEURL . '/js/jquery.carouFredSel.js', array('jquery'));
	wp_enqueue_script( 'superfish', THEMEURL . '/js/superfish.js', array('jquery'), false, true);
	wp_enqueue_script( 'sidr', THEMEURL . '/js/jquery.sidr.min.js', array('jquery'));
	wp_enqueue_script( 'site', THEMEURL . '/js/site.js', array('jquery'), false, true);
	

	if ( is_singular() && comments_open() ) {
		wp_enqueue_script( 'comment-reply' );
	}
		
}
add_action('wp_enqueue_scripts','wn_enqueue_custom_scripts');