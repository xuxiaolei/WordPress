<?php
#-----------------------------------------------------------------
# Define variables
#-----------------------------------------------------------------
define( 'RWMB_URL', LIB_URL . '/meta-box/meta-box/' );
define( 'RWMB_DIR', LIB_DIR . '/meta-box/meta-box/' );
define( 'ADMIN_URL', LIB_URL . '/admin'  );
define( 'ADMIN_DIR', LIB_DIR . '/admin'  );
#-----------------------------------------------------------------
# Include Files
#-----------------------------------------------------------------
include_once( 'admin/admin-init.php');
//metabox inculde
include_once( 'meta-box/meta-box/meta-box.php');
include_once( 'meta-box/config-meta-box.php');
//theme options
include_once( 'theme-options/nhp-options.php');

include_once( 'sidebar-register.php');
include_once( 'nav-walker.php');
include_once( 'like-rating.php');
include_once( 'shortcodes.php');
include_once( 'pagenavi.php');
include_once( 'social/social-counter.php');
//widgets inlude
include_once( 'widgets/widget-init.php');

?>