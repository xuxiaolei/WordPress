<?php
/**
 * Registering meta boxes
 *
 * All the definitions of meta boxes are listed below with comments.
 * Please read them CAREFULLY.
 *
 * You also should read the changelog to know what has been changed before updating.
 *
 * For more information, please visit:
 * @link http://www.deluxeblogtips.com/meta-box/
 */


add_filter( 'rwmb_meta_boxes', 'wn_register_meta_boxes' );

/**
 * Register meta boxes
 *
 * @return void
 */
function wn_register_meta_boxes( $meta_boxes )
{
	/**
	 * Prefix of meta keys (optional)
	 * Use underscore (_) at the beginning to make keys hidden
	 * Alt.: You also can make prefix empty to disable it
	 */
	// Better has an underscore as last sign
	$prefix = 'wn_';

	$meta_boxes[] = array(
		'id' => 'post-standard',

		// Meta box title - Will appear at the drag and drop handle bar. Required.
		'title' => __( '属性', 'whatnew-theme' ),

		// Post types, accept custom post types as well - DEFAULT is array('post'). Optional.
		'pages' => array( 'post' ),

		// Where the meta box appear: normal (default), advanced, side. Optional.
		'context' => 'normal',

		// Order of meta box: high (default), low. Optional.
		'priority' => 'high',

		// Auto save: true, false (default). Optional.
		'autosave' => true,

		'fields' => array(
			array(
				'name' => __( '喜欢/评价 文章系统', 'whatnew-theme' ),
				'id' => "{$prefix}lr_header",
				'type' => 'heading'
			),
			array(
				'name' => __( '总分', 'whatnew-theme' ),
				'id' => "{$prefix}post_stars",
				'type' => 'text',
				'std' => '0'
			),
			array(
				'name' => __( '投票人数', 'whatnew-theme' ),
				'id' => "{$prefix}post_votes",
				'type' => 'text',
				'std' => '0'
			),
			array(
				'name' => __( '喜欢', 'whatnew-theme' ),
				'id' => "{$prefix}post_likes",
				'type' => 'text',
				'std' => '0'
			),
			array(
				'name' => __( '浏览次数', 'whatnew-theme' ),
				'id' => "{$prefix}post_views",
				'type' => 'text',
				'std' => '0'
			)
		)
	);

	$meta_boxes[] = array(
		'id' => 'page-standard',

		// Meta box title - Will appear at the drag and drop handle bar. Required.
		'title' => __( '属性', 'whatnew-theme' ),

		// Post types, accept custom post types as well - DEFAULT is array('post'). Optional.
		'pages' => array( 'page' ),

		// Where the meta box appear: normal (default), advanced, side. Optional.
		'context' => 'normal',

		// Order of meta box: high (default), low. Optional.
		'priority' => 'high',

		// Auto save: true, false (default). Optional.
		'autosave' => true,

		'fields' => array(
			array(
				'name' => __( '标题', 'whatnew-theme' ),
				'id' => "{$prefix}t_header",
				'type' => 'heading'
			),
			array(
				'name' => __( '显示页面默认标题', 'whatnew-theme' ),
				'id' => "{$prefix}enable_page_title",
				'type' => 'checkbox',
				'std' => 1
			),
			array(
				'name' => __( '自定义页面标题', 'whatnew-theme' ),
				'id' => "{$prefix}enable_custom_page_title",
				'type' => 'checkbox',
				'std' => 0
			),
			array(
				'name' => __( '页面标题背景颜色', 'whatnew-theme' ),
				'id' => "{$prefix}custom_page_title_bg",
				'type' => 'color',
				'std' => '#00b7ee'
			),
			array(
				'name' => __( '页面标题', 'whatnew-theme' ),
				'id' => "{$prefix}custom_page_title",
				'type' => 'text',
				'std' => ''
			),
			array(
				'name' => __( '页面二级标题', 'whatnew-theme' ),
				'id' => "{$prefix}custom_page_sub_title",
				'type' => 'text',
				'std' => ''
			),
			array(
				'name' => __( '顶置推荐轮播', 'whatnew-theme' ),
				'id' => "{$prefix}slider_header",
				'type' => 'heading'
			),
			array(
				'name' => __( '显示顶置推荐轮播', 'whatnew-theme' ),
				'id' => "{$prefix}enable_featured_slider",
				'type' => 'checkbox'
			),
			array(
				'name' => __( '轮播分类', 'whatnew-theme' ),
				'id' => "{$prefix}featured_slider_cats",
				'type'    => 'taxonomy',
				'multiple' => true,
	            'options' => array(
	                    // Taxonomy name
	                    'taxonomy' => 'category',
	                    // How to show taxonomy: 'checkbox_list' (default) or 'checkbox_tree', 'select_tree' or 'select'. Optional
	                    'type' => 'select_tree',
	                    // Additional arguments for get_terms() function. Optional
	                    'args' => array()
	            ),
			),
			array(
				'name' => __( '文章显示数量', 'whatnew-theme' ),
				'id' => "{$prefix}featured_slider_num",
				'type' => 'number',
				'min'  => 1,
	            'step' => 1,
			),
			array(
				'name' => __( '排除', 'whatnew-theme' ),
				'id' => "{$prefix}featured_slider_exclude",
				'desc'  => __('输入文章ID, 用英文逗号分开.', 'whatnew-theme'),
				'type' => 'text'
			),
			array(
				'name' => __( '排序方式', 'whatnew-theme' ),
				'id' => "{$prefix}featured_slider_orderby",
				'type' => 'select',
				'options' => array(
					'ID' => 'ID',
	                'title' => '标题',
				),
				'std' => 'ID'
			),
			array(
				'name' => __( '排序', 'whatnew-theme' ),
				'id' => "{$prefix}featured_slider_order",
				'type' => 'select',
				'options' => array(
					'DESC' => '降序',
	                'ASC' => '升序',
				),
				'std' => 'DESC'
			),
			array(
				'name' => __( '自定义页面布局', 'whatnew-theme' ),
				'id' => "{$prefix}ps_header",
				'type' => 'heading'
			),
			array(
				'name' => __( '页面布局', 'whatnew-theme' ),
				'id' => "{$prefix}ec_page_layout",
				'type' => 'checkbox',
				'desc' => __( '开启自定义页面布局?', 'whatnew-theme' )
			),
			array(
				'name'     => __( '', 'whatnew-theme' ),
				'id'       => "{$prefix}page_layout",
				'type'     => 'image_select',
				// Array of 'value' => 'Label' pairs for radio options.
				// Note: the 'value' is stored in meta field, not the 'Label'
				'options' => array(
								'c-m' => IMGURL . '/layouts/c-m.png',
								'full' => IMGURL . '/layouts/full.png'
							),//Must provide key => value(array:title|img) pairs for radio options
				'std' => 'c-m'	
			),
			array(
				'name' => __( '页面侧边栏', 'whatnew-theme' ),
				'id' => "{$prefix}ps_header",
				'type' => 'heading'
			),
			array(
				'name'     => __( '默认侧边栏', 'whatnew-theme' ),
				'id'       => "{$prefix}m_sidebar",
				'type'     => 'select_sidebar',
				// Select multiple values, optional. Default is false.
				'multiple'    => false,
				'std'         => 'sidebar-m', // Default value, optional
				'placeholder' => __( '选择一个侧边栏', 'whatnew-theme' ),
			)
		)
	);

	return $meta_boxes;
}
?>
