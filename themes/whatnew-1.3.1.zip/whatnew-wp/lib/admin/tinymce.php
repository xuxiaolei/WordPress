<?php

add_action('init', 'wn_tinymce_buttons');

function wn_tinymce_buttons() {

    if ( ! current_user_can('edit_posts') && ! current_user_can('edit_pages') ) {
        return;
    }

    if ( get_user_option('rich_editing') == 'true' ) {
        add_filter( 'mce_external_plugins', 'wn_add_plugin' );
        add_filter( 'mce_buttons_3', 'wn_register_button' );
        //add_action('admin_print_styles','wn_admin_tinymce_styles');
    }

}
/**
 * Script Enqueue
 */
function wn_admin_tinymce_styles() {
	wp_enqueue_style( 'tinymce-style', ADMIN_URL . '/tinymce/css/tinymce.css' );
}
/**
 * Register Button
 */

function wn_register_button( $buttons ) {
 array_push( $buttons,  "wncolumns", "wnposts", "wncarousel","wntabs", "wnalert", "wnbutton" );
 return $buttons;
}

/**
 * Register TinyMCE Plugin
 */

function wn_add_plugin( $plugin_array ) {
   $plugin_array['twentytheme'] = ADMIN_URL . '/tinymce/tinymce.js';
   return $plugin_array;
}

?>