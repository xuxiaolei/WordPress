<?php
include_once('review-control/review.php');
include_once('admin-nav-custom.php');
include_once('category-image.class.php');
include_once('posts-image-column.class.php');
include_once('tinymce.php');

#-----------------------------------------------------------------
# Some Custom Functions
#-----------------------------------------------------------------
/**
 *Script Enqueue
 */
function wn_admin_custom_styles() {
	wp_enqueue_style( 'admin-style', ADMIN_URL . '/css/admin.css' );
}
add_action('admin_enqueue_scripts','wn_admin_custom_styles');
$twenty_cat_image = new twenty_cat_image();

function twenty_admin_init() {
	$twenty_image_column = new twenty_image_column();
}
add_action( 'admin_init', 'twenty_admin_init' );
?>