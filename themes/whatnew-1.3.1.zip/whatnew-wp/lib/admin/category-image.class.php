<?php  
if( !class_exists('twenty_cat_image') ) :

define('CI_IMAGE_PLACEHOLDER', ADMIN_URL ."/images/placeholder.png" );

class twenty_cat_image {

	public function __construct() {
		add_action( 'admin_init', array( $this, 'ci_init' ) );
		// save our taxonomy image while edit or save term
		add_action('edit_term', array( $this, 'ci_save_taxonomy_image' ));
		add_action('create_term', array( $this, 'ci_save_taxonomy_image' ));

		// style the image in category list
		if ( strpos( $_SERVER['SCRIPT_NAME'], 'edit-tags.php' ) > 0 ) {
			//add_action('quick_edit_custom_box', array( $this, 'ci_quick_edit_custom_box' ), 10, 3);
			add_filter( "attribute_escape", array( $this, "ci_change_insert_button_text" ), 10, 2 );
		}

		add_filter( 'post_thumbnail_html', array( $this, 'tutport_thumbnail_html' ), 10, 5 );

	}
	public function ci_init() {
		$ci_taxonomies = get_taxonomies();
		foreach ($ci_taxonomies as $ci_taxonomy) {
			add_action($ci_taxonomy.'_add_form_fields', array( $this, 'ci_add_taxonomy_field' ));
			add_action($ci_taxonomy.'_edit_form_fields', array( $this, 'ci_edit_taxonomy_field' ));
			add_filter( 'manage_edit-' . $ci_taxonomy . '_columns', array( $this, 'ci_taxonomy_columns' ));
			add_filter( 'manage_' . $ci_taxonomy . '_custom_column', array( $this, 'ci_taxonomy_column' ), 10, 3 );
		}
	}
	public function ci_add_taxonomy_field() {
		if( get_bloginfo( 'version' ) >= 3.5 ) {
			wp_enqueue_media();
		} else {
			wp_enqueue_style('thickbox');
			wp_enqueue_script('thickbox');
		}
		printf('
			<div class="form-field">
				<label for="taxonomy_image"> %1$s </label>
				<input type="text" name="taxonomy_image" id="taxonomy_image" value="" />
				<br/>
				<button class="ci_upload_image_button button"> %2$s </button>
			</div> %3$s',
			__('Image', 'twenty-theme'),
			__('Upload/Add image', 'twenty-theme'),
			$this->ci_script()
		);
	}

	public function ci_edit_taxonomy_field( $taxonomy ) {
		if (get_bloginfo('version') >= 3.5) {
			wp_enqueue_media();
		} else {
			wp_enqueue_style('thickbox');
			wp_enqueue_script('thickbox');
		}	

		if($this->ci_taxonomy_image_url( $taxonomy->term_id, NULL, TRUE ) == CI_IMAGE_PLACEHOLDER ) {
			$image_text = "";
		} else {
			$image_text = $this->ci_taxonomy_image_url( $taxonomy->term_id, NULL, TRUE );
		}
		printf('
			<tr class="form-field">
				<th scope="row" valign="top"><label for="taxonomy_image"> %1$s </label></th>
				<td><img class="taxonomy-image" src="%2$s" /><br/>
				<input type="text" name="taxonomy_image" id="taxonomy_image" value="%3$s" /><br />
				<button class="ci_upload_image_button button"> %4$s </button>
				<button class="ci_remove_image_button button"> %5$s </button>
			</tr> %6$s',
			__('Image', 'twenty-theme'),
			$this->ci_taxonomy_image_url( $taxonomy->term_id, NULL, TRUE ),
			$image_text,
			__('Upload/Add image', 'twenty-theme'),
			__('Remove image', 'twenty-theme'),
			$this->ci_script()
		);
	}

	public function ci_script() {
		return '<script type="text/javascript">
		    jQuery(document).ready(function($) {
				var wordpress_ver = "'.get_bloginfo("version").'", upload_button;
				$(".ci_upload_image_button").click(function(event) {
					upload_button = $(this);
					var frame;
					if (wordpress_ver >= "3.5") {
						event.preventDefault();
						if (frame) {
							frame.open();
							return;
						}
						frame = wp.media();
						frame.on( "select", function() {
							// Grab the selected attachment.
							var attachment = frame.state().get("selection").first();
							frame.close();
							if (upload_button.parent().prev().children().hasClass("tax_list")) {
								upload_button.parent().prev().children().val(attachment.attributes.url);
								upload_button.parent().prev().prev().children().attr("src", attachment.attributes.url);
							}
							else
								$("#taxonomy_image").val(attachment.attributes.url);
						});
						frame.open();
					}
					else {
						tb_show("", "media-upload.php?type=image&amp;TB_iframe=true");
						return false;
					}
				});
				
				$(".ci_remove_image_button").click(function() {
					$("#taxonomy_image").val("");
					$(this).parent().siblings(".title").children("img").attr("src","' . CI_IMAGE_PLACEHOLDER . '");
					$(".inline-edit-col :input[name=\'taxonomy_image\']").val("");
					return false;
				});
				
				if (wordpress_ver < "3.5") {
					window.send_to_editor = function(html) {
						imgurl = $("img",html).attr("src");
						if (upload_button.parent().prev().children().hasClass("tax_list")) {
							upload_button.parent().prev().children().val(imgurl);
							upload_button.parent().prev().prev().children().attr("src", imgurl);
						}
						else
							$("#taxonomy_image").val(imgurl);
						tb_remove();
					}
				}
				
				$(".editinline").live("click", function(){  
				    var tax_id = $(this).parents("tr").attr("id").substr(4);
				    var thumb = $("#tag-"+tax_id+" .thumb img").attr("src");
					if (thumb != "' . CI_IMAGE_PLACEHOLDER . '") {
						$(".inline-edit-col :input[name=\'taxonomy_image\']").val(thumb);
					} else {
						$(".inline-edit-col :input[name=\'taxonomy_image\']").val("");
					}
					$(".inline-edit-col .title img").attr("src",thumb);
				    return false;  
				});  
		    });
		</script>';
	}

	public function ci_save_taxonomy_image( $term_id ) {
		if( isset($_POST['taxonomy_image']) ) {
			update_option( 'ci_taxonomy_image'.$term_id, $_POST['taxonomy_image'] );
		}
	}

	public function ci_get_attachment_id_by_url( $image_src ) {
		global $wpdb;

		$query = "SELECT ID FROM {$wpdb->posts} WHERE guid = '$image_src'";
    	$id = $wpdb->get_var($query);

    	return (!empty($id)) ? $id : NULL;
	}

	public function ci_taxonomy_image_url($term_id = NULL, $size = NULL, $return_placeholder = FALSE) {
		if( !$term_id ) {
			if( is_category() ) {
				$term_id = get_query_var( 'cat' );
			} elseif ( is_tax() ) {
				$custom_term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );
				$term_id = $custom_term->term_id;
			}
		}

		$taxonomy_image_url = get_option( 'ci_taxonomy_image' . $term_id );

		if( !isset($taxonomy_image_url) || empty($taxonomy_image_url) ) {
			return CI_IMAGE_PLACEHOLDER;
		}

		$attachment_id = $this->ci_get_attachment_id_by_url( $taxonomy_image_url );

		if( !empty($attachment_id) ) {
			if( empty($size) ) {
				$size = 'full';
			}
			$taxonomy_image_url = wp_get_attachment_image_src( $attachment_id, $size );
			$taxonomy_image_url = $taxonomy_image_url[0];
		}
		if($return_placeholder) {
			return ($taxonomy_image_url != '') ? $taxonomy_image_url : CI_IMAGE_PLACEHOLDER;
		} else {
			return $taxonomy_image_url;
		}
	}

	public function ci_quick_edit_custom_box( $column_name, $screen, $name ) {
		if ($column_name == 'thumb') 
			echo '<fieldset>
			<div class="thumb inline-edit-col">
				<label>
					<span class="title"><img src="" alt="Thumbnail"/></span>
					<span class="input-text-wrap"><input type="text" name="taxonomy_image" value="" class="tax_list" /></span>
					<span class="input-text-wrap">
						<button class="z_upload_image_button button">' . __('Upload/Add image', 'twenty-theme') . '</button>
						<button class="z_remove_image_button button">' . __('Remove image', 'twenty-theme') . '</button>
					</span>
				</label>
			</div>
		</fieldset>';
	}

	/**
	 * Thumbnail column added to category admin.
	 *
	 * @access public
	 * @param mixed $columns
	 * @return void
	 */
	public function ci_taxonomy_columns( $columns ) {
		$new_columns = array();
		$new_columns['cb'] = $columns['cb'];
		$new_columns['thumb'] = __('Image', 'twenty-theme');

		unset( $columns['cb'] );

		return array_merge( $new_columns, $columns );
	}

	/**
	 * Thumbnail column value added to category admin.
	 *
	 * @access public
	 * @param mixed $columns
	 * @param mixed $column
	 * @param mixed $id
	 * @return void
	 */
	public function ci_taxonomy_column( $columns, $column, $id ) {
		if ( $column == 'thumb' ) {
			$columns = '<span><img src="' . $this->ci_taxonomy_image_url($id, NULL, TRUE) . '" alt="' . __('Thumbnail', 'twenty-theme') . '" class="wp-post-image" /></span>';
		}
		
		return $columns;
	}

	// change 'insert into post' to 'use this image'
	public function ci_change_insert_button_text($safe_text, $text) {
	    return str_replace("Insert into Post", "Use this image", $text);
	}

	//filter to 'the_post_thumbnail', when post has no featured image, use category featured image
	public function tutport_thumbnail_html( $html, $post_id, $post_thumbnanil_id, $size, $attr ) {
		if( empty( $html ) ) {
			$cats = get_the_category( $post_id );
			$cat = $cats[0];
			$default_image = $this->ci_taxonomy_image_url( $cat->term_id, $size, TRUE );
			$html = sprintf('<img src="%1$s" %2$s >',
						$default_image,
						$attr
					);
		}
		return $html;
	}
	
}

endif;

?>