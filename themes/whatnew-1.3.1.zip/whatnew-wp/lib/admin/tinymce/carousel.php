<?php
// Call WP Load
$wp_include = "../wp-load.php";$i = 0;
while (!file_exists($wp_include) && $i++ < 10) {$wp_include = "../$wp_include";} require($wp_include);
if ( !is_user_logged_in() || !current_user_can('edit_posts') )
	wp_die(__("You are not allowed to be here","whatnew-theme"));
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>Carousel Creator</title>
<link rel="stylesheet" href="<?php echo get_template_directory_uri() . '/css/bootstrap.css'; ?>" type="text/css" media="screen" />
<link rel="stylesheet" href="<?php echo ADMIN_URL . '/tinymce/css/tinymce.css'; ?>" type="text/css" media="screen" />
<script type="text/javascript" src="<?php echo home_url() ?>/wp-includes/js/jquery/jquery.js"></script>
<script type="text/javascript" src="<?php echo home_url() ?>/wp-includes/js/tinymce/tiny_mce_popup.js?v=3211"></script>
	<script type="text/javascript" >
            tinyMCEPopup.requireLangPack();

        var CarouselDialog = {
        	local_ed : 'ed',
            init : function(ed) {
            	CarouselDialog.local_ed = ed;
                var f = document.forms[0];
                output = '';
                // Get the selected contents as text and place it in the input
                //f.someval.value = tinyMCEPopup.editor.selection.getContent({format : 'text'});
            },

            insert : function() {
            		var example = '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>';
					var nl = '<br /><br />';
					var show_title = title = sub_title = title_bg = cats = authors = exclude = orderby = order = posts_per_page = '';
					if(jQuery('#show-title').is(":checked")) {
						show_title = 'show_title=true ';
					}
					if(jQuery('#title').val() != '') {
						title = 'title="'+jQuery('#title').val()+'" ';
					}
					if(jQuery('#sub-title') != '') {
						sub_title = 'sub_title="'+jQuery('#sub-title').val()+'" ';
					}
					if(jQuery('#title-bg').val() != '') {
						title_bg = 'title_bg="'+jQuery('#title-bg').val()+'" ';
					}
					if(jQuery('#cats').val() != '') {
						cats = 'cats="'+jQuery('#cats').val()+'" ';
					}
					if(jQuery('#authors').val() != '') {
						authors = 'authors="'+jQuery('#authors').val()+'" ';
					}
					if(jQuery('#exclude').val() != '') {
						exclude = 'exclude="'+jQuery('#exclude').val()+'" ';
					}
					if(jQuery('#orderby').val() != '') {
						orderby = 'orderby="'+jQuery('#orderby').val()+'" ';
					}
					if(jQuery('#order').val() != '') {
						order = 'order="'+jQuery('#order').val()+'" ';
					}
					if(jQuery('#posts-per-page').val() != '') {
						posts_per_page = 'posts_per_page="'+jQuery('#posts-per-page').val()+'" ';
					}
					
			        output = '[insert_carousel '+show_title + title + sub_title + title_bg + cats + authors + exclude + orderby + order + posts_per_page+']' + nl;

                    // Insert the contents from the input into the document
                    tinyMCEPopup.editor.execCommand('mceInsertContent', false, output);
                    tinyMCEPopup.close();
                }
        };

		tinyMCEPopup.onInit.add(CarouselDialog.init, CarouselDialog);

        </script>
</head>
<body>

<form onsubmit="CarouselDialog.insert();return false;" action="#">
    <div id="tabs">
    	
        <div class="tabcont">
            <h3>文章轮播</h3>
            <fieldset>
                <label>显示标题:</label>
                <input type="checkbox" name="show-title" id="show-title" >
            </fieldset>
            <fieldset>
                <label>标题:</label>
                <input type="text" name="title" id="title" >
            </fieldset>
            <fieldset>
                <label>二级标题:</label>
                <input type="text" name="sub-title" id="sub-title" >
            </fieldset>
            <fieldset>
                <label>标题背景色:</label>
                <input type="text" name="title-bg" id="title-bg" >
            </fieldset>
            <fieldset>
                <label>分类:</label>
                <input type="text" name="cats" id="cats" >
            </fieldset>
            <fieldset>
                <label>作者:</label>
                <input type="text" name="authors" id="authors" >
            </fieldset>
            <fieldset>
                <label>排除:</label>
                <input type="text" name="exclude" id="exclude" >
            </fieldset>
            <fieldset>
                <label>排序方式:</label>
                <select name="orderby" id="orderby">
                	<option value="id">ID</option>
                	<option value="title">标题</option>
                	<option value="comment_count">评论数</option>
					<option value="views">浏览量</option>
					<option value="likes">喜欢量</option>
					<option value="stars">评分</option>
                </select>
            </fieldset>
            <fieldset>
                <label>排序:</label>
                <select name="order" id="order">
                	<option value="desc">降序</option>
                	<option value="asec">升序</option>
                </select>
            </fieldset>
            
            <fieldset>
                <label>每页文章显示数:</label>
                <input type="text" name="posts-per-page" id="posts-per-page" >
            </fieldset>
        </div>
    </div>
    <div class="mceActionPanel">
            <input type="button" id="insert" name="insert" value="{#insert}" onclick="CarouselDialog.insert();" />
            <input type="button" id="cancel" name="cancel" value="{#cancel}" onclick="tinyMCEPopup.close();" />
    </div>
</form>

</body>
</html>
