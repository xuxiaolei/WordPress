<?php
// Call WP Load
$wp_include = "../wp-load.php";
$i = 0;
while (!file_exists($wp_include) && $i++ < 10) {
    $wp_include = "../$wp_include";
} require



($wp_include);
if ( !is_user_logged_in() || !current_user_can('edit_posts') )
    wp_die(__("You are not allowed to be here","whatnew-theme"));
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Columns creator</title>
        <link rel="stylesheet" href="<?php echo ADMIN_URL . '/tinymce/css/tinymce.css'; ?>" type="text/css" media="screen" />
        <script type="text/javascript" src="<?php echo home_url() ?>/wp-includes/js/jquery/jquery.js"></script>
        <script type="text/javascript" src="<?php echo home_url() ?>/wp-includes/js/tinymce/tiny_mce_popup.js?v=3211"></script>
        <script type="text/javascript" >
            tinyMCEPopup.requireLangPack();


            var ListsDialog = {
                local_ed : 'ed',
                init : function(ed) {
                    ListsDialog.local_ed = ed;
                    var f = document.forms[0];
                    output = '';
                    // Get the selected contents as text and place it in the input
                    //f.someval.value = tinyMCEPopup.editor.selection.getContent({format : 'text'});
                    jQuery('.select-col').click(function(){

                        jQuery(".select-col").attr('class', 'select-col');
                          jQuery(this).addClass('active');
                    
                    });

                },

                insert : function() {

                    var cols = jQuery('.select-col.active').attr('id');;
					var example = '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>';
					var nl = '<br /><br />';
			        switch(cols)
			        {
			            case "two": output = '[col type="half"]' + example + '[/col]' + nl + '[col type="half last"]' + example + '[/col]' + nl;
			                break;
			            case "three": output = '[col type="one-third"]' + example + '[/col]' + nl + '[col type="one-third"]' + example + '[/col]' + nl + '[col type="one-third last"]' + example + '[/col]' + nl;
			            	break;
			            case "four": output = '[col type="one-fourth"]' + example + '[/col]' + nl + '[col type="one-fourth"]' + example + '[/col]' + nl + '[col type="one-fourth"]' + example + '[/col]' + nl + '[col type="one-fourth last"]' + example + '[/col]' + nl;
			                break;
			            case "onetwo": output = '[col type="one-third"]' + example + '[/col]' + nl + '[col type="two-third last"]' + example + '[/col]' + nl;
			                break;
			            case "onethree": output = '[col type="one-fourth"]' + example + '[/col]' + nl + '[col type="three-fourth last"]' + example + '[/col]' + nl;
			                break;
			            case "onethreethree": output = '[col type="one-fourth"]' + example + '[/col]' + nl + '[col type="three-eighth"]' + example + '[/col]' + nl + '[col type="three-eighth last"]' + example + '[/col]' + nl;
			            	break;
			            default: output = "";
			        }

                    // Insert the contents from the input into the document
                    tinyMCEPopup.editor.execCommand('mceInsertContent', false, output);
                    tinyMCEPopup.close();
                }
            };

            tinyMCEPopup.onInit.add(ListsDialog.init, ListsDialog);

        </script>
    </head>
    <body>

        <form onsubmit="ListsDialog.insert();return false;" action="#">
            <div id="lists">

                <h3>选择样式</h3>
                <p>点击下面样式进行选择</p>
                <div class="select-col" id="two">
                    <h5>Two columns</h5>
                    <div class="column half"></div>
                    <div class="column half last"></div>
                    <div class="clear"></div>
                </div>
                <div class="select-col" id="three">
                    <h5>Three columns</h5>
                    <div class="column one-third"></div>
                    <div class="column one-third"></div>
                    <div class="column one-third last"></div>
                    <div class="clear"></div>
                </div>
                <div class="select-col" id="four">
                    <h5>Four columns</h5>
                    <div class="column one-fourth"></div>
                    <div class="column one-fourth"></div>
                    <div class="column one-fourth"></div>
                    <div class="column one-fourth last"></div>
                    <div class="clear"></div>
                </div>
                <div class="select-col" id="onetwo">
                    <h5>Columns 1/3 and 2/3 </h5>
                    <div class="column one-third"></div>
                    <div class="column two-third last"></div>
                    <div class="clear"></div>
                </div>
                <div class="select-col"  id="onethree">
                    <h5>Columns 1/4 and 3/4 </h5>
                    <div class="column one-fourth"></div>
                    <div class="column three-fourth last"></div>
                    <div class="clear"></div>
                </div>
                <div class="select-col" id="onethreethree">
                    <h5>Columns 1/4 and 3/8 and 3/8 </h5>
                    <div class="column one-fourth"></div>
                    <div class="column three-eighth"></div>
                    <div class="column three-eighth last"></div>
                    <div class="clear"></div>
                </div>
                <div class="mceActionPanel">
                    <input type="button" id="insert" name="insert" value="{#insert}" onclick="ListsDialog.insert();" />
                    <input type="button" id="cancel" name="cancel" value="{#cancel}" onclick="tinyMCEPopup.close();" />
                </div>
        </form>

    </body>
</html>
