<?php
// Call WP Load
$wp_include = "../wp-load.php";$i = 0;
while (!file_exists($wp_include) && $i++ < 10) {$wp_include = "../$wp_include";} require($wp_include);
if ( !is_user_logged_in() || !current_user_can('edit_posts') )
	wp_die(__("You are not allowed to be here","whatnew-theme"));
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>Tabs creator</title>
<link rel="stylesheet" href="<?php echo ADMIN_URL . '/tinymce/css/tinymce.css'; ?>" type="text/css" media="screen" />
<script type="text/javascript" src="<?php echo home_url() ?>/wp-includes/js/jquery/jquery.js"></script>
<script type="text/javascript" src="<?php echo home_url() ?>/wp-includes/js/tinymce/tiny_mce_popup.js?v=3211"></script>
	<script type="text/javascript" >
            tinyMCEPopup.requireLangPack();


        var TabsDialog = {
            init : function() {
                var f = document.forms[0];
                output = '';
                // Get the selected contents as text and place it in the input
                //f.someval.value = tinyMCEPopup.editor.selection.getContent({format : 'text'});
                jQuery('#newtab').click(function(){
                    jQuery('.tabcont:first').clone().addClass('newtab').appendTo('#tabs');
                    return false;
                });

                jQuery('.removeTab').click(function() {
                    if(jQuery('#tabs .tabcont').size() == 1) {
                        alert('抱歉,你至少需要一个tab');
                    }
                    else {
                        jQuery(this).parent().slideUp(300, function() {
                            jQuery(this).remove();
                        })
                    }
                    return false;
                });
            },

            insert : function() {
				var example = '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>';
				var nl = '<br /><br />';
                output = '[tabs]' + nl;
				
                jQuery('.tabcont').each(function(index) {
                    var title = jQuery(this).find('.tab-title').val();
                    var content = jQuery(this).find('.tab-content').val();
                    output += '[tab title="'+title+'"]' + nl + content + nl + '[/tab]' + nl;
                });
                output += ' [/tabs]' + nl;
		// Insert the contents from the input into the document
		tinyMCEPopup.editor.execCommand('mceInsertContent', false, output);
		tinyMCEPopup.close();
            }
        };

tinyMCEPopup.onInit.add(TabsDialog.init, TabsDialog);

        </script>
</head>
<body>

<form onsubmit="TabsDialog.insert();return false;" action="#">
    <div id="tabs">
    	
        <div class="tabcont">
            <h3><?php _e( 'Tab', 'whatnew-theme' ) ?></h3>
            <p>
                <label><?php _e( 'Tab 标题', 'whatnew-theme' ) ?></label>
                <input class="tab-title" name="tab" type="text" class="text" />
            </p>
            <p>
                <label><?php _e( 'Tab 内容', 'whatnew-theme' ) ?></label>
                <textarea class="tab-content" name="tab-content" class="text" ></textarea>
            </p>
           <!-- <button class="updateButton removeTab"><?php _e( '删除 Tab', 'whatnew-theme' ) ?></button> -->
        </div>
    </div>
    <a href="#" class="btn" id="newtab"><?php _e( '添加 Tab', 'whatnew-theme' ) ?></a>
    <div class="mceActionPanel">
            <input type="button" id="insert" name="insert" value="{#insert}" onclick="TabsDialog.insert();" />
            <input type="button" id="cancel" name="cancel" value="{#cancel}" onclick="tinyMCEPopup.close();" />
    </div>
</form>

</body>
</html>
