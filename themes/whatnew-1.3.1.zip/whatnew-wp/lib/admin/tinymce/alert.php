<?php
// Call WP Load
$wp_include = "../wp-load.php";$i = 0;
while (!file_exists($wp_include) && $i++ < 10) {$wp_include = "../$wp_include";} require($wp_include);
if ( !is_user_logged_in() || !current_user_can('edit_posts') )
	wp_die(__("You are not allowed to be here","whatnew-theme"));
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>Alert creator</title>
<link rel="stylesheet" href="<?php echo get_template_directory_uri() . '/css/bootstrap.css'; ?>" type="text/css" media="screen" />
<link rel="stylesheet" href="<?php echo ADMIN_URL . '/tinymce/css/tinymce.css'; ?>" type="text/css" media="screen" />
<script type="text/javascript" src="<?php echo home_url() ?>/wp-includes/js/jquery/jquery.js"></script>
<script type="text/javascript" src="<?php echo home_url() ?>/wp-includes/js/tinymce/tiny_mce_popup.js?v=3211"></script>
	<script type="text/javascript" >
            tinyMCEPopup.requireLangPack();


        var AlertDialog = {
        	local_ed : 'ed',
            init : function(ed) {
            	AlertDialog.local_ed = ed;
                var f = document.forms[0];
                output = '';
                // Get the selected contents as text and place it in the input
                //f.someval.value = tinyMCEPopup.editor.selection.getContent({format : 'text'});
                jQuery('.uk-alert').click(function(){
                	  
                      jQuery(".active").removeClass('active');
                      jQuery(this).addClass('active');
                
                });
            },

            insert : function() {
					var example = '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>';
					var nl = '<br /><br />';
				
                    var type = jQuery('.alert.active').attr('id');
					var content = jQuery('.alert-content').val();
					var close = 'false';
					if(jQuery('#alert-close').is(":checked")) {
						close = 'true';
					}
			        output = '[alert type="'+type+'" close='+close+']'+content+'[/alert]' + nl;

                    // Insert the contents from the input into the document
                    tinyMCEPopup.editor.execCommand('mceInsertContent', false, output);
                    tinyMCEPopup.close();
                }
        };

		tinyMCEPopup.onInit.add(AlertDialog.init, AlertDialog);

        </script>
</head>
<body>

<form onsubmit="AlertDialog.insert();return false;" action="#">
    <div id="tabs">
    	
        <div class="tabcont">
            <h3>消息框</h3>
            <p>
                <label>关闭按钮:</label>
                <input type="checkbox" name="alert-close" id="alert-close" >
            </p>
            <p>
                <label>消息框类型:</label>
                <fieldset class="select-right">
	                <div class="alert alert-info" id="info">
						Lorem ipsum dolor sit amet, consectetur adipisicing
	                </div>
	                <div class="alert alert-success" id="success">
						Lorem ipsum dolor sit amet, consectetur adipisicing
	                </div>
	                <div class="alert alert-warning" id="warning">
						Lorem ipsum dolor sit amet, consectetur adipisicing
	                </div>
	                <div class="alert alert-danger" data-uk-alert="" id="danger">
						Lorem ipsum dolor sit amet, consectetur adipisicing
	                </div>
                </fieldset>
            </p>
            <p>
                <label>消息框内容:</label>
                <textarea class="alert-content" name="alert-content" class="text" ></textarea>
            </p>
        </div>
    </div>
    <div class="mceActionPanel">
            <input type="button" id="insert" name="insert" value="{#insert}" onclick="AlertDialog.insert();" />
            <input type="button" id="cancel" name="cancel" value="{#cancel}" onclick="tinyMCEPopup.close();" />
    </div>
</form>

</body>
</html>
