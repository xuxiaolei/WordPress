<?php
// Call WP Load
$wp_include = "../wp-load.php";$i = 0;
while (!file_exists($wp_include) && $i++ < 10) {$wp_include = "../$wp_include";} require($wp_include);
if ( !is_user_logged_in() || !current_user_can('edit_posts') )
	wp_die(__("You are not allowed to be here","whatnew-theme"));
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>Blog Posts Creator</title>
<link rel="stylesheet" href="<?php echo get_template_directory_uri() . '/css/bootstrap.css'; ?>" type="text/css" media="screen" />
<link rel="stylesheet" href="<?php echo ADMIN_URL . '/tinymce/css/tinymce.css'; ?>" type="text/css" media="screen" />
<script type="text/javascript" src="<?php echo home_url() ?>/wp-includes/js/jquery/jquery.js"></script>
<script type="text/javascript" src="<?php echo home_url() ?>/wp-includes/js/tinymce/tiny_mce_popup.js?v=3211"></script>
	<script type="text/javascript" >
            tinyMCEPopup.requireLangPack();

        var BlogDialog = {
        	local_ed : 'ed',
            init : function(ed) {
            	BlogDialog.local_ed = ed;
                var f = document.forms[0];
                output = '';
                // Get the selected contents as text and place it in the input
                //f.someval.value = tinyMCEPopup.editor.selection.getContent({format : 'text'});
            },

            insert : function() {
            		var example = '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>';
					var nl = '<br /><br />';
					var show_title = show_pagenation = title = sub_title = title_bg_color = cats = authors = exclude = orderby = order = type = posts_per_page = '';
					if(jQuery('#show-title').is(":checked")) {
						show_title = 'show_title=true ';
					}
					if(jQuery('#show-pagenation').is(":checked")) {
						show_pagenation = 'show_paging=true ';
					}
					if(jQuery('#title').val() != '') {
						title = 'title="'+jQuery('#title').val()+'" ';
					}
					if(jQuery('#sub-title') != '') {
						sub_title = 'sub_title="'+jQuery('#sub-title').val()+'" ';
					}
					if(jQuery('#title-bg').val() != '') {
						title_bg_color = 'title_bg_color="'+jQuery('#title-bg').val()+'" ';
					}
					if(jQuery('#cats').val() != '') {
						cats = 'cats="'+jQuery('#cats').val()+'" ';
					}
					if(jQuery('#authors').val() != '') {
						authors = 'authors="'+jQuery('#authors').val()+'" ';
					}
					if(jQuery('#exclude').val() != '') {
						exclude = 'exclude="'+jQuery('#exclude').val()+'" ';
					}
					if(jQuery('#orderby').val() != '') {
						orderby = 'orderby="'+jQuery('#orderby').val()+'" ';
					}
					if(jQuery('#order').val() != '') {
						order = 'order="'+jQuery('#order').val()+'" ';
					}
					if(jQuery('#display-type').val() != '') {
						type = 'type="'+jQuery('#display-type').val()+'" ';
					}
					if(jQuery('#posts-per-page').val() != '') {
						posts_per_page = 'posts_per_page="'+jQuery('#posts-per-page').val()+'" ';
					}
					
			        output = '[insert_posts '+show_title + show_pagenation + title + sub_title + title_bg_color + cats + authors + exclude + orderby + order + type + posts_per_page+']' + nl;

                    // Insert the contents from the input into the document
                    tinyMCEPopup.editor.execCommand('mceInsertContent', false, output);
                    tinyMCEPopup.close();
                }
        };

		tinyMCEPopup.onInit.add(BlogDialog.init, BlogDialog);

        </script>
</head>
<body>

<form onsubmit="BlogDialog.insert();return false;" action="#">
    <div id="tabs">
    	
        <div class="tabcont">
            <h3><?php _e( '文章列表', 'whatnew-theme' ); ?></h3>
            <fieldset>
                <label>Show Title:</label>
                <input type="checkbox" name="show-title" id="show-title" >
            </fieldset>
            <fieldset>
                <label><?php _e( '标题:', 'whatnew-theme' ) ?></label>
                <input type="text" name="title" id="title" >
            </fieldset>
            <fieldset>
                <label><?php _e( '二级标题:', 'whatnew-theme' ) ?></label>
                <input type="text" name="sub-title" id="sub-title" >
            </fieldset>
            <fieldset>
                <label><?php _e( '标题背景颜色', 'whatnew-theme' ) ?></label>
                <input type="text" name="title-bg" id="title-bg" >
            </fieldset>
            <fieldset>
                <label><?php _e( '分类:', 'whatnew-theme' ) ?></label>
                <input type="text" name="cats" id="cats" >
            </fieldset>
            <fieldset>
                <label><?php _e( '作者:', 'whatnew-theme' ) ?></label>
                <input type="text" name="authors" id="authors" >
            </fieldset>
            <fieldset>
                <label><?php _e( '排除:', 'whatnew-theme' ) ?></label>
                <input type="text" name="exclude" id="exclude" >
            </fieldset>
            <fieldset>
                <label><?php _e( '排序方式:', 'whatnew-theme' ) ?></label>
                <select name="orderby" id="orderby">
                	<option value="id">ID</option>
                	<option value="title"><?php _e( '标题', 'whatnew-theme' ) ?></option>
                	<option value="comment_count"><?php _e( '评论数', 'whatnew-theme' ) ?></option>
					<option value="views"><?php _e( '浏览量', 'whatnew-theme' ) ?></option>
					<option value="likes"><?php _e( '喜欢量', 'whatnew-theme' ) ?></option>
					<option value="stars"><?php _e( '评分', 'whatnew-theme' ) ?></option>
                </select>
            </fieldset>
            <fieldset>
                <label><?php _e( '排序', 'whatnew-theme' ) ?></label>
                <select name="order" id="order">
                	<option value="desc"><?php _e( '降序', 'whatnew-theme' ) ?></option>
                	<option value="asec"><?php _e( '升序', 'whatnew-theme' ) ?></option>
                </select>
            </fieldset>
            <fieldset>
                <label><?php _e( '列表样式:', 'whatnew-theme' ) ?></label>
                <select name="display-type" id="display-type">
                	<option value="1"><?php _e( '经典', 'whatnew-theme' ) ?></option>
                	<option value="2"><?php _e( '两列', 'whatnew-theme' ) ?></option>
                	<option value="3"><?php _e( '三列', 'whatnew-theme' ) ?></option>
					<option value="4"><?php _e( '两列(小)', 'whatnew-theme' ) ?></option>
                </select>
            </fieldset>
            <fieldset>
                <label><?php _e( '显示分页:', 'whatnew-theme' ) ?></label>
                <input type="checkbox" name="show-pagenation" id="show-pagenation" >
            </fieldset>
            
            <fieldset>
                <label><?php _e( '每页文章数:', 'whatnew-theme' ) ?></label>
                <input type="text" name="posts-per-page" id="posts-per-page" >
            </fieldset>
        </div>
    </div>
    <div class="mceActionPanel">
            <input type="button" id="insert" name="insert" value="{#insert}" onclick="BlogDialog.insert();" />
            <input type="button" id="cancel" name="cancel" value="{#cancel}" onclick="tinyMCEPopup.close();" />
    </div>
</form>

</body>
</html>
