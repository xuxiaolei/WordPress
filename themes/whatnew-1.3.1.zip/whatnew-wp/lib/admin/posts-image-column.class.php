<?php  
if(!class_exists('twenty_image_column')) :

class twenty_image_column {
	public function __construct() {
		add_filter( 'manage_posts_columns', array( $this, 'twenty_columns_head' ) );
		add_action( 'manage_posts_custom_column', array( $this, 'twenty_columns_content' ), 10, 2 );
	}
	/**
	 * add new column
	 */
	public function twenty_columns_head( $defaults ) {
		$this->twenty_array_insert( $defaults, 2, array('featured_image' => __( 'Featured Image', 'twenty' )) );
		return $defaults;
	}
	/**
	 * return columns content
	 */
	public function twenty_columns_content( $column_name, $post_id ) {
		if($column_name == 'featured_image') {
			$post_featured_image = $this->twenty_get_featured_image( $post_id );
			if($post_featured_image) {
				printf('<img src="%s" />', $post_featured_image);
			}
		}
	}
	/**
	 * get featued image
	 */
	public function twenty_get_featured_image( $post_id ) {
		$post_thumbnail_id = get_post_thumbnail_id( $post_id );
		if($post_thumbnail_id) {
			$post_thumbnail_img = wp_get_attachment_image_src( $post_thumbnail_id, 'column-image' );
			return $post_thumbnail_img[0];
		}
	}
	/**
	 * array insert
	 */
	public function twenty_array_insert( &$array, $position, $insert_array ) {
		$first_array = array_splice($array, 0, $position);
		$array = array_merge($first_array, $insert_array, $array);
	}
}

endif;

?>