<?php

class WN_LikeRating {
	/**
	 * this is a post like and post rating system
	 *
	 */
	public function __construct() {

		add_action( 'wp_head', array( &$this, 'header_enqueue' ), 2 );

		add_action('wp_ajax_likes', array( &$this, 'likes' ) );
		add_action('wp_ajax_nopriv_likes', array( &$this, 'likes' ) );
		
		add_action('wp_ajax_rates', array( &$this, 'rates' ) );
		add_action('wp_ajax_nopriv_rates', array( &$this, 'rates' ) );	
		
		add_filter( "the_content", array( &$this, "the_content" ) );
	}

	/**
	 * Additional column for the selected post type from the plugin option
	 * Later action by add add_filter( "manage_{$post_type}_posts_columns", $posts_columns );
	 * @return $columns.
	 * @since 1.5
	**/
	function header_enqueue() {
		wp_enqueue_script( 'like-rating', THEMEURL . '/js/jquery.like-rating.js',array('jquery'));
		wp_localize_script( 'like-rating', 'lrating', apply_filters('sp_localize_script', array(
			'ajaxurl'	=> admin_url('admin-ajax.php'),
			'nonce'		=> wp_create_nonce( 'like-rating' ),
			'likes'		=> array( 
							'action' 	=> 'likes',
							'success'	=> __('喜欢成功!', 'whatnew-theme'),
							'error'		=> __('你已经喜欢过它了.XD.', 'whatnew-theme')
			),
			'rates'		=> array( 
							'action' 	=> 'rates',
							'success'	=> __('评价成功!', 'whatnew-theme'),
							'error'		=> __('你已经评价过它了.XD.', 'whatnew-theme')
			)
		)));
	}

	/**
	 * Ajax function for like
	 * @since 1.5
	**/
	function likes() {
		
		// Check nonce for security reason
		$nonce = $_POST['nonce'];
		if ( ! wp_verify_nonce( $nonce, 'like-rating' ) && ! isset( $_POST['id'] ) )
			die();

		
		// Get the post ID and the post meta data
		$post_id = $_POST['id'];
		$meta_likes = get_post_meta( $post_id, 'wn_post_likes', true );

		// Create or modified the cookie
		$this->set_cookie( $post_id, 'likes' );
		
		// Set to 0 if is not existed and update the likes count
		$likes = $meta_likes ? $meta_likes : 0;
		$likes++;
		update_post_meta( $post_id, 'wn_post_likes', $likes );
		
		echo $likes;
		exit;
	}
	/**
	 * Get Post Likes
	 */
	static function get_likes() {
		global $post;
		$meta_likes = get_post_meta( $post->ID, 'wn_post_likes', true );
		// Set to 0 if is not existed and update the likes count
		$likes = $meta_likes ? $meta_likes : 0;

		return $likes;
	}
	/**
	 * Ajax function for rates
	 * @since 1.5
	**/
	function rates() {
		if( ! wp_verify_nonce( $_POST['nonce'], 'like-rating' ) && ! isset( $_POST['id'] ) && ! isset( $_POST['star'] ) )
			die();

		// Get the post ID
		$post_id = (int) $_POST['id'];
		
		// Update the total votes for current post
		$meta_votes = get_post_meta( $post_id, 'wn_post_votes', true );
		$votes = $meta_votes ? $meta_votes : 0;
		$votes++;
		update_post_meta( $post_id, 'wn_post_votes', $votes );
		
		// Update the total stars for current post
		$meta_stars = get_post_meta( $post_id, 'wn_post_stars', true );
		$stars = $meta_stars ? $meta_stars : 0;
		$stars = $stars + (int) $_POST['star'];
		update_post_meta( $post_id, 'wn_post_stars', $stars );
		
		// Create or modified the cookie
		$this->set_cookie( $post_id, 'rates' );
		
		echo (int) $stars / (int) $votes;
		exit;
	}
	/**
	 * Get Post Stars
	 */
	static function get_stars() {
		global $post;
		$meta_stars = get_post_meta( $post->ID, 'wn_post_stars', true );
		$meta_votes = get_post_meta( $post->ID, 'wn_post_votes', true );
		$votes = ( $meta_votes && is_numeric($meta_votes) && $meta_votes >= 0 ) ? $meta_votes : 0;
		// Set to 0 if is not existed and update the stars count
		$stars = ( $meta_stars && is_numeric($meta_stars) && $meta_stars >= 0) ? ($meta_stars/$votes) : 0;
		
		return $stars;
	}
	/**
	 * Get Post Votes
	 */
	static function get_votes() {
		global $post;
		$meta_votes = get_post_meta( $post->ID, 'wn_post_votes', true );
		// Set to 0 if is not existed and update the votes count
		$votes = ( $meta_votes && is_numeric($meta_votes) && $meta_votes >= 0 ) ? $meta_votes : 0;

		return $votes;
	}
	
	/**
	 * Function for creating or modifying the post cookie
	 * Uses WordPress define cookie path and domain
	 * Cookie expired time is 5 years 
	 * @since 1.5
	**/
	function set_cookie( $post_id, $type = 'likes' ) {
		$cookie = array();
		if( isset( $_COOKIE["like_rating"] ) ) {
			$cookie = json_decode( stripslashes( $_COOKIE["like_rating"] ) );

			if( isset( $cookie->$type ) )
				array_push( $cookie->$type, $post_id );
			else
				$cookie->$type = array( $post_id );
						
		} else {
			$cookie[$type] = array( $post_id );
		}
		
		setcookie( 'like_rating', json_encode( $cookie ), time() + (5*365*24*60*60), COOKIEPATH, COOKIE_DOMAIN );
	}

	/**
	 * Get the current post ID and + 1 to the meta for counting
	 * using the get_post_meta and update_post_meta
	 * @return $content.
	 * @since 1.5
	**/
	function the_content( $content ) {
		
		// For a content text lower than the excerpt 
		if ( ! is_singular() )
			return $content;
			
		// Get the post ID
		global $post;
		
		$meta_views = get_post_meta( $post->ID, 'wn_post_views', true );
		$views = $meta_views ? $meta_views : 0;
		$views++;
		update_post_meta( $post->ID, 'wn_post_views', $views );

		return $content;
	}
	/**
	 * Get Post Views
	 */
	static function get_views() {
		global $post;
		$meta_views = get_post_meta( $post->ID, 'wn_post_views', true );
		// Set to 0 if is not existed and update the views count
		$views = $meta_views ? $meta_views : 0;

		return $views;
	}
}

new WN_LikeRating();

?>