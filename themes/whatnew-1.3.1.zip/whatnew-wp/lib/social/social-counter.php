<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class Social_Counter {
    
	/**
     * Delete transients.
     */
    public function delete_transients() {
        delete_transient( 'socialcountplus_counter' );
    }
    
    /**
     * Reset transients.
     */
    public function reset_transients() {
        $this->delete_transients();
        $this->update_transients();
    }
    
    public function update_transients() {
    	
		$facebook_id = wn_theme_setting( 'facebook_id' );
		
		$youtube_user = wn_theme_setting( 'youtube_user' );
		
		$googleplus_id = wn_theme_setting( 'googleplus_id' );
		
		$instagram_user_id = wn_theme_setting( 'instagram_user_id' );
		
		$instagram_access_token = wn_theme_setting( 'instagram_access_token' );
		
		$steam_group_name = wn_theme_setting( 'steam_group_name' );
		
		$soundcloud_username = wn_theme_setting( 'soundcloud_username' );
		
		$soundcloud_client_id = wn_theme_setting( 'soundcloud_client_id' );

    	// Get facebook data.
        $facebook_data = wp_remote_get( 'http://api.facebook.com/restserver.php?method=facebook.fql.query&query=SELECT%20fan_count%20FROM%20page%20WHERE%20page_id=' . $facebook_id );
       
		if ( is_wp_error( $facebook_data ) ) {
            $count['facebook'] = ( isset( $cache['facebook'] ) ) ? $cache['facebook'] : 0;
        } else {
            $facebook_xml = new SimpleXmlElement( $facebook_data['body'], LIBXML_NOCDATA );
            $facebook_count = (string) $facebook_xml->page->fan_count;

            if ( $facebook_count ) {
                $count['facebook'] = $facebook_count;
                $cache['facebook'] = $facebook_count;
            } else {
                $count['facebook'] = ( isset( $cache['facebook'] ) ) ? $cache['facebook'] : 0;
            }
        }
        
        // YouTube.
        if ( isset( $youtube_user ) && ! empty( $youtube_user ) ) {

            // Get youtube data.
            $youtube_data = wp_remote_get( 'http://gdata.youtube.com/feeds/api/users/' . $youtube_user );

            if ( is_wp_error( $youtube_data ) || '400' <= $youtube_data['response']['code'] ) {
                $count['youtube'] = ( isset( $cache['youtube'] ) ) ? $cache['youtube'] : 0;
            } else {
                $youtube_body = str_replace( 'yt:', '', $youtube_data['body'] );
                $youtube_xml = new SimpleXmlElement( $youtube_body, LIBXML_NOCDATA );
                $youtube_count = (string) $youtube_xml->statistics['subscriberCount'];

                if ( $youtube_count ) {
                    $count['youtube'] = $youtube_count;
                    $cache['youtube'] = $youtube_count;
                } else {
                    $count['youtube'] = ( isset( $cache['youtube'] ) ) ? $cache['youtube'] : 0;
                }
            }
        }
        
        if ( isset( $googleplus_id ) && ! empty( $googleplus_id ) ) {
            $googleplus_id = 'https://plus.google.com/' . $googleplus_id;

            $googleplus_data_params = array(
                'method'    => 'POST',
                'sslverify' => false,
                'timeout'   => 30,
                'headers'   => array( 'Content-Type' => 'application/json' ),
                'body'      => '[{"method":"pos.plusones.get","id":"p","params":{"nolog":true,"id":"' . $googleplus_id . '","source":"widget","userId":"@viewer","groupId":"@self"},"jsonrpc":"2.0","key":"p","apiVersion":"v1"}]'
            );

            // Get googleplus data.
            $googleplus_data = wp_remote_get( 'https://clients6.google.com/rpc', $googleplus_data_params );

            if ( is_wp_error( $googleplus_data ) || '400' <= $googleplus_data['response']['code'] ) {
                $count['googleplus'] = ( isset( $cache['googleplus'] ) ) ? $cache['googleplus'] : 0;
            } else {
                $googleplus_response = json_decode( $googleplus_data['body'], true );

                if ( isset( $googleplus_response[0]['result']['metadata']['globalCounts']['count'] ) ) {
                    $googleplus_count = $googleplus_response[0]['result']['metadata']['globalCounts']['count'];

                    $count['googleplus'] = $googleplus_count;
                    $cache['googleplus'] = $googleplus_count;
                } else {
                    $count['googleplus'] = ( isset( $cache['googleplus'] ) ) ? $cache['googleplus'] : 0;
                }
            }
        }
        
        // Instagram.
        if ( isset( $instagram_user_id ) && ! empty( $sinstagram_user_id ) && isset( $instagram_access_token ) && ! empty( $instagram_access_token ) ) {
            // Get googleplus data.
            $instagram_data = wp_remote_get( 'https://api.instagram.com/v1/users/' . $instagram_user_id . '/?access_token=' . $instagram_access_token );

            if ( is_wp_error( $instagram_data ) || '400' <= $instagram_data['response']['code'] ) {
                $count['instagram'] = ( isset( $cache['instagram'] ) ) ? $cache['instagram'] : 0;
            } else {
                $instagram_response = json_decode( $instagram_data['body'], true );

                if (
                    isset( $instagram_response['meta']['code'] )
                    && 200 == $instagram_response['meta']['code']
                    && isset( $instagram_response['data']['counts']['followed_by'] )
                ) {
                    $instagram_count = $instagram_response['data']['counts']['followed_by'];

                    $count['instagram'] = $instagram_count;
                    $cache['instagram'] = $instagram_count;
                } else {
                    $count['instagram'] = ( isset( $cache['instagram'] ) ) ? $cache['instagram'] : 0;
                }
            }
        }
        
        //Steam
        if ( isset( $steam_group_name ) && ! empty( $steam_group_name ) ) {

            // Get steam data.
            $steam_data = wp_remote_get( 'http://steamcommunity.com/groups/' . $steam_group_name . '/memberslistxml/?xml=1' );

            if ( is_wp_error( $steam_data ) || '400' <= $steam_data['response']['code'] ) {
                $count['steam'] = ( isset( $cache['steam'] ) ) ? $cache['steam'] : 0;
            } else {
                try {
                    $steam_xml = @new SimpleXmlElement( $steam_data['body'], LIBXML_NOCDATA );
                    $steam_count = (string) $steam_xml->groupDetails->memberCount;
                } catch (Exception $e) {
                    $steam_xml = ( isset( $cache['steam'] ) ) ? $cache['steam'] : 0;
                }

                if ( $steam_count ) {
                    $count['steam'] = $steam_count;
                    $cache['steam'] = $steam_count;
                } else {
                    $count['steam'] = ( isset( $cache['steam'] ) ) ? $cache['steam'] : 0;
                }
            }
        }
        
        //SoundCloud
        if ( isset( $soundcloud_username ) && ! empty( $soundcloud_username ) && isset( $soundcloud_client_id ) && ! empty( $soundcloud_client_id ) ) {
            // Get googleplus data.
            $soundcloud_data = wp_remote_get( 'http://api.soundcloud.com/users/' . $soundcloud_username . '.json?client_id=' . $soundcloud_client_id );

            if ( is_wp_error( $soundcloud_data ) || '400' <= $soundcloud_data['response']['code'] ) {
                $count['soundcloud'] = ( isset( $cache['soundcloud'] ) ) ? $cache['soundcloud'] : 0;
            } else {
                $soundcloud_response = json_decode( $soundcloud_data['body'], true );

                if ( isset( $soundcloud_response['followers_count'] ) ) {
                    $soundcloud_count = $soundcloud_response['followers_count'];

                    $count['soundcloud'] = $soundcloud_count;
                    $cache['soundcloud'] = $soundcloud_count;
                } else {
                    $count['soundcloud'] = ( isset( $cache['soundcloud'] ) ) ? $cache['soundcloud'] : 0;
                }
            }
        }
        
        //Posts
        $count_posts = wp_count_posts();

        if ( is_wp_error( $count_posts->publish ) ) {
            $count['posts'] = ( isset( $cache['posts'] ) ) ? $cache['posts'] : 0;;
        } else {
            $count['posts'] = $count_posts->publish;
            $cache['posts'] = $count_posts->publish;
        }
        
        //Comments
        $comments_count = wp_count_comments();

        if ( is_wp_error( $comments_count->approved ) ) {
            $count['comments'] = ( isset( $cache['comments'] ) ) ? $cache['comments'] : 0;;
        } else {
            $count['comments'] = $comments_count->approved;
            $cache['comments'] = $comments_count->approved;
        }
        
        // Update plugin extra cache.
        update_option( 'socialcountplus_cache', $cache );

        // Update counter transient.
        set_transient( 'socialcountplus_counter', $count, apply_filters( 'social_count_plus_transient_time', 60*60*24 ) ); // 24 hours.
        
        return $count;
    }
    
	
}

?>