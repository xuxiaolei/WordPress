<?php
function wn_register_sidebars() {
    global $NHP_Options;
    $sidebars = $NHP_Options->get( 'sidebars' );
    
    if(!empty($sidebars)) {
	    foreach ($sidebars as $id => $title ) {
	    	if(!empty($title)) {
		        register_sidebar( array(
		            'name'          => $title,
		            'id'            => 'custom-sidebar-'.$id,
		            'description'   => '',
		            'before_widget' => '<div id="%1$s" class="widget-container %2$s clearfix">',
		            'after_widget'  => '</div>',
		            'before_title'  => '<h4 class="widget-title">',
		            'after_title'   => '</h4>'
		
		        ));
	        }
	    }
    }

    register_sidebar( array(
            'name'          => __( '默认侧边栏', 'whatnew-theme' ),
            'id'            => 'sidebar-m',
            'description'   => __( '这是默认的侧边栏.', 'whatnew-theme' ),
            'before_widget' => '<div id="%1$s" class="widget-container %2$s clearfix">',
            'after_widget'  => '</div>',
            'before_title'  => '<h4 class="widget-title">',
            'after_title'   => '</h4>'

        ));

    register_sidebar( array(
            'name'          => __( '文章页侧边栏', 'whatnew-theme' ),
            'id'            => 'sidebar-single',
            'description'   => __( '这是文章页面默认侧边栏, 若没有任何小工具, 文章页将会自动调用默认侧边栏.', 'whatnew-theme' ),
            'before_widget' => '<div id="%1$s" class="widget-container %2$s clearfix">',
            'after_widget'  => '</div>',
            'before_title'  => '<h4 class="widget-title">',
            'after_title'   => '</h4>'

        ));

    register_sidebar( array(
            'name'          => __( '页脚边栏 - 左', 'whatnew-theme' ),
            'id'            => 'sidebar-footer-l',
            'description'   => __( '这是页脚左侧的侧边栏.', 'whatnew-theme' ),
            'before_widget' => '<div id="%1$s" class="widget-container %2$s clearfix">',
            'after_widget'  => '</div>',
            'before_title'  => '<h4 class="footer-widget-title">',
            'after_title'   => '</h4>'

        ));
        
    register_sidebar( array(
            'name'          => __( '页脚边栏 - 右', 'whatnew-theme' ),
            'id'            => 'sidebar-footer-r',
            'description'   => __( '这是页脚右侧的侧边栏.', 'whatnew-theme' ),
            'before_widget' => '<div id="%1$s" class="widget-container %2$s clearfix">',
            'after_widget'  => '</div>',
            'before_title'  => '<h4 class="footer-widget-title">',
            'after_title'   => '</h4>'

        ));
}
add_action('init', 'wn_register_sidebars');
?>