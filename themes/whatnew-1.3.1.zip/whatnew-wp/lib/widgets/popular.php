<?php

class WN_Popular extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {
		parent::__construct(
			'wn_popular', // Base ID
			__('WN - 热门文章', 'whatnew-theme'), // Name
			array( 'description' => __( '显示一列自定义参数的热门文章列表.', 'whatnew-theme' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	function widget( $args, $instance ) {
		//display settings
		extract( $args );
		$title        = apply_filters( 'widget_title', $instance['title'] );
		$exclude      = empty( $instance['exclude'] ) ? ''                : $instance['exclude'];
		$num          = empty( $instance['num'] )     ? '6'               : $instance['num'];
		$cats         = empty( $instance['cats'] )    ? ''                : $instance['cats'];
		$range        = empty( $instance['range'] )   ? 'daily'           : $instance['range'];
		$display_type = empty( $instance['display_type'] ) ? '1'   : $instance['display_type'];
		
		echo $before_widget;
		if ( $title ) {
			echo $before_title . $title . $after_title;
		}
		$week = date('W');
		$year = date('Y');
		$month = date('m');
		$query_str = '';
		switch ($range) {
			case 'yesterday':
				$this->filter_time_1days();
				$query_str = 'post_type=post&posts_per_page='.$num.'&order=DESC&orderby=comment_count&cat='.$cats;
				break;
			case 'last7':
				$this->filter_time_7days();
				$query_str = 'post_type=post&posts_per_page='.$num.'&order=DESC&orderby=comment_count&cat='.$cats;
				break;
			case 'weelky':
				$query_str = 'post_type=post&posts_per_page='.$num.'&order=DESC&orderby=comment_count&year='.$year.'&monthnum='.$month.'&cat='.$cats;
				break;
			case 'monthly':
				$query_str = 'post_type=post&posts_per_page='.$num.'&order=DESC&orderby=comment_count&year='.$year.'&w='.$week.'&cat='.$cats;
				break;
			case 'all':
			default:
				$query_str = 'post_type=post&posts_per_page='.$num.'&order=DESC&orderby=comment_count&cat='.$cats;
				break;
		}

		//global $post;
		//$temp_post = $post;
		query_posts( $query_str );
		?>
		<div class="popular-content">
			<ul class="popular-lists">
		<?php
		if(have_posts()):while(have_posts()): the_post();
			$review_score = wn_get_review_score(get_the_id());
			if($display_type == 1) {
		?>
				<li class="clearfix"> 
					<div class="popular-thumb1">
						<?php the_post_thumbnail( '80' ); ?>
						<?php if( $review_score ) : ?>
						<span class="small-review-score"><?php echo $review_score; ?></span>
						<?php endif; ?>
					</div>
					<div class="post-details">
						<span class="light-post-meta"><?php printf( __('%s at %s', 'whatnew-theme'), get_the_time(), get_the_date() ); ?></span>
						<h5 class="popular-post-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php echo wn_get_the_title('100'); ?></a></h5>
						<span class="comments"><i class="comment-icon"></i><?php comments_number( '0', '1', '%' ); ?></span>
					</div>
				</li>
		<?php
			}else {?>
				<li>
					<div class="popular-thumb">
						<?php the_post_thumbnail( '280x100' ); ?>
						<?php if( $review_score ) : ?>
						<span class="small-review-score"><?php echo $review_score; ?></span>
						<?php endif; ?>
					</div>
					<h5 class="popular-post-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php echo wn_get_the_title('60'); ?></a></h5>
					<div class="popular-meta">
						
						<span class="popular-date"><?php echo get_the_date(); ?></span>
						<span class="comments fr"><i class="comment-icon"></i><?php comments_number( '0', '1', '%' ); ?></span>
					</div>
				</li>
		<?php		
			}
		endwhile;endif;wp_reset_query();
		//$post = $temp_post;
		?>
			</ul>
		</div>
		<!-- END .rightnow-content -->
		<?php 
		echo $after_widget;
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	function form( $instance ) {
		$instance      = wp_parse_args( (array) $instance, array( 'title' => '', 'exclude' => '' ) );
		$title         = esc_attr( $instance['title'] );
		$num           = isset($instance['num'])     ? $instance['num']                 : '6'             ;
		$cats          = isset($instance['cats'])    ? $instance['cats']                : ''              ;
		$display_type  = ( isset( $instance[ 'display_type' ] ) )  ? $instance[ 'display_type' ]  : '1';
		$range         = isset($instance['range'])   ? esc_attr( $instance['range'] )   : 'daily'         ; ?>
		
		<p><label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( '标题:', 'whatnew-theme' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" /></p>
		<p><label for="<?php echo $this->get_field_id( 'num' ); ?>"><?php _e( '显示文章数:', 'whatnew-theme' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id( 'num' ); ?>" name="<?php echo $this->get_field_name( 'num' ); ?>" type="text" value="<?php echo $num; ?>" /></p>
		<p><label for="<?php echo $this->get_field_id( 'cats' ); ?>"><?php _e( '分类:', 'whatnew-theme' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id( 'cats' ); ?>" name="<?php echo $this->get_field_name( 'cats' ); ?>" type="text" value="<?php echo $cats; ?>" /><?php _e('<small>输入分类ID, 必须用英文逗号分隔.</small>','whatnew-theme'); ?></p>
		<p>
		<p>
		<label for="<?php echo $this->get_field_id( 'display_type' ); ?>"><?php _e( '文章布局:', 'whatnew-theme' ); ?></label> 
		<select id="<?php echo $this->get_field_id( 'display_type' ); ?>" name="<?php echo $this->get_field_name( 'display_type' ); ?>">
			<option value="1" <?php if($display_type=='1') echo 'selected="selected"'; ?>><?php _e('Type 1','whatnew-theme'); ?></option>
			<option value="2" <?php if($display_type=='2') echo 'selected="selected"'; ?>><?php _e('Type 2','whatnew-theme'); ?></option>
		</select>
		<small><?php _e('type 2 is best for small sidebar.','whatnew-theme'); ?></small>
		</p>
		<label for="<?php echo $this->get_field_id( 'range' ); ?>"><?php _e( '范围:', 'whatnew-theme' ); ?></label> 
		<select id="<?php echo $this->get_field_id( 'range' ); ?>" name="<?php echo $this->get_field_name( 'range' ); ?>">
			<option value="yesterday" <?php if($range=='yesterday') echo 'selected="selected"'; ?>>昨天</option>
			<option value="7day" <?php if($range=='7day') echo 'selected="selected"'; ?>>过去7天</option>
			<option value="weekly" <?php if($range=='weekly') echo 'selected="selected"'; ?>>过去一周</option>
			<option value="monthly" <?php if($range=='monthly') echo 'selected="selected"'; ?>>过去一月</option>
			<option value="all" <?php if($range=='all') echo 'selected="selected"'; ?>>所有时间</option>
		</select>
		</p>

	<?php
	}
	
	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title']        = strip_tags( $new_instance['title'] );
		$instance['num']          = strip_tags( $new_instance['num'] );
		$instance['cats']         = strip_tags( $new_instance['cats'] );
		$instance['display_type'] = ( isset( $new_instance[ 'display_type' ] ) )  ? $new_instance[ 'display_type' ]  : '1';
		$instance['range']        = ( ! empty( $new_instance['range'] ) )     ? strip_tags( $new_instance['range'] )     : 'daily';
		return $instance;
	}
	/**
	 *
	 */
	function filter_where_7days($where = '') {
	    //posts in the last 7 days
	    $where .= " AND post_date > '" . date('Y-m-d', strtotime('-7 days')) . "'";
	    return $where;
	}
	function filter_time_7days() {
		add_filter('posts_where', array( &$this,'filter_where_7days'));
	}
	function filter_where_1days($where = '') {
	    //posts in the last 1 days
	    $where .= " AND post_date > '" . date('Y-m-d', strtotime('-1 days')) . "'";
	    return $where;
	}
	function filter_time_1days() {
		add_filter('posts_where', array( &$this,'filter_where_7days'));
	}

}
?>