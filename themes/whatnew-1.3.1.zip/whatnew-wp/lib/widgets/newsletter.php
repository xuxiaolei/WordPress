<?php

class WN_Newsletter extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {
		parent::__construct(
			'wn_newsletter', // Base ID
			__('WN - 订阅', 'whatnew-theme'), // Name
			array( 'description' => __( '订阅本站资讯.', 'whatnew-theme' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	function widget( $args, $instance ) {
		//display settings
		extract( $args );
		$title      = apply_filters( 'widget_title', $instance['title'] );
		$desc       = empty( $instance['desc'] ) ? '' : esc_attr($instance['desc']);
		$fromtype   = empty( $instance['fromtype'] ) ? '' : $instance['fromtype'];
		$mailchimp  = empty( $instance['mailchimp'] ) ? '' : esc_attr($instance['mailchimp']);
		$feedburner = empty( $instance['feedburner'] ) ? '' : esc_attr($instance['feedburner']);
		
		echo $before_widget;
		echo '<div class="newsletter">';
		if ( $title ) {
			echo '<h4 class="newsletter-title">'. $title . '</h4>';
		}
		?>
		       <div class="newsletter-desc">
		       	<?php echo $desc;  ?>
		       </div>
		       <?php if($fromtype == 'mailchimp') { ?>
		       <form action="<?php echo esc_url($mailchimp); ?>" id="subscribe-form" method="post" target="_blank">
		           <input type="text" class="subs_input" name="EMAIL" id="footer-subscribe-email" placeholder="<?php  _e('你的邮箱地址','whatnew-theme'); ?>">
		           <input type="hidden" name="MERGE1" id="MERGE1" value="wddsidebar">   
		          
		             <input type="submit" class="subs_submit" value="<?php _e('订阅','whatnew-theme'); ?>">
		           
		           <div class="clear"></div>
		       
		       </form>
			   <?php }else{ ?>
			   <form action="http://feedburner.google.com/fb/a/mailverify" id="subscribe-form" method="post" target="_blank">
		           <input type="text" class="subs_input" name="email" placeholder="<?php  _e('你的邮箱地址','whatnew-theme'); ?>">
                    <input type="hidden" value="<?php echo $feedburner; ?>" name="uri"/>
                    <input type="hidden" name="loc" value="en_US"/>
                    <input type="submit" class="subs_submit" value="<?php _e('订阅','whatnew-theme'); ?>">
					<div class="clear"></div>
		       </form>
			   
			   <?php } ?>
		
		<?php 
		echo '</div>';
		echo $after_widget;
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	function form( $instance ) {
		
		$title      = ( !empty( $instance[ 'title' ] ) )       ? $instance[ 'title' ]       : '';
		$fromtype   = ( !empty( $instance[ 'fromtype' ] ) )    ? $instance[ 'fromtype' ]    : '';
		$mailchimp  = ( !empty( $instance[ 'mailchimp' ] ) )   ? $instance[ 'mailchimp' ]   : '';
		$feedburner = ( !empty( $instance[ 'feedburner' ] ) )  ? $instance[ 'feedburner' ]  : '';
		$desc       = ( !empty( $instance[ 'desc' ] ) )        ? $instance[ 'desc' ]        : '';
		?>
		<p><label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( '标题:', 'whatnew-theme' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" /></p>
		<p><label for="<?php echo $this->get_field_id( 'desc' ); ?>"><?php _e( '描述:', 'whatnew-theme' ); ?></label>
		<textarea class="widefat" id="<?php echo $this->get_field_id( 'desc' ); ?>" name="<?php echo $this->get_field_name( 'desc' ); ?>" rows="6"><?php echo $desc; ?></textarea></p>
		<p>
		<label for="<?php echo $this->get_field_id( 'fromtype' ); ?>"><?php _e( '类型:', 'whatnew-theme' ); ?></label> 
		<select id="<?php echo $this->get_field_id( 'fromtype' ); ?>" name="<?php echo $this->get_field_name( 'fromtype' ); ?>">
			<option value="mailchimp" <?php if($fromtype=='mailchimp') echo 'selected="selected"'; ?>>Mailchimp</option>
			<option value="feedburner" <?php if($fromtype=='feedburner') echo 'selected="selected"'; ?>>Feedburner</option>
		</select>
		</p>
		<p><label for="<?php echo $this->get_field_id( 'mailchimp' ); ?>"><?php _e( 'Mailchimp:', 'whatnew-theme' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id( 'mailchimp' ); ?>" name="<?php echo $this->get_field_name( 'mailchimp' ); ?>" type="text" value="<?php echo $mailchimp; ?>" />
			<?php _e('(你可以在 <a href="http://www.mailchimp.com" target="_blank">mailchimp.com</a> 得到你的mailchimp代码, 或者请看说明文档.)', 'whatnew-theme'); ?>
		</p>
		<p><label for="<?php echo $this->get_field_id( 'feedburner' ); ?>"><?php _e( 'Feedburner:', 'whatnew-theme' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id( 'feedburner' ); ?>" name="<?php echo $this->get_field_name( 'feedburner' ); ?>" type="text" value="<?php echo $feedburner; ?>" /></p>
		<?php
	}
	
	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title']             = strip_tags( $new_instance['title'] );
		$instance['fromtype']          = !empty($new_instance['fromtype']) ? $new_instance['fromtype'] : 'feedburner';
		$instance['desc']              = strip_tags( $new_instance['desc'] );
		$instance['feedburner']        = strip_tags( $new_instance['feedburner'] );
		$instance['mailchimp']         = strip_tags( $new_instance['mailchimp'] );
		return $instance;
	}

}


?>