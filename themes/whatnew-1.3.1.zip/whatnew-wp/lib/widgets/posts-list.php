<?php

class WN_Posts_List extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {
		parent::__construct(
			'wn_posts_list', // Base ID
			__('WN - 文章列表', 'whatnew-theme'), // Name
			array( 'description' => __( '显示一列自定义参数的文章列表.', 'whatnew-theme' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	function widget( $args, $instance ) {
		//display settings
		extract( $args );
		$title   = apply_filters( 'widget_title', $instance['title'] );
		$cats    = empty( $instance['cats'] )    ? ''     : $instance['cats'];
		$exclude = empty( $instance['exclude'] ) ? ''     : $instance['exclude'];
		$num     = empty( $instance['num'] )     ? '6'    : $instance['num'];
		$order   = empty( $instance['order'] )   ? 'desc' : $instance['order'];
		$orderby = empty( $instance['orderby'] ) ? 'id'   : $instance['orderby'];
		$exclude = empty( $instance['exclude'] ) ? ''     : $instance['exclude'];
		
		echo $before_widget;
		if ( $title ) {
			echo $before_title . $title . $after_title;
		}

		$the_args = array(
			'post_type' => 'post',
			'posts_per_page' => $num,
			'cat' => $cats,
			'order' => $order,
			'orderby' => $orderby,
			'exclude' => $exclude
		);

		if( in_array( $orderby, array('views', 'stars', 'likes') ) ) {
			$the_args['orderby'] = 'meta_value';
			$the_args['meta_key'] = 'wn_post_'.$orderby;
		}

		global $post;
		$temp_post = $post;
		$the_query = new WP_Query($the_args);
		?>
		<div class="rightnow-content">
			<ul class="rightnow-lists">
		<?php
		if($the_query->have_posts()):while($the_query->have_posts()): $the_query->the_post();
			setup_postdata( $post );
			$review_score = wn_get_review_score();
		?>
				<li class="clearfix"> 
					<div class="thumb">
						<?php the_post_thumbnail( '80' ); ?>
						<?php if( $review_score ) : ?>
						<span class="small-review-score"><?php echo $review_score; ?></span>
						<?php endif; ?>
					</div>
					<div class="post-details">
						<span class="light-post-meta"><?php printf( __('%s at %s', 'whatnew-theme'), get_the_time(), get_the_date() ); ?></span>
						<h5 class="rightnow-post-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php echo wn_get_the_title('120'); ?></a></h5>
						<?php if($orderby == 'stars') { ?>
						<span class="wn-rating"><span data-rate="<?php echo WN_LikeRating::get_stars(); ?>"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span></span></span>
						<?php }elseif($orderby == 'comments') { ?>
						<span class="comments"><i class="comment-icon"></i><?php comments_number( '0', '1', '%' ); ?></span>
						<?php }elseif($orderby == 'likes') { ?>
						<span class="likes"><i class="uk-icon-heart-empty"></i><?php echo WN_LikeRating::get_likes(); ?></span>
						<?php }elseif($orderby == 'views') { ?>
						<span class="views"><i class="view-icon"></i><?php echo WN_LikeRating::get_views(); ?></span>
						<?php } ?>
					</div>
				</li>
		<?php
			endwhile;endif;wp_reset_postdata();wp_reset_query();
			$post = $temp_post;
		?>
			</ul>
		</div>
		<!-- END .rightnow-content -->
		<?php 
		echo $after_widget;
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array( 'title' => '', 'exclude' => '' ) );
		$title    = esc_attr( $instance['title'] );
		$cats     = empty( $instance['cats'] )    ? ''                             : $instance['cats'];
		$num      = isset($instance['num'])     ? $instance['num']                 : '6'    ;
		$order    = isset($instance['order'])   ? esc_attr( $instance['order'] )   : 'desc' ;
		$orderby  = isset($instance['orderby']) ? esc_attr( $instance['orderby'] ) : 'id'   ;
		$exclude  = isset($instance['exclude']) ? esc_attr( $instance['exclude'] ) : ''     ; ?>
		
		<p><label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( '标题:', 'whatnew-theme' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" /></p>
		<p><label for="<?php echo $this->get_field_id( 'cats' ); ?>"><?php _e( '分类:', 'whatnew-theme' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id( 'cats' ); ?>" name="<?php echo $this->get_field_name( 'cats' ); ?>" type="text" value="<?php echo $cats; ?>" /><?php _e('<small>输入分类ID, 必须用英文逗号分隔.</small>','whatnew-theme'); ?></p>
		<p><label for="<?php echo $this->get_field_id( 'num' ); ?>"><?php _e( '文章显示数量:', 'whatnew-theme' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id( 'num' ); ?>" name="<?php echo $this->get_field_name( 'num' ); ?>" type="text" value="<?php echo $num; ?>" /></p>
		<p><label for="<?php echo $this->get_field_id( 'exclude' ); ?>"><?php _e( '排除:', 'whatnew-theme' ); ?></label>
		<input type="text" value="<?php echo $exclude; ?>" name="<?php echo $this->get_field_name( 'exclude' ); ?>" id="<?php echo $this->get_field_id( 'exclude' ); ?>" class="widefat" />
		<br />
		<small><?php _e( '输入文章ID, 必须用英文逗号分隔.', 'whatnew-theme' ); ?></small>
		</p>
		<p>
		<label for="<?php echo $this->get_field_id( 'order' ); ?>"><?php _e( '排序:', 'whatnew-theme' ); ?></label> 
		<select id="<?php echo $this->get_field_id( 'order' ); ?>" name="<?php echo $this->get_field_name( 'order' ); ?>">
			<option value="desc" <?php if($order=='desc') echo 'selected="selected"'; ?>>DESC</option>
			<option value="asc" <?php if($order=='asc') echo 'selected="selected"'; ?>>ASC</option>
		</select>
		</p>
		<p>
		<label for="<?php echo $this->get_field_id( 'orderby' ); ?>"><?php _e( '排序方法:', 'whatnew-theme' ); ?></label> 
		<select id="<?php echo $this->get_field_id( 'orderby' ); ?>" name="<?php echo $this->get_field_name( 'orderby' ); ?>">
			<option value="id" <?php if($orderby=='id') echo 'selected="selected"'; ?>>ID</option>
			<option value="title" <?php if($orderby=='title') echo 'selected="selected"'; ?>>标题</option>
			<option value="comment_count" <?php if($orderby=='comment_count') echo 'selected="selected"'; ?>>评论数</option>
			<option value="views" <?php if($orderby=='views') echo 'selected="selected"'; ?>>浏览量</option>
			<option value="likes" <?php if($orderby=='likes') echo 'selected="selected"'; ?>>喜欢量</option>
			<option value="stars" <?php if($orderby=='stars') echo 'selected="selected"'; ?>>评分</option>
		</select>
		</p>

	<?php
	}
	
	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title']     = strip_tags( $new_instance['title'] );
		$instance['cats']         = strip_tags( $new_instance['cats'] );
		$instance['exclude']   = strip_tags( $new_instance['exclude'] );
		$instance['num']       = strip_tags( $new_instance['num'] );
		$instance['order']     = ( ! empty( $new_instance['order'] ) )  ? strip_tags( $new_instance['order'] )  : 'desc';
		$instance['orderby']   = ( ! empty( $new_instance['orderby'] ) )   ? strip_tags( $new_instance['orderby'] )   : 'id';
		return $instance;
	}

}
?>