<?php

class WN_Footer_Logo extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {
		parent::__construct(
			'wn_footer_logo', // Base ID
			__('WN - 页脚LOGO (只能页脚显示使用)', 'whatnew-theme'), // Name
			array( 'description' => __( '在页脚显示一个LOGO', 'whatnew-theme' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	function widget( $args, $instance ) {
		extract( $args );
		// Init classes.
		//$social_counter = new Social_Counter();
		//$count = $social_counter->update_transients();
		
		echo $before_widget;
		?>
		<div class="footer-about">
			<div class="footer-logo">
					<img src="<?php echo wn_footer_logo();	?>" />
			</div>
		</div>
		<?php
		echo $after_widget;
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	function form( $instance ) {

	}
	
	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	function update( $new_instance, $old_instance ) {

	}

}


?>