<?php

class WN_Social_Counter extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {
		parent::__construct(
			'social_counter', // Base ID
			__('WN - 社交好友计数器', 'whatnew-theme'), // Name
			array( 'description' => __( '显示Twitter跟随者, Facebook好友, YouTube订阅人数, 站点文章数和总评论数.', 'whatnew-theme' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	function widget( $args, $instance ) {
		extract( $args );
		// Init classes.
		$social_counter = new Social_Counter();
		$count = $social_counter->update_transients();
		
		echo $before_widget;
		?>
			
		<ul class="social-counter-widget clearfix">
			<?php
				$sub = $link = '';
				foreach( $instance as $key => $value ) {
					$sub = $link = '';
					if($value) {
						
						switch($key) {
							case 'facebook':
								$sub = 'Likes';
								$link = 'http://www.facebook.com/'.wn_theme_setting('facebook_id');
								break;
							case 'googleplus':
								$sub = 'Followers';
								$link = 'http://plus.google.com/'.wn_theme_setting('googleplus_id');
								break;
							case 'instagram':
								$sub = 'Followers';
								$link = 'http://instagram.com/'.wn_theme_setting('instagram_username');
								break;
							case 'soundcloud':
								$sub = 'Followers';
								$link = 'http://soundcloud.com/'.wn_theme_setting('soundcloud_username');
								break;
							case 'youtube':
								$sub = 'Subscribers';
								$link = 'http://www.youtube.com/user/'.wn_theme_setting('youtube_user');
								break;
							case 'steam':
								$sub = 'Members';
								$link = 'http://steamcommunity.com/groups/'.wn_theme_setting('steam_group_name');
								break;
							case 'posts':
								$sub = 'Posts';
								break;
							case 'comments':
								$sub = 'Comments';
								break;
							default:
								$sub = 'Fans';
								break;
						}
					?>
					<li class="social-counter-<?php echo $key; ?>">
						<a href="<?php echo $link; ?>" target="_blank">
							<i class="social-icon social-icon-<?php echo $key; ?>"></i>
							<?php 
								$counter = $count[$key]; 
								$counter_text = '';
								$counter_text = $counter;
								if( $counter > 1000 ) {
									$counter_text = round($counter, 1) . 'k';
								}
							?>
							<span><?php echo $counter_text; ?></span>
							<small><?php echo $sub; ?></small>
						</a>
					</li>
					<?php
					}
				}
			?>			
			
		</ul>
		
		<?php
		echo $after_widget;
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	function form( $instance ) {
	
		$facebook    = ( !empty( $instance[ 'facebook' ] ) )    ? 1 : 0;
		$youtube     = ( !empty( $instance[ 'youtube' ] ) )     ? 1 : 0;
		$googleplus  = ( !empty( $instance[ 'googleplus' ] ) )  ? 1 : 0;
		$instagram   = ( !empty( $instance[ 'instagram' ] ) )   ? 1 : 0;
		$steam       = ( !empty( $instance[ 'steam' ] ) )       ? 1 : 0;
		$soundcloud  = ( !empty( $instance[ 'soundcloud' ] ) )  ? 1 : 0;
		$posts       = ( !empty( $instance[ 'posts' ] ) )       ? 1 : 0;
		$comments    = ( !empty( $instance[ 'comments' ] ) )    ? 1 : 0;
		?>
		<p>
		<label for="<?php echo $this->get_field_id( 'facebook' ); ?>"><?php _e( '显示facebook :', 'whatnew-theme' ); ?></label> 
		<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'facebook' ); ?>" name="<?php echo $this->get_field_name( 'facebook' );?>" <?php checked( $facebook ); ?> />
		</p>
		<p>
		<label for="<?php echo $this->get_field_id( 'youtube' ); ?>"><?php _e( '显示youtube :', 'whatnew-theme' ); ?></label> 
		<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'youtube' ); ?>" name="<?php echo $this->get_field_name( 'youtube' );?>" <?php checked( $youtube ); ?> />
		</p>
		<p>
		<label for="<?php echo $this->get_field_id( 'googleplus' ); ?>"><?php _e( '显示googleplus :', 'whatnew-theme' ); ?></label> 
		<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'googleplus' ); ?>" name="<?php echo $this->get_field_name( 'googleplus' );?>" <?php checked( $googleplus ); ?> />
		</p>
		<p>
		<label for="<?php echo $this->get_field_id( 'instagram' ); ?>"><?php _e( '显示instagram :', 'whatnew-theme' ); ?></label> 
		<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'instagram' ); ?>" name="<?php echo $this->get_field_name( 'instagram' );?>" <?php checked( $instagram ); ?> />
		</p>
		<p>
		<label for="<?php echo $this->get_field_id( 'steam' ); ?>"><?php _e( '显示steam :', 'whatnew-theme' ); ?></label> 
		<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'steam' ); ?>" name="<?php echo $this->get_field_name( 'steam' );?>" <?php checked( $steam ); ?> />
		</p>
		<p>
		<label for="<?php echo $this->get_field_id( 'soundcloud' ); ?>"><?php _e( '显示soundcloud :', 'whatnew-theme' ); ?></label> 
		<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'soundcloud' ); ?>" name="<?php echo $this->get_field_name( 'soundcloud' );?>" <?php checked( $soundcloud ); ?> />
		</p>
		<p>
		<label for="<?php echo $this->get_field_id( 'posts' ); ?>"><?php _e( '显示站点总文章数:', 'whatnew-theme' ); ?></label> 
		<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'posts' ); ?>" name="<?php echo $this->get_field_name( 'posts' );?>" <?php checked( $posts ); ?> />
		</p>
		<p>
		<label for="<?php echo $this->get_field_id( 'comments' ); ?>"><?php _e( '显示站点总评论数:', 'whatnew-theme' ); ?></label> 
		<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'comments' ); ?>" name="<?php echo $this->get_field_name( 'comments' );?>" <?php checked( $comments ); ?> />
		</p>
		<?php
	}
	
	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['facebook']    = ( !empty( $new_instance[ 'facebook' ] ) )    ? 1 : 0;
		$instance['youtube']     = ( !empty( $new_instance[ 'youtube' ] ) )     ? 1 : 0;
		$instance['googleplus']  = ( !empty( $new_instance[ 'googleplus' ] ) )  ? 1 : 0;
		$instance['instagram']  = ( !empty( $new_instance[ 'instagram' ] ) )   ? 1 : 0;
		$instance['steam']       = ( !empty( $new_instance[ 'steam' ] ) )       ? 1 : 0;
		$instance['soundcloud']  = ( !empty( $new_instance[ 'soundcloud' ] ) )  ? 1 : 0;
		$instance['posts']       = ( !empty( $new_instance[ 'posts' ] ) )       ? 1 : 0;
		$instance['comments']    = ( !empty( $new_instance[ 'comments' ] ) )    ? 1 : 0;
		return $instance;
	}

}


?>