<?php

include('header-weather.php');
include('category.php');
include('tags.php');
include('posts-list.php');
include('popular.php');
include('slider.php');
//include('social-counter.php'); //暂时不用
include('links.php');
include('footer-logo.php');
include('newsletter.php');
/**
 * Add span tag to post count of categories and archives widget
 */
function cats_widget_postcount_filter( $out ) {
	$out = str_replace( ' (', '<span class="count">(', $out );
	$out = str_replace( ')', ')</span>', $out );
	return $out;
}
add_filter( 'wp_list_categories', 'cats_widget_postcount_filter' );

function archives_widget_postcount_filter( $out ) {
	$out = str_replace( '&nbsp;(', '<span class="count">(', $out );
	$out = str_replace( ')', ')</span>', $out );
	return $out;
}
add_filter('get_archives_link', 'archives_widget_postcount_filter');


// register All widgets
function register_all_widget() {
    register_widget( 'Header_Weather' );
    register_widget( 'WN_Categories' );
    register_widget( 'WN_Tags' );
    register_widget( 'WN_Posts_List' );
    register_widget( 'WN_Popular' );
    register_widget( 'WN_Slider' );
    //register_widget( 'WN_Social_Counter' );
    register_widget( 'WN_Links' );
    register_widget( 'WN_Footer_Logo' );
    register_widget( 'WN_Newsletter' );
}
add_action( 'widgets_init', 'register_all_widget' );




?>