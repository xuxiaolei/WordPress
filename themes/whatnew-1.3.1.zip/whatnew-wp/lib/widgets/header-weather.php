<?php

class Header_Weather extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {

		parent::__construct(
			'weather_widget', // Base ID
			__('WN - 天气预报', 'whatnew-theme'), // Name
			array( 'description' => __( '显示本地天气预报的小工具', 'whatnew-theme' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	function widget( $args, $instance ) {
		$weather = $this->weather_forecast_helper( $_SERVER['REMOTE_ADDR'], $instance );
		if(!isset($weather['error'])) {
		?>
		<div class="header-weather clearfix">
			<div class="weather-report clearfix">
				<div class="weather-thumb">
					<img src="<?php echo IMGURL .'/weather/'. $weather['image'].'.png';?>" alt="">
				</div>
				<div class="weather-address"> 
					<small><?php _e('今日天气', 'whatnew-theme' );?></small>
					<b><?php echo $weather['country'].', '.$weather['city'];?></b>
				</div>
				<div class="weather-degree">
					<strong><?php echo $weather[$instance['temp_type']];?></strong>
				</div>
			</div>
		</div>
		<?php
		}else { 
			echo $weather['error'];
		}
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	function form( $instance ) {
		$temp_type = ( isset( $instance[ 'temp_type' ] ) ) ? $instance[ 'temp_type' ] : 'temp_C';
		$key_type  = ( isset( $instance[ 'key_type' ] ) )  ? $instance[ 'key_type' ]  : 'free';
		$api_key   = ( isset( $instance[ 'api_key' ] ) )   ? $instance[ 'api_key' ]   : '';
		?>
		<p>
		<label for="<?php echo $this->get_field_id( 'temp_type' ); ?>"><?php _e( '温度单位:', 'whatnew-theme' ); ?></label> 
		<select id="<?php echo $this->get_field_id( 'temp_type' ); ?>" name="<?php echo $this->get_field_name( 'temp_type' ); ?>">
			<option value="temp_C" <?php if($temp_type=='temp_C') echo 'selected="selected"'; ?>>C</option>
			<option value="temp_F" <?php if($temp_type=='temp_F') echo 'selected="selected"'; ?>>F</option>
		</select>
		</p>
		<p>
		<label for="<?php echo $this->get_field_id( 'key_type' ); ?>"><?php _e( 'API 密匙类型:', 'whatnew-theme' ); ?></label> 
		<select id="<?php echo $this->get_field_id( 'key_type' ); ?>" name="<?php echo $this->get_field_name( 'key_type' ); ?>">
			<option value="free" <?php if($key_type=='free') echo 'selected="selected"'; ?>>Free</option>
			<option value="premium" <?php if($key_type=='premium') echo 'selected="selected"'; ?>>Premium</option>
		</select>
		</p>
		<p>
		<label for="<?php echo $this->get_field_id( 'api_key' ); ?>"><?php _e( 'API 密匙:', 'whatnew-theme' ); ?></label>
		<textarea rows="7" cols="30" id="<?php echo $this->get_field_id( 'api_key' ); ?>" name="<?php echo $this->get_field_name( 'api_key' ); ?>"><?php echo esc_attr( $api_key ); ?></textarea>
			<p><?php _e('你可以在 <a href="http://www.worldweatheronline.com/" target="_blank">www.worldweatheronline.com</a> 免费注册一个API','whatnew-theme'); ?></p>
		</p>
		<?php

	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['temp_type'] = ( ! empty( $new_instance['temp_type'] ) ) ? strip_tags( $new_instance['temp_type'] ) : 'temp_C';
		$instance['key_type']  = ( ! empty( $new_instance['key_type'] ) )  ? strip_tags( $new_instance['key_type'] )  : 'free';
		$instance['api_key']   = ( ! empty( $new_instance['api_key'] ) )   ? strip_tags( $new_instance['api_key'] )   : '';
		return $instance;
	}

	function weather_forecast_helper( $ip, $instance ) {
		$whitelist = array('localhost', '127.0.0.1');
		$weather_api = $instance['api_key'];
		$weather_api_key_type = $instance['key_type'];
		if($weather_api) {
			if(!in_array($_SERVER['HTTP_HOST'], $whitelist)){
				$url = "http://www.geoplugin.net/json.gp?ip=".$ip;
				$result = json_response($url);

				if($result!=false) {
					$city = $result->geoplugin_city;
					$country = $result->geoplugin_countryName;
					
					$weatherResult = get_transient('weather_result_'.urlencode($city).'_'.urlencode($country));
					
					if($weatherResult==false) {
						$temperature = 'C';
						

						if($city) {
							if($weather_api_key_type=="premium") {
								$url = "http://api.worldweatheronline.com/premium/v1/weather.ashx?key=".$weather_api."&q=".urlencode($city).",".urlencode($country)."&num_of_days=1&includeLocation=yes&date=today&format=json";
							} else {
								$url = "http://api.worldweatheronline.com/free/v1/weather.ashx?key=".$weather_api."&q=".urlencode($city).",".urlencode($country)."&num_of_days=1&includeLocation=yes&date=today&format=json";
							}				
							$result = json_response($url);
						} else {
							if($weather_api_key_type=="premium") {
								$url = "http://api.worldweatheronline.com/premium/v1/weather.ashx?key=".$weather_api."&q=".$ip."&num_of_days=1&includeLocation=yes&date=today&format=json";
							} else {
								$url = "http://api.worldweatheronline.com/free/v1/weather.ashx?key=".$weather_api."&q=".$ip."&num_of_days=1&includeLocation=yes&date=today&format=json";
							}
							$result = json_response($url);
						}
					
						if($result!=false) {
							$weather = array();

				
							$weather['temp_F'] = $result->data->current_condition[0]->temp_F;	
							$weather['temp_C'] = $result->data->current_condition[0]->temp_C;
							
							// add + before 
							$weather['temp_F'] = intval($weather['temp_F']);
							if($weather['temp_F']>0) {
								$weather['temp_F'] = "+".$weather['temp_F'];
							} else {
								$weather['temp_F'];
							}				

							// add + before 
							$weather['temp_C'] = intval($weather['temp_C']);
							if($weather['temp_C']>0) {
								$weather['temp_C'] = "+".$weather['temp_C'];
							} else {
								$weather['temp_C'];
							}

							$weather['temp_F'] = $weather['temp_F'].' F';
							$weather['temp_C'] = $weather['temp_C'].' C';

							$weatherCode = $result->data->current_condition[0]->weatherCode;
							$weather['city'] = $result->data->nearest_area[0]->areaName[0]->value;
							$weather['country'] = $result->data->nearest_area[0]->country[0]->value;


							switch ($weatherCode) {
								case '395':
								case '392':
								case '371':
								case '368':
								case '350':
								case '338':
								case '335':
								case '332':
								case '329':
								case '326':
								case '323':
								case '320':
								case '317':
								case '284':
								case '281':
								case '266':
								case '263':
								case '230':
								case '227':
									$weather['image'] = "weather-snow";
									break;
								case '389':
								case '386':
								case '200':
									$weather['image'] = "weather-thunder";
									break;
								case '377':
								case '374':
								case '365':
								case '362':
								case '359':
								case '356':
								case '353':
								case '314':
								case '311':
								case '308':
								case '305':
								case '302':
								case '299':
								case '296':
								case '293':
								case '185':
								case '179':
								case '176':
									$weather['image'] = "weather-rain";
									break;
								case '260':
								case '248':
								case '143':
								case '122':
								case '119':
									$weather['image'] = "weather-cloudy";
									break;
								case '116':
									$weather['image'] = "weather-clouds";
									break;
								case '113':
									$weather['image'] = "weather-sun";
									break;
								case '182':
									$weather['image'] = "weather-sleet";
									break;
								default:
									$weather['image'] = "weather-default";
									break;
							}

							set_transient( 'weather_result_'.urlencode($city).'_'.urlencode($country), $weather, 3600 );
						} else {
							$weather['error'] = __("Something went wrong with the connection!",'whatnew-theme');
						}
					} else {
						$weather = get_transient('weather_result_'.urlencode($city).'_'.urlencode($country));
					}
				} else {
					$weather['error'] = __("Something went wrong with the connection!",'whatnew-theme');
				}
			} else {
				$weather['error'] = __("This option doesn't work on localhost!",'whatnew-theme');
			}
		} else {

			$weather['error'] = __("Please set up your API key!",'whatnew-theme');

		}
		return $weather;
	}

}


if ( ! function_exists( 'json_response' ) )	{

	function json_response( $url )	{
			$args = array(
				 'timeout' => '10',
				 'redirection' => '10',
				 'sslverify' => false // for localhost
			);
			
			# Parse the given url
			$raw = wp_remote_get( $url, $args );
			
			if (!isset($raw->errors) && $raw['body']) {	
				$decoded = json_decode( $raw['body'] );
				return $decoded;
			} else {
				return false;	
			}
	}

}
?>