<?php

class WN_Tags extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {
		parent::__construct(
			'wn_tags', // Base ID
			__('WN - 标签', 'whatnew-theme'), // Name
			array( 'description' => __( '显示一个自定义显示效果的标签列表.', 'whatnew-theme' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	function widget( $args, $instance ) {
		//display settings
		extract( $args );
		$title = apply_filters( 'widget_title', empty( $instance['title'] ) ? __( '标签', 'whatnew-theme' ) : $instance['title'] );
		$count = ! empty( $instance['count'] ) ? '1' : '0';
		$number = ! empty( $instance['number'] ) ? $instance['number'] : 999;
		echo $before_widget;
		if ( $title ) {
			echo $before_title . $title . $after_title;
		}
		$args = array('number' => $number );
		$tags = get_tags($args);
		$html = '<ul class="post-tags tags blue">';
		foreach ( $tags as $tag ) {
			$tag_link = get_tag_link( $tag->term_id );
					
			$html .= "<li><a href='{$tag_link}' title='{$tag->name} Tag' class='{$tag->slug}'>";
			$html .= "{$tag->name}</a>";
			if($count) {
				$html .= "<span>{$tag->count}</span></li>";
			}
		}
		$html .= '</ul>';
		echo $html;

		echo $after_widget;
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array( 'title' => '', 'count' => '0', 'number' => 999 ) );
		$title = esc_attr( $instance['title'] );
		$number = ( isset( $instance[ 'number' ] ) ) ? $instance[ 'number' ] : 999;
		$count = ( isset( $instance[ 'count' ] ) ) ? (bool) $instance[ 'count' ] : false;
	?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( '标题:', 'whatnew-theme' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'number' ); ?>"><?php _e( '标签显示数量:', 'whatnew-theme' ); ?></label>
			<input type="text" class="text" id="<?php echo $this->get_field_id( 'number' ); ?>" name="<?php echo $this->get_field_name( 'number' ); ?>" value="<?php echo $number; ?>" />
		</p>
		<p>
			<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'count' ); ?>" name="<?php echo $this->get_field_name( 'count' ); ?>"<?php checked( $count ); ?> />
			<label for="<?php echo $this->get_field_id( 'count' ); ?>"><?php _e( '显示标签下的文章数量', 'whatnew-theme' ); ?></label><br />
		</p>
	<?php
	}
	
	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['number'] = ! empty( $new_instance['number'] ) ? $new_instance['number'] : 999;
		$instance['count'] = ! empty( $new_instance['count'] ) ? 1 : 0;
		return $instance;
	}

}	


?>