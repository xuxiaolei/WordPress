<?php

class WN_Categories extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {
		parent::__construct(
			'wn_categories', // Base ID
			__('WN - 文章分类', 'whatnew-theme'), // Name
			array( 'description' => __( '显示一个自定义选项的文章分类列表.', 'whatnew-theme' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	function widget( $args, $instance ) {
		//display settings
		extract( $args );
		$title = apply_filters( 'widget_title', empty( $instance['title'] ) ? __( 'Categories', 'whatnew-theme' ) : $instance['title'] );
		$exclude = empty( $instance['exclude'] ) ? '' : $instance['exclude'];
		$c = ! empty( $instance['count'] ) ? '1' : '0';
		$h = ! empty( $instance['hierarchical'] ) ? '1' : '0';

		echo $before_widget;
		if ( $title ) {
			echo $before_title . $title . $after_title;
		}
		//here we go!
		$cat_args = array(
			'orderby'		=> 'name',
			'exclude'		=> $exclude,
			'show_count'	=> $c,
			'hierarchical'	=> $h
		);
		?>
		<ul class="category-lists clearfix">
			<?php
            $cat_args['title_li'] = '';
            wp_list_categories( $cat_args );
            ?>
		</ul>
		<?php
		echo $after_widget;
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	function form( $instance ) {

		$instance = wp_parse_args( (array) $instance, array( 'title' => '', 'exclude' => '' ) );
		$title = esc_attr( $instance['title'] );
		$count = isset($instance['count']) ? (bool) $instance['count'] :false;
		$hierarchical = isset( $instance['hierarchical'] ) ? (bool) $instance['hierarchical'] : false;
		$exclude = esc_attr( $instance['exclude'] );?>
		<p><label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( '标题:', 'whatnew-theme' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" /></p>
		<p><label for="<?php echo $this->get_field_id( 'exclude' ); ?>"><?php _e( '排除:', 'whatnew-theme' ); ?></label>
		<input type="text" value="<?php echo $exclude; ?>" name="<?php echo $this->get_field_name( 'exclude' ); ?>" id="<?php echo $this->get_field_id( 'exclude' ); ?>" class="widefat" />
		<br />
		<small><?php _e( '请输入文章分类的ID, 必须用英文逗号分隔.', 'whatnew-theme' ); ?></small>
		</p>
		<p>
		<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'count' ); ?>" name="<?php echo $this->get_field_name( 'count' ); ?>"<?php checked( $count ); ?> />
		<label for="<?php echo $this->get_field_id( 'count' ); ?>"><?php _e( '显示分类下得文章数目', 'whatnew-theme' ); ?></label><br />

		<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'hierarchical' ); ?>" name="<?php echo $this->get_field_name( 'hierarchical' ); ?>"<?php checked( $hierarchical ); ?> />
		<label for="<?php echo $this->get_field_id('hierarchical'); ?>"><?php _e( '显示阶层关系', 'whatnew-theme' ); ?></label>
		</p>

	<?php
	}
	
	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title']        = strip_tags( $new_instance['title'] );
		$instance['count']        = ! empty( $new_instance['count'] ) ? 1 : 0;
		$instance['hierarchical'] = ! empty( $new_instance['hierarchical'] ) ? 1 : 0;
		$instance['exclude']      = strip_tags( $new_instance['exclude'] );
		return $instance;
	}

}


?>