<?php

class WN_Footer_Social extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {
		parent::__construct(
			'wn_footer_social', // Base ID
			__('WN - 社交图标链接 (只能页脚显示使用)', 'whatnew-theme'), // Name
			array( 'description' => __( '显示站点的社交图片链接', 'whatnew-theme' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	function widget( $args, $instance ) {
		extract( $args );
		// Init classes.
		//$social_counter = new Social_Counter();
		//$count = $social_counter->update_transients();
		
		echo $before_widget;
		?>
		<div class="footer-about">
			<div class="footer-logo">
					<img src="<?php echo wn_footer_logo();	?>" />
			</div>
			<div class="footer-social clearfix">
				<?php
				$link = '';
				foreach( $instance as $key => $value ) {
					$link = '';
					if($value) {
						
						switch($key) {
							case 'facebook':
								$link = 'http://www.facebook.com/'.wn_theme_setting('facebook_id');
								break;
							case 'googleplus':
								$link = 'http://plus.google.com/'.wn_theme_setting('googleplus_id');
								break;
							case 'instagram':
								$link = 'http://instagram.com/'.wn_theme_setting('instagram_username');
								break;
							case 'soundcloud':
								$link = 'http://soundcloud.com/'.wn_theme_setting('soundcloud_username');
								break;
							case 'youtube':
								$link = 'http://www.youtube.com/user/'.wn_theme_setting('youtube_user');
								break;
							case 'steam':
								$link = 'http://steamcommunity.com/groups/'.wn_theme_setting('steam_group_name');
								break;
							default:
								break;
						}
					?>
					<span class="social-icon-wrapper">
						<a href="<?php echo $link; ?>"><i class="social-icon social-icon-<?php echo $key; ?>"></i></a>
					</span>
					
					<?php
					}
				}
				?>
			</div>
		</div>
		<?php
		echo $after_widget;
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	function form( $instance ) {
		$facebook    = ( !empty( $instance[ 'facebook' ] ) )    ? 1 : 0;
		$youtube     = ( !empty( $instance[ 'youtube' ] ) )     ? 1 : 0;
		$googleplus  = ( !empty( $instance[ 'googleplus' ] ) )  ? 1 : 0;
		$instagram   = ( !empty( $instance[ 'instagram' ] ) )   ? 1 : 0;
		$steam       = ( !empty( $instance[ 'steam' ] ) )       ? 1 : 0;
		$soundcloud  = ( !empty( $instance[ 'soundcloud' ] ) )  ? 1 : 0;
		?>
		<p>
		<label for="<?php echo $this->get_field_id( 'facebook' ); ?>"><?php _e( 'Show facebook :', 'whatnew-theme' ); ?></label> 
		<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'facebook' ); ?>" name="<?php echo $this->get_field_name( 'facebook' );?>" <?php checked( $facebook ); ?> />
		</p>
		<p>
		<label for="<?php echo $this->get_field_id( 'youtube' ); ?>"><?php _e( 'Show youtube :', 'whatnew-theme' ); ?></label> 
		<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'youtube' ); ?>" name="<?php echo $this->get_field_name( 'youtube' );?>" <?php checked( $youtube ); ?> />
		</p>
		<p>
		<label for="<?php echo $this->get_field_id( 'googleplus' ); ?>"><?php _e( 'Show googleplus :', 'whatnew-theme' ); ?></label> 
		<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'googleplus' ); ?>" name="<?php echo $this->get_field_name( 'googleplus' );?>" <?php checked( $googleplus ); ?> />
		</p>
		<p>
		<label for="<?php echo $this->get_field_id( 'instagram' ); ?>"><?php _e( 'Show instagram :', 'whatnew-theme' ); ?></label> 
		<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'instagram' ); ?>" name="<?php echo $this->get_field_name( 'instagram' );?>" <?php checked( $instagram ); ?> />
		</p>
		<p>
		<label for="<?php echo $this->get_field_id( 'steam' ); ?>"><?php _e( 'Show steam :', 'whatnew-theme' ); ?></label> 
		<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'steam' ); ?>" name="<?php echo $this->get_field_name( 'steam' );?>" <?php checked( $steam ); ?> />
		</p>
		<p>
		<label for="<?php echo $this->get_field_id( 'soundcloud' ); ?>"><?php _e( 'Show soundcloud :', 'whatnew-theme' ); ?></label> 
		<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'soundcloud' ); ?>" name="<?php echo $this->get_field_name( 'soundcloud' );?>" <?php checked( $soundcloud ); ?> />
		</p>
		<?php
	}
	
	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['facebook']    = ( !empty( $new_instance[ 'facebook' ] ) )    ? 1 : 0;
		$instance['youtube']     = ( !empty( $new_instance[ 'youtube' ] ) )     ? 1 : 0;
		$instance['googleplus']  = ( !empty( $new_instance[ 'googleplus' ] ) )  ? 1 : 0;
		$instance['instagram']  = ( !empty( $new_instance[ 'instagram' ] ) )   ? 1 : 0;
		$instance['steam']       = ( !empty( $new_instance[ 'steam' ] ) )       ? 1 : 0;
		$instance['soundcloud']  = ( !empty( $new_instance[ 'soundcloud' ] ) )  ? 1 : 0;
		return $instance;
	}

}


?>