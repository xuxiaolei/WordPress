<?php

class WN_Links extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {
		parent::__construct(
			'wn_links', // Base ID
			__('WN - 链接 (只能在页脚边栏使用)', 'whatnew-theme'), // Name
			array( 'description' => __( '在页脚左侧显示一列自定义链接.', 'whatnew-theme' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	function widget( $args, $instance ) {
		//display settings
		extract( $args );
		$title = $instance['title'];
		
		echo $before_widget;
		if ( $title ) {
			echo $before_title . '<span class="footer-links-title">' .$title . '</span>' . $after_title;
		}
		?>
			<div class="footer-link">
				<ul>
					<?php for($i=1;$i<7;$i++) { 
						if(!empty($instance['link_'.$i.'_title'])) {
					?>
		
					<li><a href="<?php echo $instance['link_'.$i] ?>" target="_blank"><?php echo $instance['link_'.$i.'_title']; ?></a></li>
					<?php }} ?>
				</ul>
			</div>
			<!-- END .footer-link -->
		<?php
		echo $after_widget;
		
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	function form( $instance ) {
		$title        = isset( $instance['title'] )		   ? esc_attr( $instance['title']) : '';
		$link_1_title = isset( $instance['link_1_title'] )? esc_attr( $instance['link_1_title']) : '';
		$link_2_title = isset( $instance['link_2_title'] )? esc_attr( $instance['link_2_title']) : '';
		$link_3_title = isset( $instance['link_3_title'] )? esc_attr( $instance['link_3_title']) : '';
		$link_4_title = isset( $instance['link_4_title'] )? esc_attr( $instance['link_4_title']) : '';
		$link_5_title = isset( $instance['link_5_title'] )? esc_attr( $instance['link_5_title']) : '';
		$link_6_title = isset( $instance['link_6_title'] )? esc_attr( $instance['link_6_title']) : '';
		$link_1 = isset($instance['link_1']) ? $instance['link_1'] : '';
		$link_2 = isset($instance['link_2']) ? $instance['link_2'] : '';
		$link_3 = isset($instance['link_3']) ? $instance['link_3'] : '';
		$link_4 = isset($instance['link_4']) ? $instance['link_4'] : '';
		$link_5 = isset($instance['link_5']) ? $instance['link_5'] : '';
		$link_6 = isset($instance['link_6']) ? $instance['link_6'] : '';
		
		?>
		<div class="links-widget">
		<p><label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( '标题:', 'whatnew-theme' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" /></p>
		<p>
			<label for="<?php echo $this->get_field_id( 'link_1_title' ); ?>"><?php _e( '链接标题1:', 'whatnew-theme' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'link_1_title' ); ?>" name="<?php echo $this->get_field_name( 'link_1_title' ); ?>" type="text" value="<?php echo $link_1_title; ?>" />
			<label for="<?php echo $this->get_field_id( 'link_1' ); ?>"><?php _e( '链接1:', 'whatnew-theme' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'link_1' ); ?>" name="<?php echo $this->get_field_name( 'link_1' ); ?>" type="text" value="<?php echo $link_1; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'link_2_title' ); ?>"><?php _e( '链接标题2:', 'whatnew-theme' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'link_2_title' ); ?>" name="<?php echo $this->get_field_name( 'link_2_title' ); ?>" type="text" value="<?php echo $link_2_title; ?>" />
			<label for="<?php echo $this->get_field_id( 'link_2' ); ?>"><?php _e( '链接2:', 'whatnew-theme' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'link_2' ); ?>" name="<?php echo $this->get_field_name( 'link_2' ); ?>" type="text" value="<?php echo $link_2; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'link_3_title' ); ?>"><?php _e( '链接标题3:', 'whatnew-theme' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'link_3_title' ); ?>" name="<?php echo $this->get_field_name( 'link_3_title' ); ?>" type="text" value="<?php echo $link_3_title; ?>" />
			<label for="<?php echo $this->get_field_id( 'link_3' ); ?>"><?php _e( '链接3:', 'whatnew-theme' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'link_3' ); ?>" name="<?php echo $this->get_field_name( 'link_3' ); ?>" type="text" value="<?php echo $link_3; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'link_4_title' ); ?>"><?php _e( '链接标题4:', 'whatnew-theme' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'link_4_title' ); ?>" name="<?php echo $this->get_field_name( 'link_4_title' ); ?>" type="text" value="<?php echo $link_4_title; ?>" />
			<label for="<?php echo $this->get_field_id( 'link_4' ); ?>"><?php _e( '链接4:', 'whatnew-theme' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'link_4' ); ?>" name="<?php echo $this->get_field_name( 'link_4' ); ?>" type="text" value="<?php echo $link_4; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'link_5_title' ); ?>"><?php _e( '链接标题5:', 'whatnew-theme' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'link_5_title' ); ?>" name="<?php echo $this->get_field_name( 'link_5_title' ); ?>" type="text" value="<?php echo $link_5_title; ?>" />
			<label for="<?php echo $this->get_field_id( 'link_5' ); ?>"><?php _e( '链接5:', 'whatnew-theme' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'link_5' ); ?>" name="<?php echo $this->get_field_name( 'link_5' ); ?>" type="text" value="<?php echo $link_5; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'link_6_title' ); ?>"><?php _e( '链接标题6:', 'whatnew-theme' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'link_6_title' ); ?>" name="<?php echo $this->get_field_name( 'link_6_title' ); ?>" type="text" value="<?php echo $link_6_title; ?>" />
			<label for="<?php echo $this->get_field_id( 'link_6' ); ?>"><?php _e( '链接6:', 'whatnew-theme' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'link_6' ); ?>" name="<?php echo $this->get_field_name( 'link_6' ); ?>" type="text" value="<?php echo $link_6; ?>" />
		</p>
		</div>
		<?php
	}
	
	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title']        = strip_tags( $new_instance['title'] );
		$instance['link_1_title'] = strip_tags( $new_instance['link_1_title'] );
		$instance['link_2_title'] = strip_tags( $new_instance['link_2_title'] );
		$instance['link_3_title'] = strip_tags( $new_instance['link_3_title'] );
		$instance['link_4_title'] = strip_tags( $new_instance['link_4_title'] );
		$instance['link_5_title'] = strip_tags( $new_instance['link_5_title'] );
		$instance['link_6_title'] = strip_tags( $new_instance['link_6_title'] );
		$instance['link_1'] = ! empty($new_instance['link_1']) ? $new_instance['link_1'] : '';
		$instance['link_2'] = ! empty($new_instance['link_2']) ? $new_instance['link_2'] : '';
		$instance['link_3'] = ! empty($new_instance['link_3']) ? $new_instance['link_3'] : '';
		$instance['link_4'] = ! empty($new_instance['link_4']) ? $new_instance['link_4'] : '';
		$instance['link_5'] = ! empty($new_instance['link_5']) ? $new_instance['link_5'] : '';
		$instance['link_6'] = ! empty($new_instance['link_6']) ? $new_instance['link_6'] : '';
		return $instance;
	}

}


?>