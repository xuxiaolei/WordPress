<?php
#-----------------------------------------------------------------
# Blog Posts
#-----------------------------------------------------------------

/**
 * Insert Posts for page
 */
function wn_blog_posts_sc( $atts, $content='' ) {

	global $post,$paged;
	
	extract( shortcode_atts( array(
        'show_title' => true,
		'title' => '',
		'title_bg_color' => '#00b7ee',
		'sub_title' => '',
		'post_type' => 'post',
		'cats' => '',
		'authors' => '',
        'posts_per_page' => get_option( 'posts_per_page' ),
        'exclude' => '',
        'orderby' => 'ID',
        'order' => 'DESC',
        'type' => 1,
        'show_paging' => false
	), $atts ) );

	$args = array(
		'post_type' => $post_type,
		'posts_per_page' => $posts_per_page,
		'order' => $order,
		'orderby' => $orderby,
		'ignore_sticky_posts' => false
	);

	//some args check
	if($show_title == 'false') {
		$show_title = false;
	}
	if($show_paging == 'false') {
		$show_paging = false;
	}
	if($exclude!=''){
        //$exclude= explode(',',$exclude);
        $args['post__not_in'] = $exclude;
    }
    
    if($authors!=''){
       // $authors = explode(',',$authors);
        $args['author'] = $authors;
    }
    
    if($cats!=''){
        //$cats = explode(',',$cats);
        $args['cat'] = $cats;
    }
    if( in_array( $orderby, array('views', 'stars', 'likes') ) ) {
		$args['orderby'] = 'meta_value';
		$args['meta_key'] = 'wn_post_'.$orderby;
	}

    $page_num = 1;
 	if( $show_paging == true ){
        if($paged>0){
             $page_num =  $paged;
        }else{
        	if(get_query_var('paged')) {
        		$page_num  = $paged = get_query_var( 'paged');

        	}elseif(get_query_var( 'page')) {
        		$page_num  = $paged = get_query_var( 'page');
        	}else {
        		$page_num  = $paged = 1;
        	}
        }
        // try get page if page <=1
        if($page_num<=1){
            $page_num = $paged = 1;
        }
    }  
    if($page_num<=0){
         $page_num = 1;
    }
    $args['paged'] =  $page_num;

	//post show type
	$grid = false;
	$display_type = 'classic-list';
	switch( $type ) {
		case '1':
			$display_type = 'classic-list';
			break;
		case '2':
			$display_type = 'col2-list';
			$grid = true;
			break;
		case '3':
			$display_type = 'col3-list';
			$grid = true;
			break;
		case '4':
			$display_type = 'small-list';
			$grid = true;
			break;
		default:
			$display_type = 'classic-list';
			break;
	}
    /** Start The Posts Loop **/
    ?>
    <section id="<?php echo $display_type ;?>" class="posts-box">
    	<?php if($show_title): ?>
		<header class="box-header clearfix">
			<h4 class="box-title"><span class="bc" style="background-color:<?php echo $title_bg_color; ?>"><?php echo esc_html($title); ?></span><?php echo esc_html($sub_title); ?></h4>
		</header>
		<?php endif ?>
		<div class="<?php echo $display_type.'s';?> clearfix">
		<?php if($grid){ echo '<div class="row">'; } ?>
		<?php
	    // The Query
		$the_query = new WP_Query( $args );

		// The Loop
		$temp_post = $post;//temp global $post fore later recover

		if ( $the_query->have_posts() ) :
			while ( $the_query->have_posts() ) : $the_query->the_post();
				setup_postdata($post);
				get_template_part( 'templates/loop/' . $display_type, '' );
			endwhile;
		else :
			// no posts found
		endif;

		// Restore original Post Data
		wp_reset_postdata();wp_reset_query();
		$post = $temp_post;
		?>
		</div>
		<?php if($grid){ echo '</div>'; } ?>
		<nav role="navigation" id="nav-below" class="navigation-paging">
			<?php  
				if($show_paging) {
					wp_pagenavi(array( 'query' => $the_query ));
				}
			?>
		</nav>
	</section>
	<!-- END .posts-box -->
	<?php
	/** END The Posts Loop **/
}
add_shortcode( 'insert_posts', 'wn_blog_posts_sc' );

/**
 * Carousel
 */
function wn_carousel_sc( $atts, $content='' ) {
	global $post,$paged;
	$rand_id = rand(1,100);
	extract( shortcode_atts( array(
        'show_title' => true,
		'title' => '',
		'title_bg_color' => '#00b7ee',
		'sub_title' => '',
		'post_type' => 'post',
		'cats' => '',
		'authors' => '',
        'posts_per_page' => get_option( 'posts_per_page' ),
        'exclude' => '',
        'orderby' => 'ID',
        'order' => 'DESC'
	), $atts ) );

	$args = array(
		'post_type' => $post_type,
		'posts_per_page' => $posts_per_page,
		'order' => $order,
		'orderby' => $orderby,
		'ignore_sticky_posts' => false
	);
	if( in_array( $orderby, array('views', 'stars', 'likes') ) ) {
		$args['orderby'] = 'meta_value';
		$args['meta_key'] = 'wn_post_'.$orderby;
	}
	//some args check
	if($show_title == 'false') {
		$show_title = false;
	}
	if($exclude!=''){
        //$exclude= explode(',',$exclude);
        $args['post__not_in'] = $exclude;
    }
    
    if($authors!=''){
       // $authors = explode(',',$authors);
        $args['author'] = $authors;
    }
    
    if($cats!=''){
        //$cats = explode(',',$cats);
        $args['cat'] = $cats;
    }

    /** Start The Posts Loop **/
    ?>
    <section id="carousel-posts-<?php echo $rand_id; ?>" class="posts-box">
    	<?php if($show_title): ?>
		<header class="box-header clearfix">
			<h4 class="box-title"><span class="bc" style="background-color:<?php echo $title_bg_color; ?>"><?php echo esc_html($title); ?></span><?php echo esc_html($sub_title); ?></h4>
			<div id="carousel-controls" class="carousel-controls">
				<a class="carousel-prev">Prev</a>
				<a class="carousel-next">Next</a>
			</div>
		</header>
		<?php endif ?>
		<div class="carousel-posts-outer-wrapper">
			<div class="carousel-posts clearfix">
				<div class="slides">
			<?php
		    // The Query
			$the_query = new WP_Query( $args );
	
			// The Loop
			$temp_post = $post;//temp global $post fore later recover
	
			if ( $the_query->have_posts() ) :
				while ( $the_query->have_posts() ) : $the_query->the_post();
					setup_postdata($post);
					$review_score = wn_get_review_score();
					?>
					<article id="article" class="carousel-list">
						<div class="post-thumb">
							<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
								<?php the_post_thumbnail( '210x140'); ?>
							</a>
							<?php if( $review_score ) : ?>
							<span class="classic-review-score"><?php echo $review_score; ?></span>
							<?php endif; ?>
						</div>
						<div class="entry-content">
								<h5 class="item-title">
									<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php echo wn_get_the_title('60'); ?></a>
								</h5>
								<div class="post-excerpt">
									<?php echo wn_get_the_excerpt('120');?>
								</div>
								<div class="light-post-meta">
									<span><?php printf(__( '作者: %s - %s', 'whatnew-theme'), wn_post_author(), get_the_date()); ?></span>
								</div>
						</div>
					</article>
					<!-- End #article -->
					<?php
				endwhile;
			else :
				// no posts found
			endif;
	
			// Restore original Post Data
			wp_reset_postdata();wp_reset_query();
			$post = $temp_post;
			?>
				</div>
			</div>
			<!-- END .slider -->
			<script type="text/javascript">
				jQuery(document).ready( function($) {
					
					var carousel = $("#carousel-posts-<?php echo $rand_id; ?> .carousel-posts .slides");
					//var item_width = jQuery( " .carousel-list", carousel ).outerWidth();
				    carousel.carouFredSel({
						responsive	: true,
						circular 	: false,
						infinite 	: false,
						prev 		: '#carousel-posts-<?php echo $rand_id; ?> #carousel-controls .carousel-prev',
						next 		: '#carousel-posts-<?php echo $rand_id; ?> #carousel-controls .carousel-next',
						height 		: "auto",
						width 		: "100%",
						auto 		: false,
						debug       : false,
						items		: {
							visible	: {
								min : 2,
								max : 4
							},
							//width   : "item_width"			
						},
						direction	: "left",
						scroll : {
							items			: 1,
							easing			: "elastic",
							duration		: 1000,							
							pauseOnHover	: true
						},
						onCreate 	: function() {

							jQuery(window).on('load', function(){
								carousel.parent().add(carousel).css({
									'height': Math.max.apply(Math, carousel.children().map(function(){ return jQuery(this).height(); }).get()) + 'px'});
							}).trigger('load');
	
							jQuery(window).on('resize', function(){
								carousel.parent().add(carousel).css('height', Math.max.apply(Math, carousel.children().map(function(){ return jQuery(this).height(); }).get()) + 'px');
							}).trigger('resize');
						}				
					});
				});
			</script>
		</div>
		<!-- END .carousel-posts-outer-wrapper -->
	</section>
	<!-- END .posts-box -->
	<?php
	/** END The Posts Loop **/

}
add_shortcode( 'insert_carousel', 'wn_carousel_sc' );
/**
 * Blog Post Slider
 */
function wn_slider_sc( $atts, $content='' ) {
	extract( shortcode_atts( array(
		'post_type' => 'post',
		'cats' => array(),
        'posts_num'=>6,
        'exclude'=>'',
        'orderby'=>'ID',
        'order'=>'DESC',
        'type'=>1,
	), $args ) );
}
add_shortcode( 'insert_slider', 'wn_slider_sc' );

// buttons
function wn_button_sc( $atts, $content='' ){
    
	extract( shortcode_atts( array(
		'size' => '',
        'color'=>'',
        'link'=>'',
        'target'=>'_blank'
	), $atts ) );
	
    $class='';
    if($size){
        $class.=' '.$size;
    }
    if($color){
        $class.=' btn btn-'.$color;
    }
    
    if($target!=''){
        $target = ' target="'.esc_attr($target).'" ';
    }
    
   if(trim($link)==''){
        return '<button type="button" class="'.esc_attr($class).'">'.$content.'</button>';
   }else{
        return '<a class="'.esc_attr($class).'" '.$target.' href="'.$link.'">'.$content.'</a>';
   }
    
}
add_shortcode( 'button', 'wn_button_sc' );

//alert
function  wn_alert_sc($atts,$content ='') {

    extract(shortcode_atts(array(
		'type' => 'info',
		'size' => '',
		'close' => 'false'
	), $atts));

    $dismissable = '';

    if($type!=''){
        $type ='alert-'.$type;
    }
    if($close == 'true' ) {
	    $close_button = '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>';
    	$dismissable = ' alert-dismissable';
    }else {
	    $close_button = '';
    }
    $html  = '<div class="alert ' . $type . $dismissable . '">'.$close_button.return_clean($content).'</div>';
    return $html;
    
}
add_shortcode('alert', 'wn_alert_sc');

function wn_tabs_sc($atts, $content = null)
{	
	
	if (!preg_match_all("/(.?)\[(tab)\b(.*?)(?:(\/))?\](?:(.+?)\[\/tab\])?(.?)/s", $content, $matches)) {
		return do_shortcode($content);
	}
	else
	{
		for ($i = 0; $i < count($matches[0]); $i++) {
			$matches[3][$i] = shortcode_parse_atts($matches[3][$i]);
		}
		$tab_id = rand(0, 100);
		$out = '<div class="wn-tabs clearfix">';
		$out.= '<ul class="nav nav-tabs">';
		for ($i = 0; $i < count($matches[0]); $i++) {
			$active = '';
			if($i == 0) {
				$active = 'class="active"';
			}
			$out.= '<li '.$active.'><a href="#tab-'.$tab_id.'-'.$i.'" data-toggle="tab">'. $matches[3][$i]['title'] .'</a></li>';
		}
		$out.= '</ul>';
		
		$out.= '<div class="tab-content">';
		for ($i = 0; $i < count($matches[0]); $i++) {
			$active = 'class="tab-pane"';
			if($i == 0) {
				$active = 'class="tab-pane active"';
			}
			$out.= '<div id="tab-'.$tab_id.'-'.$i.'" '.$active.'>'. return_clean(trim($matches[5][$i])) .'</div>';
		}
		$out.= '</div>';
		
		$out.= '</div>';
		
		return $out;
	}
}
add_shortcode('tabs', 'wn_tabs_sc');


function wn_col_sc( $atts, $content = null ) {
	 extract( shortcode_atts( array(
		'type' => 'full'
	), $atts ) );
	$out = '<div class="column ' . $type . '">' . return_clean( $content ) . '</div>';
	if ( strpos( $type, 'last' ) ) {
		$out .= '<div class="clear"></div>';
	}
	return $out;
}
add_shortcode('col', 'wn_col_sc');

function return_clean( $content, $p_tag = false, $br_tag = false ) {
	$content = preg_replace( '#^<\/p>|^<br \/>|<p>$#', '', $content );

	if ( $br_tag )
		$content = preg_replace( '#<br \/>#', '', $content );

	if ( $p_tag )
		$content = preg_replace( '#<p>|</p>#', '', $content );

	return do_shortcode( shortcode_unautop( trim( $content ) ) );
}
?>