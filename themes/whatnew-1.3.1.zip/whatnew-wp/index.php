<?php 
get_header();
$default_layout  =  wn_theme_setting('default_layout');  
$page_layout     =  $default_layout;

if(is_singular()) {
  global $post;
  $enable_custom_layout = get_post_meta( $post->ID, 'wn_ec_page_layout', true );  
  
  if( isset($enable_custom_layout) && $enable_custom_layout ) {
  
    $page_layout = get_post_meta( $post->ID, 'wn_page_layout', true ); 
    
  }else {
  
    $page_layout = wn_theme_setting('post_layout'); 
    
  }
  
}
    
$page_layout = wn_get_layout($page_layout);

get_template_part( 'templates/layouts/' . $page_layout, '' );

get_footer(); 
?>