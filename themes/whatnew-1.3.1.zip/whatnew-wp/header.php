<!DOCTYPE html>
<html <?php language_attributes(); ?>>
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<title><?php wn_title(); ?></title>
	
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">

		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
	
		<!-- Favicon and Apple Icons -->
		<link href="<?php echo wn_favicon(); ?>" rel="shortcut icon" type="image/x-icon">
		<!-- wp_head -->
		<?php wp_head(); ?>
	</head>
	<body screen_capture_injected="true" <?php body_class(); ?>>
		<div id="mobile-header">
		    <a id="menu-trigger" href="#sidr-main">
				<i class="fa fa-bars"></i>
		    </a>
		    <div class="mobile-search">
				<form class="form-search" method="get" action="<?php echo home_url(); ?>/" role="search">
				    <input class="search-query" type="text" name="s" id="s" placeholder="Search..." autocomplete="off" value="">
				    <button class="search-submit" id="searchsubmit"><i class="fa fa-search"></i></button>
				</form>
			</div>
		</div>
		<!-- END .mobile-header -->
		<div id="page" class="hfeed site boxed-mode clearfix">
			<aside id="secondary" class="s-sidebar-wrapper">
		      <div class="site-branding">
		      	<?php 
		      		$logo = wn_theme_setting( 'header-logo' );
		      	?>
		      	<?php if(!empty($logo)){ ?>
		        <a href="<?php echo home_url(); ?>" class="header-logo">
					<img src="<?php echo $logo; ?>" />
				</a>
				<?php }else{ ?>
		        <h2 class="site-title">
		        	<a href="<?php echo home_url(); ?>"><?php bloginfo('name'); ?></a>
		        </h2>
				<?php } ?>
		      </div>
		      <!-- END .logo -->
		      <nav id="primary-nav" class="main-navigation" role="navigation">
		        <?php wp_nav_menu( array(
		          'theme_location'  => 'primary',
		          'container'       => false, 
		          'menu_class'      => 'nav-menu', 
		          'menu_id'         => 'primary-menu',
		          'walker'          => new WN_Custom_Nav_Walker ) ); ?>
		      </nav>
		      <!-- END nav -->
		    </aside>
		    <!-- END .m-sidebar-wrapper -->