<?php get_header(); ?>
<div id="main">
				<div class="mainTop clear">
					<div class="imageRotation leftFloat"> 
	 					<div class="imageBox">
	 						<a href="http://www.ninanfm.com/archives/13.html" target="_blank"><img src="http://www.ninanfm.com/wp-content/uploads/2015/07/maohe.jpg" /></a>
	 						<a href="http://www.ninanfm.com/archives/11.html" target="_blank"><img src="http://www.ninanfm.com/wp-content/uploads/2015/07/huiyi.jpg" /></a>
	 						<a href="http://www.ninanfm.com/archives/14.html" target="_blank"><img src="http://www.ninanfm.com/wp-content/uploads/2015/07/qingchun.jpg" /></a>
	 						<a href="http://www.ninanfm.com/archives/6.html" target="_blank"><img src="http://www.ninanfm.com/wp-content/uploads/2015/07/luguo.jpg" /></a>
	 						<a href="http://www.ninanfm.com/archives/3.html" target="_blank"><img src="http://www.ninanfm.com/wp-content/uploads/2015/07/duchu.jpg" /></a>

	 					</div>
	    				    				<div class="titleBox">
	     					<p class="active"><span>猫和他的半岛铁盒</span></p>
	        				<p>我愿回忆，成为一种习惯.</p>
	        				<p>青春有一半关于梦想</p>
	        				<p>你在过路的风景上。</p>
	        				<p>一个人的独处。</p>
	    				</div>
	 					<div class="icoBox">
	 						<span class="active" rel="1">1</span>
	 						<span rel="2">2</span>
	 						<span rel="3">3</span>
	 						<span rel="4">4</span>
	 						<span rel="5">5</span>

	 					</div>
					</div>

<div class="hotNews2 rightFloat">
<ul class="case">
	<li>
		<div class="case_w">
			<img src="http://www.ninanfm.com/wp-content/uploads/2015/07/beishang.jpg" width="280" height="170" />
			<div class="fire"></div>
<a href="http://www.ninanfm.com/archives/9.html" class="x" target="_blank"></a>
		
	</li>
<div class="wenzi">悲伤的人就是不够坚强。</div>
	<li>
		<div class="case_w">
			<img src="http://www.ninanfm.com/wp-content/uploads/2015/07/mingzi.jpeg" width="280" height="170" />
			<div class="fire"></div>
<a href="http://www.ninanfm.com/archives/7.html" class="x" target="_blank"></a>
		</div>
	</li><div class="wenzi">vol.你名字的样子。</div>
</ul>

</div>

				</div>

				<div class="mainContentsy clear">
					<div class="articleList leftFloat">
						
						<div class="postList clear">
							<div class="articleListTitle">
<div class="summary"><div class="fmwm3">呢喃FM，2015年中<span style="color: #339966;">大招募</span>！！！</span>详情请点击<a href="http://www.ninanfm.com/about/contactus"  target="_blank"><span style="color: #339966;">【招募信息】</span></a></div></div>
    							<div class="articleListMore">
     						 		<a href="<?php bloginfo('url'); ?>/article">查看更多　</a>
    							</div>
							</div>
							<ul>
							<?php $posts = query_posts($query_string . '&orderby=date&showposts=6&cat=1,2'); ?>
							<?php while(have_posts()) : the_post(); ?>
								<li>
									<div class="entryImg">
										<a title="<?php the_title(); ?>" target="_blank" href="<?php the_permalink(); ?>">
											<img width="235" height="152" alt="<?php the_title(); ?>" src="<?php echo catch_that_image() ?>">
										</a>
										<?php
										$custom_fields = get_post_custom_keys($post_id);
										if (!in_array ('post_copyright', $custom_fields)) :
										?>
										<span class="entryCopyright"><?php the_category(' , '); ?></span>
										<?php else: ?>
										<span class="entryCopyright">精选</span>
										<?php endif; ?>
									</div>
									<h3 class="entryTitle">
										<a title="<?php the_title(); ?>" target="_blank" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
									</h3>
									<p class="entryContent"><?php 
									if ($post->post_excerpt) {
										_e(wp_trim_words( $post->post_excerpt, 80,'......' ));
									} else {
										_e(wp_trim_words( $post->post_content, 80,'......' )); 
									}
									?></p>
									<div class="entryMeta">
<em class="entryDate"><div class="tagda"><?php the_tags((' '),''); ?></div>/ <?php the_time('Y-m-d') ?></em>
									</div>
									<div class="entryCover">
										<em class="entryViews ml2"><?php echo getPostViews(get_the_ID()); ?></em>
										<em class="entryReplys ml2"><?php comments_popup_link('0', '1', '%', '', '0'); ?></em>
									</div>
								</li>
							<?php endwhile; ?>
							</ul>
						</div>
					</div>
					<?php include_once("sidebarIndex.php"); ?>
				</div>
				
				<div class="linkShow clear">
					<div class="articleListTitle">
   							<h3>友情链接</h3>
   							<span style="padding: 0 0 0 10px; color: #999999; line-height: 30px;">[ 申请友链请在 <a title="友情链接" target="_blank" href="<?php bloginfo('url'); ?>/about/link">友链页面</a> 查看详情，留言。 ]</span>
					</div>
					<div class="friendLink clear">
						<ul>
							<li><a target="_blank" title="小时光电台" href="http://www.xsgdt.com/">小时光电台</a></li>
							<li><a target="_blank" title="呢喃电台" href="http://www.ninanfm.com/">呢喃</a></li>
							<li><a target="_blank" title="运营笔记" href="http://www.ccoooo.com/">运营笔记</a></li>
							<li><a target="_blank" title="耳朵的主人" href="http://www.edzbe.com/">耳朵的主人</a></li>
						</ul>
					</div>
				</div>
			</div>
<?php get_footer(); ?>