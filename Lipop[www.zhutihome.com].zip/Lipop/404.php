<?php
get_header(); ?>
<div id="container">
<div class="gg">404，此页面已经从地球上消失！请到火星上寻找。</div>
</div>

<?php get_footer(); ?>