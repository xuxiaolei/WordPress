<div class="footer">
    <p>Copyright &copy; 2015 | Designed by <a target="_blank" href="http://www.yelook.com/">Toyye</a>. </p>
</div>
<div class="floattop"><i class="fa fa-arrow-circle-up fa-3x"></i></div>
</div>
</body>
</html>