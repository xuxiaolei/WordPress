<?php get_header(); ?>
<div class="content-wrap">
	<div style="text-align:center;padding:10px 0;font-size:16px;background-color:#ffffff;">
		<h2 style="font-size:36px;margin-bottom:10px;">哎哟～404了～休息一下，玩个游戏吧！</h2>
<p align="center"><font face="微软雅黑" size="5" color="#0099CC">
<a target="_blank" href="http://www.cuizl.com/">首页</a>&nbsp;
<a target="_blank" href="http://www.cuizl.com/qiyezhuti" title="企业主题">企业主题</a>&nbsp;
<a target="_blank" href="http://www.cuizl.com/bokezhuti" title="博客主题">博客主题</a>&nbsp;
<a target="_blank" href="http://www.cuizl.com/cmszhuti">CMS主题</a>&nbsp;
<a target="_blank" href="http://www.cuizl.com/tag/%E5%85%8D%E8%B4%B9">免费主题</a>&nbsp;
<a target="_blank" href="http://www.cuizl.com/wpjiaochen">wordpress教程</a>&nbsp;&nbsp;
<a target="_blank" href="http://www.cuizl.com/wpchajian">wordpress插件</a>&nbsp;&nbsp;
<a target="_blank" href="http://www.cuizl.com/wpkaifa">wordpress开发</a></font></p><p align="center">
</div>
<?php get_footer(); ?>