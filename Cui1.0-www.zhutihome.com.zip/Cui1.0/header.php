<!DOCTYPE HTML>

<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=10,IE=9,IE=8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<title>
<?php wp_title('-', true, 'right'); echo get_option('blogname'); if (is_home ()) echo get_option('blogdescription'); if ($paged > 1) echo '-Page ', $paged; ?>
</title>
<?php

$sr_1 = 0; $sr_2 = 0; $commenton = 0; 

if( dopt('d_sideroll_b') ){ 

    $sr_1 = dopt('d_sideroll_1');

    $sr_2 = dopt('d_sideroll_2');

}

if( is_singular() ){ 

    if( comments_open() ) $commenton = 1;

}

?>
<script>

window._deel = {name: '<?php bloginfo('name') ?>',url: '<?php echo get_bloginfo("template_url") ?>', ajaxpager: '<?php echo dopt('d_ajaxpager_b') ?>', commenton: <?php echo $commenton ?>, roll: [<?php echo $sr_1 ?>,<?php echo $sr_2 ?>]}

</script>
<?php 

wp_head(); 

if( dopt('d_headcode_b') ) echo dopt('d_headcode'); ?>

<!--[if lt IE 9]><script src="<?php bloginfo('template_url'); ?>/js/html5.js"></script><![endif]-->

</head>

<body <?php body_class(); ?>>
<header id="masthead" class="site-header">
  <nav id="top-header">
    <div class="top-nav">
      <div id="user-profile"> 欢迎光临！
        <?php 

		if( dopt('d_sign_b') ){ 

			global $current_user; 

			get_currentuserinfo();

			$uid = $current_user->ID;

			$u_name = get_user_meta($uid,'nickname',true);

	   ?>
        <span class="nav-set"><span class="nav-login">
        <?php if(is_user_logged_in()){echo '<i class="fa fa-user"></i> '.$u_name.' &nbsp; '; echo ' <i class="fa fa-power-off"></i>';}else{echo '<i class="fa fa-user"></i>';}; wp_loginout(); ?>
        </span> </span>
        <?php } ?>
      </div>
      <div class="menu-%e5%a4%b4%e9%83%a8-container">
        <ul id="menu-%e5%a4%b4%e9%83%a8" class="top-menu">
          <?php if( dopt('d_topindex_01_b') ) printf(dopt('d_topindex_01')); ?>
        </ul>
      </div>
    </div>
  </nav>
  <div id="nav-header">
  	<div id="top-menu">
    <div id="top-menu_1"><span class="nav-search"><i class="fa fa-search"></i></span> <span class="nav-search_1"><i class="fa fa-navicon"></i></span>
      <hgroup class="logo-site">
        <h1 class="site-title"> <a href="/"><img src="<?php bloginfo('template_url'); ?>/img/logo.png" alt="Cui 1.0博客主题" /></a></h1>
      </hgroup>
      <div id="site-nav-wrap">
        <nav id="site-nav" class="main-nav">
          <div>
            <ul class="down-menu nav-menu">
              <?php echo str_replace("</ul></div>", "", ereg_replace("<div[^>]*><ul[^>]*>", "", wp_nav_menu(array('theme_location' => 'nav', 'echo' => false)) )); ?>
              <li id="menu-item-6853" class="menu-item-6853"><a target="_blank" href="http://www.cuizl.com/bokezhuti/1347.html"><i class="fa-external-link-square fa"></i><span class="font-text">cui 1.0主题下载</span></a></li>
            </ul>
          </div>
        </nav>
      </div>
    </div>
  	</div>
  </div>
  <nav>
    <ul class="nav_sj">
        <?php echo str_replace("</ul></div>", "", ereg_replace("<div[^>]*><ul[^>]*>", "", wp_nav_menu(array('theme_location' => 'nav', 'echo' => false)) )); ?>
    </ul>
  </nav>
</header>
<div id="search-main">
  <div id="searchbar">
    <form id="searchform" action="/" method="get">
      <input id="s" type="text" required placeholder="输入搜索内容" name="s" value="">
      <button id="searchsubmit" type="submit">搜索</button>
    </form>
  </div>
  <div id="searchbar">
    <form id="searchform" target="_blank" action="https://www.baidu.com/" method="get">
      <input type="hidden" name="entry" value="1">
      <input class="swap_value" name="q" placeholder="输入百度站内搜索关键词">
      <button id="searchsubmit" type="submit">百度</button>
    </form>
  </div>
  <div class="clear"></div>
</div>
<section class="container">
<div class="speedbar">
  <div class="toptip"><strong class="text-success"><i class="fa fa-volume-up"></i> </strong> <?php echo dopt('d_tui'); ?></div>
</div>
<?php if( dopt('d_adsite_01_b') ) echo '<div class="banner banner-site">'.dopt('d_adsite_01').'</div>'; ?>
