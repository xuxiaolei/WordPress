<?php
/*
老莫原创主题：Color Fell
Copy Right @ 2015.11 By LaoMo WordPress Theme 
版权所有：老莫博客:www.wp38.cn
*/
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<meta http-equiv="Content-Type" content="text/html" />
<link rel="shortcut icon" href="" type="image/x-icon" />
<title><?php wp_title( '|', true, 'right' ); bloginfo('name'); ?>-<?php echo get_bloginfo ( 'description' );?></title>
<?php
	global $post;
	if (is_single()){
		$keywords = get_post_meta($post->ID, "keyword", true);
		if($keywords == ""){
			$tags = wp_get_post_tags($post->ID);
			foreach ($tags as $tag){
				$keywords = $keywords.$tag->name.",";
			}
			$keywords = rtrim($keywords, ', ');
		}
		$description = get_post_meta($post->ID, "description", true);
		if($description == ""){
			if($post->post_excerpt){
				$description = $post->post_excerpt;
			}else{
				$description = mb_strimwidth(strip_tags($post->post_content),0,200,'');
			}
		}
	}elseif (is_page()){
		$keywords = $options['keyword'];
		$description = $options['description'];
	}elseif (is_category()){
		$keywords = single_cat_title('', false);
		$description = category_description();
	}elseif (is_tag()){
		$keywords = single_tag_title('', false);
		$description = tag_description();
	}
	$keywords = trim(strip_tags($keywords));
	$description = trim(strip_tags($description));
	?>
<meta  name="keywords" content="<?php if (is_home()){echo getop('keyword');}else{echo $keywords;}?>">
<meta  name="description" content="<?php if (is_home()){echo getop('sitems');}else{echo $description;}?>">
<meta name="description" content="<?php echo $description; ?>" />
<script type="text/javascript"> 
window.onload = function(){ 
menuFixed('nav'); 
} 
</script> 
<link type="text/css" href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet">
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/slide.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.js"></script>
</head>
<body class="custom-background">
<div class="contains">
	<div class="header">
	<div class="headerui">
			<div class="main">
				<div class="logo">

<?php
if (get_option('LaoMo_options')['indexshow'] == 0){
echo "<a href=";
echo " ";
echo bloginfo('url');
echo ">";
echo "<img src=";
echo getop('sitelogo');
echo " ";
echo "</a>";
}else{
echo "<a href=";
echo bloginfo('url');
echo ">";
echo singlelinkcolor('color1');
echo bloginfo('name');
echo "</a>";
echo "</h3>";
}
?>
<div class="topnav" ><?php wp_nav_menu('theme_location=mainmenu'); ?></div>
</div>

				
				
			</div><div class="nav1080" id="nav" <?php echo headcolor('color1');?>>
			<div class="navmain" >
			
							<div class="nav" >				<div class="sousuo">
					<?php
echo sidebarcolor('color1');
echo $instance["title"];
echo "</h3>";
echo $search_title;
if ($instance["sou"])
echo 'get_search_form()';
echo '<form method="get" id="searchform" action="' . $_SERVER['PHP_SELF'] . '">';
echo '<input name="s" id="s" type="text" class="souform" value="输入你搜索的关键字" />';
echo '<input id="searchsubmit" type="submit" class="soubuttom" value="搜索" />';
echo '</form>';?>
					</div>
					<ul id="menuss" <?php echo linkover('color1');?> ><?php echo strip_tags(wp_nav_menu( $menu)); ?></ul>
	
				</div>
				</div>
			</div>

		</div>
	</div>