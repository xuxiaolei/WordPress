<?php
/*
老莫原创主题：Color Fell
Copy Right @ 2015.11 By LaoMo WordPress Theme 
版权所有：老莫博客:www.wp38.cn
*/
?>
<?php get_header(); ?>
<div id="content">
	<div class="wrapper">
		<div class="site"><?php laoMopublic(); ?></div>
		<?php
			the_title( '<h1 class="title">', '</h1>' );
			while ( have_posts() ) : the_post();
			get_template_part( 'content', 'page' );
			endwhile;
		?>
	</div>
</div>
<?php get_footer(); ?>