<?php
/*
老莫原创主题：Color Fell
Copy Right @ 2015.11 By LaoMo WordPress Theme 
版权所有：老莫博客:www.wp38.cn
*/
?>
<?php get_header(); ?>
<div id="content">
<div class="wrapper">
<?php
get_template_part( 'inc/theme-loop', 'single');
?>

</div>
</div>
<?php get_footer(); ?>