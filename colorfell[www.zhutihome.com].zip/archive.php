<?php
/*
老莫原创主题：Color Fell
Copy Right @ 2015.11 By LaoMo WordPress Theme 
版权所有：老莫博客:www.wp38.cn
*/
?>
<?php get_header(); ?>
<?php if ( is_day() ) : printf( __( '<span>%s·¢²¼µÄËùÓÐÎÄÕÂ</span>', 'tanhaibonet' ), get_the_date() ); ?>
				<?php elseif ( is_month() ) : printf( __( '<span>%s·¢²¼µÄËùÓÐÎÄÕÂ</span>', 'tanhaibonet' ), get_the_date( _x( 'F Y', 'monthly archives date format', 'tanhaibonet' ) ) ); ?>
				<?php elseif ( is_year() ) : printf( __( '<span>%s·¢²¼µÄËùÓÐÎÄÕÂ</span>', 'tanhaibonet' ), get_the_date( _x( 'Y', 'yearly archives date format', 'tanhaibonet' ) ) ); ?>
				<?php endif; ?>
		<?php get_template_part( 'inc/theme-catpage', 'archive');?>

<?php get_footer(); ?>