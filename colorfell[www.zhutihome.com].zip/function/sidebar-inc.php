<?php
/*
老莫原创主题：Color Fell
Copy Right @ 2015.11 By LaoMo WordPress Theme 
版权所有：老莫博客:www.wp38.cn
*/
?>
<?php
// 搜索功能类
class LaoMoseach extends WP_Widget {

function LaoMoseach() {
parent::WP_Widget(false, $name='LaoMo搜索');
}
function widget($args, $instance) {
global $post;
$solid = '4px'; 
$post_old = $post;
$cat_posts = new WP_Query(
"&seach=" . $instance["sou"]
);
//sidebar name
if( $instance["title_search"] )
echo '$instance["title"]';
else
echo '<div class="soso">';
echo sidebarcolor('color1');
echo $instance["title"];
echo "</h3>";
echo $search_title;
if ($instance["sou"])
echo 'get_search_form()';
echo '<form method="get" id="searchform" action="' . $_SERVER['PHP_SELF'] . '">';
echo '<input name="s" id="s" type="text" class="souform" />';
echo '<input id="searchsubmit" type="submit" class="soubuttom" value="搜索" />';
echo '</form>';
//Get Post
while ( $cat_posts->have_posts() )
{
$cat_posts->the_post();
?>
</li>
<?php
}
echo '</div>';
echo $after_widget;
remove_filter('excerpt_length', $new_excerpt_length);
$post = $post_old;
}
function update($LaoMotheme, $old_instance) {
if ( function_exists('the_post_thumbnail') )
{
$search = get_option('LaoMo_updata');
if ( !$search ) $search = array();
$search[$this->id] = array($LaoMotheme['thumb_w'], $LaoMotheme['thumb_h']);
update_option('LaoMo_updata', $search);
}
return $LaoMotheme;
}
function form($instance) {
?>
<p>
<label for="<?php echo $this->get_field_id("title"); ?>">
标题:
<input class="widefat" id="<?php echo $this->get_field_id("title"); ?>" name="<?php echo $this->get_field_name("title"); ?>" type="text" value="<?php echo esc_attr($instance["title"]); ?>" />
</label>
</p>
<p>
<?php
}
}
// 分类列表类
class LaoMofenglei extends WP_Widget {

function LaoMofenglei() {
parent::WP_Widget(false, $name='LaoMo分类');
}
function widget($args, $instance) {
global $post;
$post_old = $post;
$cat_posts = new WP_Query(
"&seach=" . $instance["fenglei"]
);
//sidebar name
if( $instance["title_fenglei"] )
echo '$instance["title"]';
else
echo '<div class="rightsidebar">';
echo sidebarcolor('color1');
echo $instance["title"];
echo "</h3>";
echo $search_title;
echo "<ul>\n";
if ($instance["fenglei"])
$orderby = 'name'; 
$order = 'ASC';
$depth = 1;
$show_count = 1;
$pad_counts = 0;
$hierarchical = 1;
$title = '';
$args = array(
'order' => $order,
'orderby' => $orderby,
'depth' => $depth,
'show_count' => $show_count,
'pad_counts' => $pad_counts,
'hierarchical' => $hierarchical,
'title_li' => $title 
);
$categories = get_categories($args);
foreach($categories as $category) {
if ($cate == 0){
echo '<li>';
echo '<a';
echo ' '; 
echo linkover('color1');
echo ' ';
echo 'href=';
echo get_category_link($category->term_id );
echo " ";
echo 'title=';
echo $category->name;
echo '>';
echo $category->name;
echo '<b>';
echo '[';
echo $category->category_count;
echo ']';
echo '</b>';
echo '</a>';
echo '</li>';
}
}

//Get Post
while ( $cat_posts->have_posts() )
{
$cat_posts->the_post();
?>
</li>
<?php
}
echo '</div>';
echo $after_widget;
remove_filter('excerpt_length', $new_excerpt_length);
$post = $post_old;
}
function update($LaoMotheme, $old_instance) {
if ( function_exists('the_post_thumbnail') )
{
$flei = get_option('LaoMo_updata');
if ( !$flei ) $flei = array();
$flei[$this->id] = array();
update_option('LaoMo_updata',$flei);
}
return $LaoMotheme;
}
function form($instance) {
?>
<p>
<label for="<?php echo $this->get_field_id("title"); ?>">
标题:
<input class="widefat" id="<?php echo $this->get_field_id("title"); ?>" name="<?php echo $this->get_field_name("title"); ?>" type="text" value="<?php echo esc_attr($instance["title"]); ?>" />
</label>
</p>
<p>
<?php
}
}

// 最新文章类
class LaoMozxwz extends WP_Widget {

function LaoMozxwz() {
parent::WP_Widget(false, $name='LaoMo最新文章');
}
function widget($args, $instance) {
global $post;
$post_old = $post;
$cat_posts = new WP_Query(
"&seach=" . $instance["zuixinwenzhang"]
);
//sidebar name
if( $instance["title_biaoqian"] )
echo '<a href="' . get_category_link($instance["cat"]) . '">' . $instance["title"] . '</a>';
else
echo "<div id=float>";
echo '<div class="rightsidebar">';
echo sidebarcolor('color1');
echo $instance["title"];
echo "</h3>";
echo "<ul>\n";
query_posts(array('showposts'=>$instance["zxwzid"]));;
if ($instance["zuixinwenzhang"])
echo '$instance["zxwzid"]';
else
echo "<ul>";
while (have_posts()) : the_post();
echo "<a";
echo " ";
echo linkover('color1');
echo " ";
echo "href=";
echo the_permalink();
echo " ";
echo "title=";
echo the_title();
echo " ";
echo ">";
echo "<li>";
echo "<p>";
echo "</p>";
echo excerpttitle(15);
echo "</a>";
echo "</li>";
endwhile;
echo "</ul>";
echo "</div>";

//Get Post
while ( $cat_posts->have_posts() )
{
$cat_posts->the_post();
?>
</li>
<?php
}
echo '</div>';
echo $after_widget;
remove_filter('excerpt_length', $new_excerpt_length);
$post = $post_old;
}
function update($LaoMotheme, $old_instance) {
if ( function_exists('the_post_thumbnail') )
{
$biaoti = get_option('LaoMo_updata');
if ( !$biaoti ) $biaoti = array();
$biaoti[$this->id] = array();
update_option('LaoMo_updata',$biaoti);
}
return $LaoMotheme;
}
function form($instance) {
?>
<p>
<label for="<?php echo $this->get_field_id("title"); ?>">
标题:
<input class="widefat" id="<?php echo $this->get_field_id("title"); ?>" name="<?php echo $this->get_field_name("title"); ?>" type="text" value="<?php echo esc_attr($instance["title"]); ?>" />
</label>
显示文章条数:
<label for="<?php echo $this->get_field_id("zxwzid");?>">
<input class="widefat" style="width:30px;margin-top:10px;" id="<?php echo $this->get_field_id("zxwzid");?>" name="<?php echo $this->get_field_name("zxwzid"); ?>" type="text" value="<?php echo esc_attr($instance["zxwzid"]); ?>" />
</label>
</p>
<p>
<?php
}
}

// 标签云类
class LaoMobiaoqian extends WP_Widget {

function LaoMobiaoqian() {
parent::WP_Widget(false, $name='LaoMo标签云');
}
function widget($args, $instance) {
global $post;
$post_old = $post;
$cat_posts = new WP_Query(
"&biaoqian=" . $instance["biaoqian"]
);
//sidebar name
if( $instance["title_biaoqian tagsidebar"] )
echo '$instance["title"]';
else
echo '<div class="rightsidebar">';
echo sidebarcolor('color1');
echo $instance["title"];
echo "</h3>";
echo "<ul>\n";
echo "<div class=tagsidebar>";
if ($instance["zuixinwenzhang"])                        
$tag_link = get_tag_link($tag->term_id);
wp_tag_cloud(array('smallest'=>1, 'largest' => 12,'unit'=>'px','orderby' => 'count', 'order' => 'DESC', 'hide_empty' => false) );
echo "</div>";
//Get Post
while ( $cat_posts->have_posts() )
{
$cat_posts->the_post();
?>
</li>
<?php
}
echo '</div>';
echo $after_widget;
remove_filter('excerpt_length', $new_excerpt_length);
$post = $post_old;
}
function update($LaoMotheme, $old_instance) {
if ( function_exists('the_post_thumbnail') )
{
$bqian = get_option('LaoMo_updata');
if ( !$bqian ) $bqian = array();
$bqian[$this->id] = array();
update_option('LaoMo_updata',$bqian);
}
return $LaoMotheme;
}
function form($instance) {
?>
<p>
<label for="<?php echo $this->get_field_id("title"); ?>">
标题:
<input class="widefat" id="<?php echo $this->get_field_id("title"); ?>" name="<?php echo $this->get_field_name("title"); ?>" type="text" value="<?php echo esc_attr($instance["title"]); ?>" />
</label>

</p>
<p>
<?php
}
}
// 近期文章类
class LaoMojinqiwz extends WP_Widget {

function LaoMojinqiwz() {
parent::WP_Widget(false, $name='LaoMo近期文章');
}
function widget($args, $instance) {
global $post;
$post_old = $post;
$cat_posts = new WP_Query(
"&jqwz=" . $instance["jqwz"]
);
//sidebar name
if( $instance["jinqiwz"] )
echo '<a href="' . get_category_link($instance["cat"]) . '">' . $instance["title"] . '</a>';
else
echo '<div class="rightsidebar">';
echo sidebarcolor('color1');
echo $instance["title"];
echo "</h3>";
echo $zjwz_title;
echo "<ul>\n";
echo "<div class=jinqiwz>";
if ($instance["jinqiwzhang"])
echo '$instance["zjwzid"]';
else
query_posts(array('showposts' => $instance["zjwzid"],'caller_get_posts' => 1,'order' => DESC,'orderby' => modified) );
while (have_posts()) : the_post();
echo "<li>";
echo "<p>";
echo "</p>";
echo "<a";
echo " ";
echo linkover('color1');
echo " ";
echo "href=";
echo the_permalink();
echo " ";
echo "title=";
echo the_title();
echo ">";
echo excerpttitle(17);
echo "</a>";
echo "<br>";
echo "<span>";
echo human_time_diff(get_the_modified_time('U'), current_time( 'timestamp' ) ) . '前';
echo "</span>";
echo "</li>";
endwhile;
echo wp_reset_query();
echo "</div>";
//Get Post
while ( $cat_posts->have_posts() )
{
$cat_posts->the_post();
?>
</li>
<?php
}
echo '</div>';
echo $after_widget;
remove_filter('excerpt_length', $new_excerpt_length);
$post = $post_old;
}
function update($LaoMotheme, $old_instance) {
if ( function_exists('the_post_thumbnail') )
{
$jqwzz = get_option('LaoMo_updata');
if ( !$jqwzz ) $jqwzz = array();
$jqwzz[$this->id] = array();
update_option('LaoMo_updata',$jqwzz);
}
return $LaoMotheme;
}
function form($instance) {
?>
<p>
<label for="<?php echo $this->get_field_id("title"); ?>">
标题:
<input class="widefat" id="<?php echo $this->get_field_id("title"); ?>" name="<?php echo $this->get_field_name("title"); ?>" type="text" value="<?php echo esc_attr($instance["title"]); ?>" />
</label>
显示文章条数:
<label for="<?php echo $this->get_field_id("zjwzid");?>">
<input class="widefat" style="width:30px;margin-top:10px;" id="<?php echo $this->get_field_id("zjwzid");?>" name="<?php echo $this->get_field_name("zjwzid"); ?>" type="text" value="<?php echo esc_attr($instance["zjwzid"]); ?>" />
</label>
</p>
<p>
<?php
}
}

// 友情链接
class LaoMoyqlj extends WP_Widget {

function LaoMoyqlj() {
parent::WP_Widget(false, $name='LaoMo友情链接');
}
function widget($args, $instance) {
global $post;
$post_old = $post;
$cat_posts = new WP_Query(
"&yqlj=" . $instance["yqlj"]
);
//sidebar name
if( $instance["title_yqlj yqljsidebar"] )
echo '$instance["title"]';
else
echo '<div class="rightsidebar">';
echo sidebarcolor('color1');
echo $instance["title"];
echo "</h3>";
echo "<ul>\n";
echo "<div class=yqlj>";
if ($instance["zuixinwenzhang"])                        
echo "<h3>友情链接</h3><ul>";
get_links(-1, '<span>', '</span>', '<br />', FALSE, id, FALSE, FALSE, -1, FALSE);
echo "</ul>"; 
//Get Post
while ( $cat_posts->have_posts() )
{
$cat_posts->the_post();
?>
</li>
<?php
}
echo '</div>';
echo $after_widget;
remove_filter('excerpt_length', $new_excerpt_length);
$post = $post_old;
}
function update($LaoMotheme, $old_instance) {
if ( function_exists('the_post_thumbnail') )
{
$bqian = get_option('LaoMo_updata');
if ( !$bqian ) $bqian = array();
$bqian[$this->id] = array();
update_option('LaoMo_updata',$bqian);
}
return $LaoMotheme;
}
function form($instance) {
?>
<p>
<label for="<?php echo $this->get_field_id("title"); ?>">
标题:
<input class="widefat" id="<?php echo $this->get_field_id("title"); ?>" name="<?php echo $this->get_field_name("title"); ?>" type="text" value="<?php echo esc_attr($instance["title"]); ?>" />
</label>

</p>
<p>
<?php
}
}


//最新图片文章
class LaoMonewstupwenzhang extends WP_Widget {

function LaoMonewstupwenzhang() {
parent::WP_Widget(false, $name='LaoMo最新图文');
}
function widget($args, $instance) {
global $post;
$post_old = $post;
$cat_posts = new WP_Query(
"&seach=" . $instance["zuixinwenzhang"]
);
//sidebar name
if( $instance["title_biaoqian"] )
echo '<a href="' . get_category_link($instance["cat"]) . '">' . $instance["title"] . '</a>';
else
echo '<div class="newsphoto">';
echo sidebarcolor('color1');
echo $instance["title"];
echo "</h3>";
echo "<ul>\n";
query_posts(array('showposts'=>$instance["zxwzid"]));;
if ($instance["zuixinwenzhang"])
echo '$instance["zxwzid"]';
else

while (have_posts()) : the_post();
echo "<li>";
echo "<dl>";
echo "<a href=";
echo the_permalink();
echo " ";
echo "title=";
echo the_title_attribute();
echo " ";
echo ">";
echo "<div class=newpic>";
echo "<img src=";
echo default_images();
echo " ";
echo "alt=";
echo the_title();
echo " ";
echo "title=";
echo the_title();
echo "/>";
echo "</div>";
echo "</a>";

echo " ";
echo "<a";
echo " ";
echo linkover('color1');
echo " ";
echo "href=";
echo the_permalink();
echo " ";
echo "title=";
echo the_title();
echo " ";
echo ">";
echo "<dt>";
echo excerpttitle(6);
echo "</a>";
echo "</dt>";
echo "</li>";
endwhile;

echo "</dl>";
//Get Post
while ( $cat_posts->have_posts() )
{
$cat_posts->the_post();
?>
</li>
<?php
}
echo '</div>';
echo $after_widget;
remove_filter('excerpt_length', $new_excerpt_length);
$post = $post_old;
}
function update($LaoMotheme, $old_instance) {
if ( function_exists('the_post_thumbnail') )
{
$biaoti = get_option('LaoMo_updata');
if ( !$biaoti ) $biaoti = array();
$biaoti[$this->id] = array();
update_option('LaoMo_updata',$biaoti);
}
return $LaoMotheme;
}
function form($instance) {
?>
<p>
<label for="<?php echo $this->get_field_id("title"); ?>">
标题:
<input class="widefat" id="<?php echo $this->get_field_id("title"); ?>" name="<?php echo $this->get_field_name("title"); ?>" type="text" value="<?php echo esc_attr($instance["title"]); ?>" />
</label>
显示文章条数:
<label for="<?php echo $this->get_field_id("zxwzid");?>">
<input class="widefat" style="width:30px;margin-top:10px;" id="<?php echo $this->get_field_id("zxwzid");?>" name="<?php echo $this->get_field_name("zxwzid"); ?>" type="text" value="<?php echo esc_attr($instance["zxwzid"]); ?>" />
</label>
</p>
<p>
<?php
}
}

// 最新评论
class LaoMozxpl extends WP_Widget {

function LaoMozxpl() {
    parent::WP_Widget(false, $name='LaoMo最新评论');
}
function widget($args, $instance) {
global $post;
$post_old = $post;
$cat_posts = new WP_Query(
"&seach=" . $instance["zuixinwenzhang"]
);
//sidebar name
if( $instance["title_pinglun"] )
echo '<a href="' . get_category_link($instance["cat"]) . '">' . $instance["title"] . '</a>';
else
echo "<div id=float>";
echo '<div class="zxplsidebar">';
echo sidebarcolor('color1');
echo $instance["title"];
echo "</h3>";
echo "<ul>\n";
query_posts(array('showposts'=>$instance["zxplid"]));;
if ($instance["zuixinwenzhang"])
echo "<ul>";
echo h_comments($outer='博主',$limit='10');
echo "</ul>";
echo "</div>";

//Get Post
while ( $cat_posts->have_posts() )
{
$cat_posts->the_post();
?>
</li>
<?php
}
echo '</div>';
echo $after_widget;
remove_filter('excerpt_length', $new_excerpt_length);
$post = $post_old;
}
function update($LaoMotheme, $old_instance) {
    if ( function_exists('the_post_thumbnail') )
    {
        $biaoti = get_option('LaoMo_updata');
        if ( !$biaoti ) $biaoti = array();
        $biaoti[$this->id] = array();
        update_option('LaoMo_updata',$biaoti);
    }
    return $LaoMotheme;
}
function form($instance) {
?>
<p>
    <label for="<?php echo $this->get_field_id("title"); ?>">
        标题:
        <input class="widefat" id="<?php echo $this->get_field_id("title"); ?>" name="<?php echo $this->get_field_name("title"); ?>" type="text" value="<?php echo esc_attr($instance["title"]); ?>" />
    </label>

</p>
<p>
    <?php
    }
    }
?>

