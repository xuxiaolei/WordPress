﻿<?php
/*
老莫原创主题：Color Fell
Copy Right @ 2015.11 By LaoMo WordPress Theme 
版权所有：老莫博客:www.wp38.cn
*/
?>
<?php
function LaoMo_theme_save(){
global $post;
$options = get_option('yset');
$LaoMo_Option=LaoMo_Option_Setting();
wp_enqueue_media();
wp_enqueue_style('thickbox');
if (isset($_REQUEST['option-save'])){
	$slideur1=$_REQUEST['slideurl1'];
	$slideur2=$_REQUEST['slideurl2'];
	$slideur3=$_REQUEST['slideurl3'];
	$slideur4=$_REQUEST['slideurl4'];
	$slide01=$_REQUEST['slideo'];
	$slide02=$_REQUEST['slidet'];
	$slide03=$_REQUEST['slidew'];
	$slide04=$_REQUEST['slidef'];
//提交表单
	$LaoMo_data=array("slideu04"=>$slideur4,"slideu03"=>$slideur3,"slideu02"=>$slideur2,"slideu01"=>$slideur1,"slide1"=>$slide01,"slide2"=>$slide02,"slide3"=>$slide03,"slide4"=>$slide04);	
	update_option('yset',$LaoMo_data);
	$slideurl01=$slideur1;
	$slideurl02=$slideur2;
	$slideurl03=$slideur3;
	$slideurl04=$slideur4;
	$headslide01=$slide01;
	$headslide02=$slide02;
	$headslide03=$slide03;
	$headslide04=$slide04;
	echo '<div><p>主题设置成功！</p></div>';
	}else{
	$slideurl01=$options['slideu01'];
	$slideurl02=$options['slideu02'];
	$slideurl03=$options['slideu03'];
	$slideurl04=$options['slideu04'];
	$headslide01=$options['slide1'];
	$headslide02=$options['slide2'];
	$headslide03=$options['slide3'];
	$headslide04=$options['slide4'];
	}
if ( 'reset' == isset($_REQUEST['reset']) ){
	$slideurl01=$slideur1;
	$slideurl02=$slideur2;
	$slideurl03=$slideur3;
	$slideurl04=$slideur4;
	$headslide01=$slide01;
	$headslide02=$slide02;
	$headslide03=$slide03;
	$headslide04=$slide04;
	delete_option('yset',$headslide01,$headslide02,$headslide03,$headslide04,$slideurl01);
	echo '<div class="reset"><p>主题重设成功！</p></div>';
}
?>
<div class="LaoMoset">
<div class="slidebox"><div class="jcsz" id="basic"><p><h3><?php echo $LaoMo_Option['jbsz']?></h3></p></div>
<form  method="post">
<?php $options = get_option('yset');?>
<table>
<tr>
  <td width="221" height="41"><label for="select">幻灯图片01：</label></td>
  <td width="705">
  <div id="showimg">
  <?php
if($options['slide1']!=""){
echo '<img src="'.$options['slide1'].'" width="60" height="60" class="sopic"/>';
}
?></div>
  <input type="text" size="80" name="slideo" id="slideo" value="<?php echo $headslide01;?>" />
  <input type="file"  name="file"  class="upload" id="slideo" >
  </td>
</tr>
<tr>
  <td height="41"><label for="select">幻灯图片01链接</label></td>
  <td><input type="text" name="slideurl1" id="slideurl1" value="<?php echo $slideurl01;?>" class="slideinput"/></td>
</tr>
<tr>
</tr>
  <tr>
  <td>
  <label for="select">幻灯图片02：</label>
  <td>
  <div id="showimg">
  <?php
if($options['slide2']!=""){
echo '<img src="'.$options['slide2'].'" width="60" height="60" class="sopic"/>';
}
?>
  </div>
  <br>
  <input type="text" size="80" name="slidet" id="slidet" value="<?php echo $headslide02;?>" class="slideinput"/>
  <input type="file"  name="file"  class="upload" id="slidet" >
  </td>
  <tr>
  <td height="41"><label for="select">幻灯图片02链接</label></td>
  <td><input type="text" name="slideurl2" id="slideurl2" value="<?php echo $slideurl02;?>" class="slideinput"/></td>
</tr>
</tr>

<tr>
<td>
<label for="select">幻灯图片03：</label>

<td>
<div id="showimg">
<?php
if($options['slide3']!=""){
echo '<img src="'.$options['slide3'].'" width="60" height="60" class="sopic"/>';
}
?>
</div>
<input type="text" size="80" name="slidew" id="slidew" value="<?php echo $headslide03;?>" class="slideinput"/>
<input type="file"  name="file"  class="upload" id="slidew" >
</td>
</td>
  <tr>
  <td height="41"><label for="select">幻灯图片03链接</label></td>
  <td><input type="text" name="slideurl3" id="slideurl3" value="<?php echo $slideurl03;?>" class="slideinput"/></td>
</tr>
</tr>

<tr>
<td>
<label for="select">幻灯图片04：</label>
<td>
<div id="showimg">
<?php
if($options['slide4']!=""){
echo '<img src="'.$options['slide4'].'" width="60" height="60" class="sopic"/>';
}
?>
</div>
<input type="text" size="80" name="slidef" id="slidef" value="<?php echo $headslide04;?>" class="slideinput"/>
<input type="file"  name="file"  class="upload" id="slidef" >
</td>
</td>
  <tr>
  <td height="41"><label for="select">幻灯图片04链接</label></td>
  <td><input type="text" name="slideurl4" id="slideurl4" value="<?php echo $slideurl04;?>" class="slideinput"/></td>
</tr>
</tr>
</table>
<input type="submit" name="option-save" class="button-primary l" value="<?php _e('保存设置'); ?>" />
<div>
<input type="submit" name="reset" value="<?php _e('重置数据') ?>" class="button-primary r" />
</form>
</div>
</div>
<script>
	jQuery(document).ready(function(){
		var LaoMo_upload_frame;
		var value_id;
		jQuery('.upload').live('click',function(event){
				value_id =jQuery( this ).attr('id');
				(value_id)
				event.preventDefault();
				if( LaoMo_upload_frame ){
					LaoMo_upload_frame.open();
					return;
				}
				LaoMo_upload_frame = wp.media({
					title: '设置图片',
					button: {
						text: '设置图片',
					},
					multiple: false
				});
				LaoMo_upload_frame.on('select',function(){
					attachment = LaoMo_upload_frame.state().get('selection').first().toJSON();
					jQuery('input[name='+value_id+']').val(attachment.url); //返回数据
				});
				LaoMo_upload_frame.open();
		});

	});
</script>
<?php }?>