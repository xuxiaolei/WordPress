<?php
/*
老莫原创主题：Color Fell
Copy Right @ 2015.11 By LaoMo WordPress Theme 
版权所有：老莫博客:www.wp38.cn
*/
?>
<?php
function LaoMo_theme_shehui(){
global $post;
$options = get_option('shehui');
$LaoMo_Option=LaoMo_Option_Setting();
wp_enqueue_media();
wp_enqueue_style('thickbox');
if (isset($_REQUEST['shehui-save'])){
	$shhsh=$_REQUEST['shshow'];
	$ewma=$_REQUEST['erwema'];
	$erweima=$_REQUEST['erweimapic'];
	$qqshow=$_REQUEST['qqshowhidden'];
	$qqurl=$_REQUEST['qqlianjie'];
	$sinash=$_REQUEST['sinashowhidden'];
	$sinaurl=$_REQUEST['xinlangurl'];
	$txwbsh=$_REQUEST['tengxunshowhidden'];
	$txwburl=$_REQUEST['txweibourl'];
//提交表单
	$LaoMo_data=array("txweibourl"=>$txwburl,"tengxunshowhidden"=>$txwbsh,"shhshow"=>$shhsh,"erwema"=>$ewma,"erweimapic"=>$erweima,"sinashowhidden"=>$sinash,"xinlangurl"=>$sinaurl,"qqshowhidden"=>$qqshow,"qqlianjie"=>$qqurl,"xinlangurl"=>$sinaurl);	
	update_option('shehui',$LaoMo_data);
	$shehhshow=$shhsh;
	$ewmm=$ewma;
	$ewmp=$erweima;
	$qqsh=$qqshow;
	$qq=$qqurl;
	$sinax=$sinash;
	$sina=$sinaurl;
	$txweibo=$txwbsh;
	$tengxunweibourl=$txwburl;
	echo '<div><p>主题设置成功！</p></div>';
	}else{
	$shehhshow=$options['shhshow'];
	$ewmm=$options['erwema'];
	$ewmp=$options['erweimapic'];
	$qqsh=$options['qqshowhidden'];
	$qq=$options['qqlianjie'];
	$sinax=$options['sinashowhidden'];
	$sina=$options['xinlangurl'];
	$txweibo=$options['tengxunshowhidden'];
	$tengxunweibourl=$options['txweibourl'];
	}
if ( 'reset' == isset($_REQUEST['reset']) ){
	$shehhshow=$shhsh;
	$ewmm=$ewma;
	$ewmp=$erweima;
	$qqsh=$qqshow;
	$qq=$qqurl;
	$sinax=$sinash;
	$sina=$sinaurl;
	$txweibo=$txwbsh;
	$tengxunweibourl=$txwburl;
	delete_option('shehui',$shehhshow,$ewmm,$ewmp,$qqsh,$qq,$sinax,$sina,$txweibo,$tengxunweibourl);
	echo '<div class="reset"><p>主题重设成功！</p></div>';
}
?>
<div class="LaoMoset">
<div class="slidebox"><div class="jcsz" id="basic"><p><h3><?php echo $LaoMo_Option['shehui']?></h3></p></div>
<form  method="post">
<?php $options = get_option('shehui');?>
<table>
<tr><td width="271">二维码设置</td>
<td width="656"><label for="select">显示/隐藏:</label>
<select name="shshow" id="shshow" value="<?php echo $shehhshow;?>">
<?php

if($options['shhshow']==0 ){
echo '<option value="0">显示</option>';
echo '<option value="1">隐藏</option>';
}else{
echo '<option value="1">隐藏</option>';
echo '<option value="0">显示</option>';
}
?>
</select></td></tr>
<tr>
<td><label for="select">二维码图片上传：</label></td>
<td>
<div id="showimg">
<?php
if($options['erweimapic']!=""){
echo '<img src="'.$options['erweimapic'].'" width="60" height="60" class="sopic"/>';
}
?></div>
<input type="text" size="80" name="erweimapic" id="erweimapic" value="<?php echo $ewmp;?>"/>
<input type="file"  name="file"  class="upload" id="erweimapic" >
</td>
</tr>
<tr>
<td><label for="select">二维码链接地址：</label></td>
<td><input type="text" size="80" name="erwema" id="erwema" value="<?php echo $ewmm;?>"/></td>
</tr>


<tr><td>QQ社会化设置</td>
<td><label for="select">显示/隐藏:</label>
<select name="qqshowhidden" id="qqshowhidden" value="<?php echo $qqsh;?>">
<?php

if($options['qqshowhidden']==0 ){
echo '<option value="0">显示</option>';
echo '<option value="1">隐藏</option>';
}else{
echo '<option value="1">隐藏</option>';
echo '<option value="0">显示</option>';
}
?>
</select></td></tr>
<tr>
<td><label for="select">QQ链接地址</label></td>
<td><input type="text" size="80" name="qqlianjie" id="qqlianjie" value="<?php echo $qqurl;?>"/></td>
</tr>
<tr><td>新浪社会化设置</td>
<td><label for="select">显示/隐藏:</label>
<select name="sinashowhidden" id="sinashowhidden" value="<?php echo $sinax;?>">
<?php

if($options['sinashowhidden']==0 ){
echo '<option value="0">显示</option>';
echo '<option value="1">隐藏</option>';
}else{
echo '<option value="1">隐藏</option>';
echo '<option value="0">显示</option>';
}
?>
</select></td></tr>
<tr>
<td><label for="select">新浪微博链接地址</label></td>
<td><input type="text" size="80" name="xinlangurl" id="xinlangurl" value="<?php echo $sinaurl;?>"/></td>
</tr>
</table>
<input type="submit" name="shehui-save" class="button-primary l" value="<?php _e('保存设置'); ?>" />

</div>

<div>
<input type="submit" name="reset" value="<?php _e('重置数据') ?>" class="button-primary r" />
</form>
</div>
<script>
	jQuery(document).ready(function(){
		var LaoMo_upload_frame;
		var value_id;
		jQuery('.upload').live('click',function(event){
				value_id =jQuery( this ).attr('id');
				(value_id)
				event.preventDefault();
				if( LaoMo_upload_frame ){
					LaoMo_upload_frame.open();
					return;
				}
				LaoMo_upload_frame = wp.media({
					title: '设置图片',
					button: {
						text: '设置图片',
					},
					multiple: false
				});
				LaoMo_upload_frame.on('select',function(){
					attachment = LaoMo_upload_frame.state().get('selection').first().toJSON();
					jQuery('input[name='+value_id+']').val(attachment.url); //返回数据
				});
				LaoMo_upload_frame.open();
		});

	});
</script>
<?php }?>