<?php
/*
老莫原创主题：Color Fell
Copy Right @ 2015.11 By LaoMo WordPress Theme 
版权所有：老莫博客:www.wp38.cn
*/
?>
<?php
add_action('admin_menu','LaoMo_admin_menu');
	function LaoMo_admin_menu(){
	add_menu_page('主题设置','主题设置','edit_themes','theme-shell.php','LaoMo_get_save_page','',50,'LaoMo_Option_Setting');
	}                                
	add_action('admin_init','LaoMo_style');  
	function LaoMo_admin_set(){
		register_setting('LaoMo_user','LaoMo_options');
	}
	
	add_action('admin_menu','LaoMo_admin_submenu');
	function LaoMo_admin_submenu(){
	add_submenu_page('theme-shell.php','主题设置','幻灯设置','edit_themes','LaoMo_theme_save','LaoMo_theme_save');
	add_submenu_page('theme-shell.php','主题设置','广告设置','edit_themes','LaoMo_theme_gg','LaoMo_theme_gg');
	add_submenu_page('theme-shell.php','主题设置','社会化设置','edit_themes','LaoMo_theme_shehui','LaoMo_theme_shehui');
	}

	/*加载css样式*/
	function LaoMo_style(){
	 	wp_enqueue_style('LaoMotheme',get_template_directory_uri().'/function/css/admin.css');
	 	wp_enqueue_script('LaoMoscript',get_template_directory_uri().'/function/js/ColorPicker.js');
	}

	//后台选卡配置
	function LaoMo_Option_Setting(){
		$options = array(
			'cysz' => '常用设置',
			'jbsz' => '幻灯设置',
			'guanggao' => '广告设置',
			'shehui' => '社会化设置',
			'banquan' => '底部版权',
		);

	return $options;
	}
		print_r($LaoMo_Option);
		
?>