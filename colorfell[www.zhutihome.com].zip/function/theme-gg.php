<?php
/*
老莫原创主题：Color Fell
Copy Right @ 2015.11 By LaoMo WordPress Theme 
版权所有：老莫博客:www.wp38.cn
*/
?>
<?php
function LaoMo_theme_gg(){
global $post;
$options = get_option('adgg');
$LaoMo_Option=LaoMo_Option_Setting();
wp_enqueue_media();
wp_enqueue_style('thickbox');
if (isset($_REQUEST['option-save'])){
	$ggurl01=$_REQUEST['adggurl01'];
	$ggurl02=$_REQUEST['adggurl02'];
	$ggshow=$_REQUEST['hdshowo'];
	$adgg01=$_REQUEST['adggone'];
	$adgg02=$_REQUEST['adggtwo'];
	$adgg03=$_REQUEST['adggthree'];
	$adgg04=$_REQUEST['adggfour'];
//提交表单
	$LaoMo_data=array("hdggu1"=>$ggurl01,"hdggu2"=>$ggurl02,"hdshowone"=>$ggshow,"adgg1"=>$adgg01,"adgg2"=>$adgg02,"adgg3"=>$adgg03,"adgg4"=>$adgg04);	
	update_option('adgg',$LaoMo_data);
	$headggurl01=$ggurl01;
	$headggurl02=$ggurl02;
	$headggshow01=$ggshow;
	$headad01=$adgg01;
	$headad02=$adgg02;
	$headad03=$adgg03;
	$headad04=$adgg04;
	echo '<div><p>主题设置成功！</p></div>';
	}else{
	$headggshow01=$options['hdshowone'];
	$headggurl01=$options['hdggu1'];
	$headggurl02=$options['hdggu2'];
	$headad01=$options['adgg1'];
	$headad02=$options['adgg2'];
	$headad03=$options['adgg3'];
	$headad04=$options['adgg4'];
	}
if ( 'reset' == isset($_REQUEST['reset']) ){
	$headggurl01=$ggurl01;
	$headggurl02=$ggurl02;
	$headggshow01=$ggshow;
	$headad01=$adgg01;
	$headad02=$adgg02;
	$headad03=$adgg03;
	$headad04=$adgg04;
	delete_option('adgg',$headad01,$headad02,$headad03,$headad04,$headggshow01,$headggurl02,$headggurl01);
	echo '<div class="reset"><p>主题重设成功！</p></div>';
}
?>
<div class="LaoMoset">
<div class="slidebox"><div class="jcsz" id="basic"><p><h3><?php echo $LaoMo_Option['guanggao']?></h3></p></div>
<form  method="post">
<?php $options = get_option('adgg');?>
<table>
<tr><td>广告显示隐藏设置</td>
<td><label for="select">显示/隐藏:</label>
<select name="hdshowo" id="hdshowo" value="<?php echo $ggshow;?>">
<?php

if($options['hdshowone']==0 ){
echo '<option value="0">显示</option>';
echo '<option value="1">隐藏</option>';
}else{
echo '<option value="1">隐藏</option>';
echo '<option value="0">显示</option>';
}
?>
</select></td></tr>
<tr>
<td><label for="select">顶部广告01：</label></td>
<td>
<div id="showimg">
<?php
if($options['adgg1']!=""){
echo '<img src="'.$options['adgg1'].'" width="60" height="60" class="sopic"/>';
}
?></div>
<input type="text" size="80" name="adggone" id="adggone" value="<?php echo $headad01;?>" class="slide01"/>
<input type="file"  name="file"  class="upload" id="adggone" >
</td>
</tr>
<tr>
<td><label for="select">顶部广告01链接：</label></td>
<td><input type="text" size="80" name="adggurl01" id="adggurl01" value="<?php echo $headggurl01;?>"/></td>
</tr>


<tr>
<td>
<label for="select">顶部广告02：</label>
<td>
<div id="showimg">
<?php
if($options['adgg2']!=""){
echo '<img src="'.$options['adgg2'].'" width="60" height="60" class="sopic"/>';
}
?>
</div>
<br>
<input type="text" size="80" name="adggtwo" id="adggtwo" value="<?php echo $headad02;?>" class="slide02"/>
<input type="file"  name="file"  class="upload" id="adggtwo" >
</td>
</td>
<tr>
<td><label for="select">顶部广告02链接：</label></td>
<td><input type="text" size="80" name="adggurl02" id="adggurl02" value="<?php echo $headggurl02;?>"/></td>
</tr>
</tr>
</table>
<input type="submit" name="option-save" class="button-primary l" value="<?php _e('保存设置'); ?>" />

</div>

<div>
<input type="submit" name="reset" value="<?php _e('重置数据') ?>" class="button-primary r" />
</form>
</div>
<script>
	jQuery(document).ready(function(){
		var LaoMo_upload_frame;
		var value_id;
		jQuery('.upload').live('click',function(event){
				value_id =jQuery( this ).attr('id');
				(value_id)
				event.preventDefault();
				if( LaoMo_upload_frame ){
					LaoMo_upload_frame.open();
					return;
				}
				LaoMo_upload_frame = wp.media({
					title: '设置图片',
					button: {
						text: '设置图片',
					},
					multiple: false
				});
				LaoMo_upload_frame.on('select',function(){
					attachment = LaoMo_upload_frame.state().get('selection').first().toJSON();
					jQuery('input[name='+value_id+']').val(attachment.url); //返回数据
				});
				LaoMo_upload_frame.open();
		});

	});
</script>
<?php }?>