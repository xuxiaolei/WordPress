<?php
/*
老莫原创主题：Color Fell
Copy Right @ 2015.11 By LaoMo WordPress Theme 
版权所有：老莫博客:www.wp38.cn
*/
?>
<?php
function LaoMo_get_save_page(){
global $post;
$options = get_option('LaoMo_options');
wp_enqueue_media();
wp_enqueue_style('thickbox');
if ( 'option-save' == isset($_REQUEST['option-save']) ){
$topnav=$_REQUEST['topnav'];
$sitelogo=$_REQUEST['logo'];
$sitems=$_REQUEST['sitems'];
$keyword=$_REQUEST['keyword'];
$icon=$_REQUEST['icon'];
$indexshow=$_REQUEST['indexshow'];
$color1 = $_REQUEST['color1'];
$color2 = $_REQUEST['color2'];
echo $LaoMo_upload;
$LaoMo_data=array("color1"=>$color1,"color2"=>$color2,"topnav"=>$topnav,"indexshow"=>$indexshow,"sitelogo"=>$sitelogo,"sitems"=>$sitems,"keyword"=>$keyword,"icon"=>$icon);
if(update_option('LaoMo_options',$LaoMo_data)==1){
echo '<div class="reset"><p>主题设置成功！</p></div>';
}else{
echo "错误提示";
}
}
if ( 'reset' == isset($_REQUEST['reset']) ){
delete_option('LaoMo_options');
echo '<div class="reset"><p>主题重设成功！</p></div>';
}
$LaoMo_Option=LaoMo_Option_Setting();
?>
<div class="LaoMoset">
<div class="jbsz"><p><h3><?php echo $LaoMo_Option['cysz']?>
</h3>
<form method="post" enctype="multipart/form-data">
<?php $options = get_option('LaoMo_options');?>
<table border="0" cellspacing="5" cellpadding="5">
<tr><td>网站标志设置</td>
<td><label for="select">显示/隐藏:</label>
<select name="indexshow" id="setshow">
<?php
$options = get_option('LaoMo_options');
if($options['indexshow']==0 ){
echo '<option value="0">显示</option>';
echo '<option value="1">隐藏</option>';
}else{
echo '<option value="1">隐藏</option>';
echo '<option value="0">显示</option>';
}
?>
</select></td></tr>
<tr><td>顶部菜单显示与隐藏</td><td>
<label for="select">显示/隐藏</label>
<select name="topnav" id="sethidden">
<?php
$options = get_option('LaoMo_options');
if($options['topnav']==0 ){
echo '<option value="0">显示</option>';
echo '<option value="1">隐藏</option>';
}else{
echo '<option value="1">隐藏</option>';
echo '<option value="0">显示</option>';
}
?>
</select>
</td>
</tr>
</tr>
<tr>
<td><label for="select">顶部菜单颜色修改</label></td>
<td class="color">
<input type="text" name="color1" id="color1" value="<?php echo ($options['color1']);?>"/>
<script>CreateCPBtn('color1');</script>
<p>点击选择颜色修改即可</p>
</td></tr>
<tr>
<td><label for="select">底部菜单颜色修改</label></td>
<td class="color"><input type="text" name="color2" id="color2" value="<?php echo ($options['color2']);?>"/>
<script>window.CreateCPBtn('color2');</script>
<p>点击选择颜色即可</p>
</td>
</tr>
<td><label>网站标志:</label></td>
<?php
if($options['sitelogo']!=""){
echo '<img src="'.$options['sitelogo'].'" width="60" height="60"/>';
}
?>
<div id="showimg">
</div>
<td><input type="text" size="80" name="logo"  value="<?php echo($options['sitelogo']); ?>" class="logo"/>
<input type="file"  name="file"  class="upload" id="logo" >
<p>点击选择或填写你的标志地址保存即可</p></td>
<tr>
<td><label>网站描述:(Description)</label></td>
<td><textarea name="sitems"><?php echo  $options['sitems'];?></textarea>
<p>填写一句描述网站</p></td>
</tr>
<tr>
<td><label>关键词(KeyWord)：</label></td>
<td><textarea name="keyword" ><?php echo $options['keyword'];?></textarea>
<p>关键字搜索(这里影响SEO优化)</p></td>
</tr>
<tr>
<td><label>favicon图片地址</label></td>
<td><input name="icon" type="text" class="favicon" placeholder="http://www.gzwebsj.com/favicon.ico" value="<?php echo  $options['icon'];?>" size="50" maxlength="200">
<p>填写小图标图片地址</p>
</td></tr>
<div id="showimg">
</div>

</table>
<input type="submit" name="option-save" class="button-primary l" value="<?php _e('保存设置'); ?>" />
</form>
</div>
<form method="post">
<div>
<input type="submit" name="reset" value="<?php _e('重置数据') ?>" class="button-primary r" />
</div>
</form>
<div>
  <p>
  <p></div>
</div>
<script>
	jQuery(document).ready(function(){
		var LaoMo_upload_frame;
		var value_id;
		jQuery('.upload').live('click',function(event){
				value_id =jQuery( this ).attr('id');
				(value_id)
				event.preventDefault();
				if( LaoMo_upload_frame ){
					LaoMo_upload_frame.open();
					return;
				}
				LaoMo_upload_frame = wp.media({
					title: '设置图片',
					button: {
						text: '设置图片',
					},
					multiple: false
				});
				LaoMo_upload_frame.on('select',function(){
					attachment = LaoMo_upload_frame.state().get('selection').first().toJSON();
					jQuery('input[name='+value_id+']').val(attachment.url); //返回数据
				});
				LaoMo_upload_frame.open();
		});

	});
</script>
<?php }?>