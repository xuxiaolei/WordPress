<?php
/*
老莫原创主题：Color Fell
Copy Right @ 2015.11 By LaoMo WordPress Theme 
版权所有：老莫博客:www.wp38.cn
*/
?>
<?php
/*背景和链接颜色样式表*/
function getcolor($str){
$options = get_option('LaoMo_options');
echo 'style=';
echo 'color:';
echo getop('color1');
echo ';';
}

/*侧栏栏目标题样式表*/
function sidebarcolor($str){
$options = get_option('LaoMo_options');
echo "<h3";
echo " ";
echo "style=";
echo "color:";
echo getop('color1');
echo ";";
echo "border-left:";
echo "solid";
echo ";";
echo ">";
}

/*顶部导航颜色*/
function headcolor($str){
$options = get_option('LaoMo_options');
echo 'style=';
echo 'background:';
echo getop('color1');
echo ';';
}

/*整站链接鼠标经过颜色*/
function linkover($str){
$options = get_option('LaoMo_options');
echo "onmouseover=";
echo "this.style.color=";
echo "'";
echo getop('color1');
echo "'";
echo " ";
echo "onmouseout=";
echo "this.style.color=";
echo "'#686868'";
}

/*侧栏栏目标题样式表*/
function singlelinkcolor($str){
$options = get_option('LaoMo_options');
echo "<h3";
echo " ";
echo "style=";
echo "color:";
echo getop('color1');
echo ";";
}

/** 
 * 面包屑导航
 */
function laoMopublic() {
    $delimiter = '<b>&raquo;</b>';
    $before = '<span class="Current">';
    $after = '</span>';
    if (!is_home() && !is_front_page() || is_paged()) {
        echo __('<i class="indexhome"></i>', 'LaoMo');
        global $post;
        $homeLink = home_url();
        echo '<a itemprop="breadcrumb" class=indexlink href="' . $homeLink . '">' . __('首页', 'LaoMo') . '</a> ' . $delimiter . ' ';
        if (is_category()) {
            global $wp_query;
            $cat_obj = $wp_query->get_queried_object();
            $thisCat = $cat_obj->term_id;
            $thisCat = get_category($thisCat);
            $parentCat = get_category($thisCat->parent);
            if ($thisCat->parent != 0) {
                $cat_code = get_category_parents($parentCat, TRUE, ' ' . $delimiter . ' ');
                echo $cat_code = str_replace('<a', '<a itemprop="breadcrumb"', $cat_code);
            }
            echo $before . '' . single_cat_title('', false) . '' . $after;
        } elseif (is_day()) {
            echo '<a itemprop="breadcrumb" class=indexlink href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' ';
            echo '<a itemprop="breadcrumb" class=indexlink href="' . get_month_link(get_the_time('Y') , get_the_time('m')) . '">' . get_the_time('F') . '</a> ' . $delimiter . ' ';
            echo $before . get_the_time('d') . $after;
        } elseif (is_month()) {
            echo '<a itemprop="breadcrumb" class=indexlink href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' ';
            echo $before . get_the_time('F') . $after;
        } elseif (is_year()) {
            echo $before . get_the_time('Y') . $after;
        } elseif (is_single() && !is_attachment()) {
            if (get_post_type() != 'post') {
                $post_type = get_post_type_object(get_post_type());
                $slug = $post_type->rewrite;
                echo '<a itemprop="breadcrumb" class=indexlink href="' . $homeLink . '/' . $slug['slug'] . '/">' . $post_type->labels->singular_name . '</a> ' . $delimiter . ' ';
                echo $before . '正文' . $after;
            } else {
                $cat = get_the_category();
                $cat = $cat[0];
                $cat_code = get_category_parents($cat, TRUE, ' ' . $delimiter . ' ');
                echo $cat_code = str_replace('<a', '<a itemprop="breadcrumb"', $cat_code);
                echo $before . '正文' . $after;
            }
        } elseif (!is_single() && !is_page() && get_post_type() != 'post') {
            $post_type = get_post_type_object(get_post_type());
            echo $before . $post_type->labels->singular_name . $after;
        } elseif (is_attachment()) {
            $parent = get_post($post->post_parent);
            $cat = get_the_category($parent->ID);
            $cat = $cat[0];
            echo '<a itemprop="breadcrumb" class=indexlink href="' . get_permalink($parent) . '">' . $parent->post_title . '</a> ' . $delimiter . ' ';
            echo $before . '正文' . $after;
        } elseif (is_page() && !$post->post_parent) {
            echo $before . '正文' . $after;
        } elseif (is_page() && $post->post_parent) {
            $parent_id = $post->post_parent;
            $breadcrumbs = array();
            while ($parent_id) {
                $page = get_page($parent_id);
                $breadcrumbs[] = '<a itemprop="breadcrumb" class=indexlink href="' . get_permalink($page->ID) . '">' . get_the_title($page->ID) . '</a>';
                $parent_id = $page->post_parent;
            }
            $breadcrumbs = array_reverse($breadcrumbs);
            foreach ($breadcrumbs as $crumb) echo $crumb . ' ' . $delimiter . ' ';
            echo $before . '正文' . $after;
        } elseif (is_search()) {
            echo $before;
            printf(__('搜索: %s', 'LaoMo') , get_search_query());
            echo $after;
        } elseif (is_tag()) {
            echo $before;
            printf(__('标签： %s', 'LaoMo') , single_tag_title('', false));
            echo $after;
        } elseif (is_author()) {
            global $author;
            $userdata = get_userdata($author);
            echo $before;
            printf(__('作者: %s', 'LaoMo') , $userdata->display_name);
            echo $after;
        } elseif (is_404()) {
            echo $before;
            _e('Not Found', 'LaoMo');
            echo $after;
        }
            
        }
    }
	
	function mzw_posts_list($orderby,$limit,$cat) {

	$args = array(
		'order'            => DESC,
		'cat'              => $cat,
		'orderby'          => $orderby,
		'showposts'        => $limit,
		'caller_get_posts' => 1
	);

	query_posts($args);
	echo '<div class="smart_post"><ul>';
	while (have_posts()) : 
		the_post(); 
		global $post;
		echo '<li class="clearfix">';
		echo '<div class="post-thumb">';
		echo post_thumbnail(45, 45, false); 
		echo '</div>';
		echo '<div class="post-right">';
		echo '<h3><a href="'.get_permalink().'">';
		the_title();
		echo '</a></h3><div class="post-meta"><span>';
		comments_popup_link('No Reply', '1 Reply', '% Replies');
		echo '</span> | <span>';
		mzw_post_views(' Views');
		echo '</span></div></div>';
		echo '</li>';
    endwhile; wp_reset_query();
	echo '</ul></div>';
}

function mzw_readers_list($out,$tim,$lim,$addlink){
	global $wpdb;
	$counts = $wpdb->get_results("select count(comment_author) as cnt, comment_author, comment_author_url, comment_author_email from (select * from $wpdb->comments left outer join $wpdb->posts on ($wpdb->posts.id=$wpdb->comments.comment_post_id) where comment_date > date_sub( now(), interval $tim day ) and user_id='0' and comment_author != '".$out."' and post_password='' and comment_approved='1' and comment_type='') as tempcmt group by comment_author order by cnt desc limit $lim");
	foreach ($counts as $count) {
		$c_url = $count->comment_author_url;
		if ($c_url == '') $c_url = 'javascript:;';

		if($addlink == 'on'){
			$c_urllink = ' href="'. $c_url . '"';
		}else{
			$c_urllink = '';
		}
		$type .= '<a title="['.$count->comment_author.']" target="_blank"'.$c_urllink.'>'.get_avatar( $count->comment_author_email, $size = '36' , '' ) .'</a>';
	}
	return $type;
}

function mzw_recent_comment_list($lim,$addlink){
	$my_email = get_bloginfo ('admin_email');
	$counts = get_comments('number=200&status=approve&type=comment'); 
	$i = 1;
	foreach ($counts as $count) {
		if ($count->comment_author_email != $my_email) {
			$c_url = $count->comment_author_url;
			if ($c_url == '') $c_url = 'javascript:;';
			if($addlink == 'on'){
				$c_urllink = ' href="'. $c_url . '"';
			}else{
				$c_urllink = ' href="javascript:;"';
			}
			echo '<li class="recentcomments clearfix"><div class="alignleft">'.get_avatar( $count->comment_author_email, $size = '45' , '' ).
			'</div><div class="comment-right"><span class="comment-author"><a'.$c_urllink.'>'.$count->comment_author.'</a>: </span><div class="comment-c"><a href="'.
			get_permalink($count->comment_post_ID).'#comment-'.$count->comment_ID.'">'.$count->comment_content.
			'</a></div></div></li>';
			if ($i == $lim) break;
			$i++;
		}
	}
}

?>