jQuery(document).ready(function){
        jQuery('#basic').click(function()){
            $("LaoMoset").toggle();
        });
    });

