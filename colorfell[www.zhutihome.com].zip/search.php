<?php
/*
老莫原创主题：Color Fell
Copy Right @ 2015.11 By LaoMo WordPress Theme 
版权所有：老莫博客:www.wp38.cn
*/
?>
<?php get_header(); ?>
<div class="contentsearch">
	<div class="wrapper">
		<div class="box">
			<?php laoMopublic(); ?>
		</div>
		<div class="main">
				<h3 class="h3">搜索结果</h3>
				<div class="">
				<?php 
				if ( have_posts() ) : 
				   get_template_part( 'inc/theme-search'); 
				   else : _e('<div>对不起，没找到你搜索内容。</div>');
				   endif;
				   ?>
			</div>
		</div>
	</div>
</div>

<?php get_footer(); ?>