<?php
/*
老莫原创主题：Color Fell
Copy Right @ 2015.11 By LaoMo WordPress Theme 
版权所有：老莫博客:www.wp38.cn
*/
?>
<div class="box">
<div class="catpage">
<div class="content">
<div class="leftbox">
<?php if ( have_posts() ) : while (have_posts()) : the_post(); ?>
<div class="leftwzbox">
<div class="wzbox">
<div class="Thumbs" id="thumb"><a href="<?php the_permalink();?>"><span class="thumbpic" style="display: none;"><?php echo excerpttitle(30);?> <p class="thumbimg"></p></span></a>
<a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><img src="<?php echo default_images(); ?>" alt="<?php the_title(); ?>"/><base target="_blank"></div></a>
<li><a <?php echo linkover('color1');?> href="<?php the_permalink();?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><base target="_blank">
<h4><?php echo excerpttitle(50);?></h4></li>
</a>
<div class="Abstract"><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 300,"..."); ?>
</div>
<div class="wz-tags"><dd></dd>
	<span class="tagspic"></span><span><?php echo the_tags('标签：', ' ', '');?></span>
</div>
	<div class="thetime"><span></span>发布时间：<?php the_time( 'Y年n月j日' ); ?></div><div class="zuozhe"><span></span>作者：<?php the_author(); ?></div>
<div class="wz-db">
<a <?php echo linkover('color1');?> href="<?php the_permalink(); ?>"><base target="_blank"><p>更多阅读</p></a>
</div>
</div>
</div>
<?php endwhile; endif;?>
<?php echo LaoMo_pagenavi();?>
</div>
	<div class="leftsidebar">
		<div class="sidebar">
			<?php get_sidebar(); ?>
		</div>
	</div>
</div>
</div>
</div>
