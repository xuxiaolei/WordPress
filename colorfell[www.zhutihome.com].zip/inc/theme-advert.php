<?php
/*
老莫原创主题：Color Fell
Copy Right @ 2015.11 By LaoMo WordPress Theme 
版权所有：老莫博客:www.wp38.cn
*/
?>
<div class="adgg">
<?php
	if(get_option('adgg')['hdshowone'] == 0){
	echo "<div class=adh200>";
	echo "<a href=";
	echo get_option('adgg')['hdggu1'];
	echo ">";
	echo "<img src=";
	echo get_option('adgg')['adgg1'];
	echo ">";
	echo "</a>";
	echo "</div>";
	echo "<div class=adh100>";
	echo "<a href=";
	echo get_option('adgg')['hdggu2'];
	echo ">";
	echo "<img src=";
	echo get_option('adgg')['adgg2'];
	echo ">";
	echo "</a>";
	echo "</div>";
} 
?>
</div>