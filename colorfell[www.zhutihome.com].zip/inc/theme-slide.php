<?php
/*
老莫原创主题：Color Fell
Copy Right @ 2015.11 By LaoMo WordPress Theme 
版权所有：老莫博客:www.wp38.cn
*/
?>
<div class="slide">
        <div class="hdflash f_list">
                <div class="slidelist">
                    <div class="f_out">
                        <a href="<?php echo get_option('yset')['slideu01'];?>" target="_blank">
                            <img src="<?php echo get_option('yset')['slide1'];?>"/>
                        </a>
                    </div>
                    <div class="f_out">
                        <a href="<?php echo get_option('yset')['slideu02'];?>" target="_blank">
                            <img src="<?php echo get_option('yset')['slide2']; ?>"/>
                        </a>
                    </div>

                    <div class="f_out">
                        <a href="<?php echo get_option('yset')['slideu03'];?>" target="_blank">
                            <img src="<?php echo get_option('yset')['slide3']; ?>"/>
                        </a>
                    </div>

                    <div class="f_out">
                        <a href="<?php echo get_option('yset')['slideu04'];?>" target="_blank">
                            <img src="<?php echo get_option('yset')['slide4']; ?>"/>
                        </a>
                    </div>
                    
                    <div class="flash_tab">
                        <div class="tabs f_tabs" style="width:330px;">
                            <ul>
                                <li class="f_tab opdiv">
                                    <a href="javascript:void(0);">
                                    </a>
                                </li>
                                <li class="f_tab opdiv">
                                    <a href="javascript:void(0);">
                                    </a>
                                </li>
                                <li class="f_tab opdiv">
                                    <a href="javascript:void(0);">
                                    </a>
                                </li>
                                <li class="f_tab opdiv">
                                    <a href="javascript:void(0);">
                                    </a>
                                </li>
    
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>