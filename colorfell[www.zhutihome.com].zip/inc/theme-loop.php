<?php
/*
老莫原创主题：Color Fell
Copy Right @ 2015.11 By LaoMo WordPress Theme 
版权所有：老莫博客:www.wp38.cn
*/
?>
<div class="box">
<div class="content">
<div class="leftbox singlebg">
<div class="publicbar">
<?php if (function_exists('laoMopublic')) laoMopublic(); ?> 
<div class="sg-post">
<span><?php the_time('Y-n-j'); ?>&nbsp;·&nbsp;</span>
<span>发表于: <a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a>&nbsp;·</span>
<span><?php post_views(' ',' 评论 '); ?>&nbsp;·&nbsp;</span>
<span><?php comments_popup_link ('0 回复','1 回复','% 回复'); ?>&nbsp;</span>
</div>
</div>

<div class="singlenr">
<?php if (have_posts()) : the_post(); update_post_caches($posts); setPostViews(get_the_ID()); ?>  
<div class="single">
<div class="sg750" >
<ul>
<li <?php echo singlelinkcolor('color1');?>>
<h3 title="<?php the_title_attribute(); ?>"><?php the_title(); ?></h3></li>
</li>
</ul>
<div class="single-nr"><?php the_content(); ?>
</div>
</div>
<div class="sg320">
<?php else : ?>
<div class="error">没有文章!</div>
<?php endif ; ?>
</div>
</div>
<div class="ilike" <?php echo headcolor('color1');?>>
<a href="javascript:;" data-action="ding" data-id="<?php the_ID(); ?>" class="favorite<?php if(isset($_COOKIE['bigfa_ding_'.$post->ID])) echo ' done';?>">喜欢 <span class="count">
<?php if( get_post_meta($post->ID,'bigfa_ding',true) ){            
echo get_post_meta($post->ID,'bigfa_ding',true);
} else {
echo '0';
}?></span>
</a>
</div>
</div>
<div class="wzcopyright">
<?php   $custom_fields = get_post_custom_keys($post_id);
if (!in_array ('copyright', $custom_fields)) : ?>

<div class="postcopyright">
<strong>【声明】</strong>本文为老莫编译，转载请注明出自<a <?php echo linkover('color1');?> href="<?php the_permalink() ?>" title=<?php the_title(); ?>><strong>老莫博客</strong></a>
<br/>
并保留本文有效链接：<a  <?php echo linkover('color1');?> href="<?php the_permalink()?>" title=<?php the_title(); ?>><?php the_title(); ?></a> , 转载请保留本声明！
<div class="share"><h4>分享到：</h4>      
<a class="sinaweibo" target="_blank" rel="nofollow" href="http://v.t.sina.com.cn/share/share.php?&url=<?php the_permalink(); ?>&title=<?php the_title(''); ?>" class="sina-share" title="新浪微博"><p></p></a>  
 
<a class="tengxunweibo" target="_blank" rel="nofollow" href="http://v.t.qq.com/share/share.php?title=<?php the_title(''); ?>&url=<?php the_permalink(); ?>&site=http://yfdxs.com/" class="tencent-share" title="腾讯微博"><p></p></a> 
  
<a class="qqkongjian" target="_blank" rel="nofollow" href="http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=<?php the_permalink(); ?>&title=<?php the_title(''); ?>&desc=&summary=&site=" class="qq-share" title="QQ空间"><p></p></a> 
</div>
</div>
<?php else: ?>

<?php  $custom = get_post_custom($post_id);
$custom_value = $custom['copyright']; ?>
<div class="postcopyright">
<strong>【说明】</strong> 本文参考自：<a target="_blank" rel="nofollow" href="<?php echo $custom_value[0] ?>" ><?php echo $custom_value[0] ?></a> , 由老莫(<a href="http://www.85blog.com">85blog.com</a>)整理编辑.
<br/>
本文链接地址：<a href="<?php the_permalink()?>" title=<?php the_title(); ?>><?php the_title(); ?></a> , 转载请保留本说明！
</div>
<?php endif; ?>

</div>
<?php
if (get_post_type()=='post' ){
$categories = get_the_category();
$tags = get_the_tag_list();
if($tags)
echo '<div class="singletag"><dd></dd><span>'.$tags.'</span></div>';
}
?>

<div class="nextpost">
	<span class="nextl" >
	<?php 
		if(get_previous_post()){
			previous_post_link("上一篇: %link","%title",true);
		} else {
			echo "该分类没有了";
		}; ?>
	</span>
	<span class="nextr">
	<?php 
		if(get_next_post()){
			next_post_link("下一篇: %link","%title",true);
		} else {
			echo "该分类没有了";
		}; ?>
	</span>
</div>
</div>

<?php comments_template(); ?>
<div class="sidebar">
<?php get_sidebar(); ?>
</div>

</div>
</div>

