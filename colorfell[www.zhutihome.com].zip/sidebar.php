<?php
/*
老莫原创主题：Color Fell
Copy Right @ 2015.11 By LaoMo WordPress Theme 
版权所有：老莫博客:www.wp38.cn
*/
?>
<?php
if(is_home() || is_front_page()) { //Ê×Ò³ÏÔÊ¾¡°Ê×Ò³²àÀ¸¡±
    if (function_exists('dynamic_sidebar') && dynamic_sidebar('widget_homesidebar')){}
}
?>

<?php
if ( is_single() || is_category()) {//ÎÄÕÂÒ³ÏÔÊ¾ ¡°ÎÄÕÂÒ³²àÀ¸¡±
    if (function_exists('dynamic_sidebar') && dynamic_sidebar('widget_postsidebar')){}
}
?>

