<?php
/*
老莫原创主题：Color Fell
Copy Right @ 2015.11 By LaoMo WordPress Theme 
版权所有：老莫博客:www.wp38.cn
*/
?>
<div class="footer" style="background:<?php echo getop('color2');?>">
<div class="footerbox">
<span>老莫原创主题 | Theme By <a href="<?php echo bloginfo('url');?>">LaoMo.1.0 Beta</span><br>
<span>本站基于 | <a href="http://www.wordpress.org">Woredpress</a>博客程序建立</span>
</div>
</div>
<?php if (is_home()){ ?>
<script type="text/javascript">
    FeatureList(".f_list", {
        "onclass": "noopdiv",
        "offclass": "opdiv",
        "pause_on_act": "mouseover",
        "interval": 1800,
        "speed": 4
    });
</script>
<script type="text/javascript">
$.fn.postLike = function() {
	if ($(this).hasClass('done')) {
		return false;
	} else {
		$(this).addClass('done');
		var id = $(this).data("id"),
		action = $(this).data('action'),
		rateHolder = $(this).children('.count');
		var ajax_data = {
			action: "bigfa_like",
			um_id: id,
			um_action: action
		};
		$.post("/wp-admin/admin-ajax.php", ajax_data,
		function(data) {
			$(rateHolder).html(data);
		});
		return false;
	}
};
$(document).on("click", ".favorite",
function() {
	$(this).postLike();
});
</script>
<?php } ?>

<script type="text/javascript" src="<?php bloginfo('template_directory');?>/js/top.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory');?>/js/js.js"></script>

<?php if ( is_home()) {  ?>

<?php } ?>
</body>