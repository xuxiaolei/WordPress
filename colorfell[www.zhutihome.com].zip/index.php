<?php
/*
老莫原创主题：Color Fell
Copy Right @ 2015.11 By LaoMo WordPress Theme 
版权所有：老莫博客:www.wp38.cn
*/
?>
<?php get_header();?>
<?php get_template_part( 'content', get_post_format() );?>
<?php get_footer()?>