<?php
/*
老莫原创主题：Color Fell
Copy Right @ 2015.11 By LaoMo WordPress Theme 
版权所有：老莫博客:www.wp38.cn
*/
?>
<div class="box">
<div class="contentmain">
<div class="adgg">
<div class="adggbox">
<?php 
if(get_option('adgg')['hdshowone'] == 0){
	echo "<div class=adh200>";
	echo "<a href=";
	echo get_option('adgg')['hdggu1'];
	echo ">";
	echo "<img src=";
	echo get_option('adgg')['adgg1'];
	echo ">";
	echo "</a>";
	echo "</div>";
	echo "<div class=adh100>";
	echo "<a href=";
	echo get_option('adgg')['hdggu2'];
	echo ">";
	echo "<img src=";
	echo get_option('adgg')['adgg2'];
	echo ">";
	echo "</a>";
	echo "</div>";
}?>
</div>
</div>
<div><?php include('inc/theme-slide.php');?></div>

<div class="shehui">
<div class="shehuileft">
<div class="zxwz">
<li><h4 <?php echo getcolor('color1');?>">最新文章</h4>
<li><?php $post_query = new WP_Query('showposts=4'); 
while ($post_query->have_posts()) : $post_query->the_post(); $do_not_duplicate = $post->ID; ?><p></p>
<a <?php echo linkover('color1');?> href="<?php the_permalink();?>"><?php echo excerpttitle(15);?><br></a> 
<?php endwhile;?> 
</li></li>
</div>
<div class="sjwz">
<li><h4 <?php echo getcolor('color1');?>">随机文章</h4>
<li>
<?php
  global $post;
  $postid = $post->ID;
  $args = array( 'orderby' => 'rand', 'post__not_in' => array($post->ID), 'showposts' => 4);
  $query_posts = new WP_Query();
  $query_posts->query($args);
?>
<?php while ($query_posts->have_posts()) : $query_posts->the_post(); ?>
<p></p><li><a <?php echo linkover('color1');?> href="<?php the_permalink();?>" title="<?php the_title_attribute();?>"><?php echo excerpttitle(15);?><br></a></li>
<?php endwhile;?>
</li>
</li>
</div>


</div>

<div class="shehuiright"><p>微信扫一扫，加关注</p>
<div class="erweima">
<?php if (get_option('shehui')['shhshow'] == 0){
	echo "<a href=";
	echo get_option('shehui')['erwema'];
	echo ">";
	echo "<img src=";
	echo get_option('shehui')['erweimapic'];
	echo ">";
	echo "</a>";
}else{
	echo "";
}
?>
</div>

<div class="shehuidiv">
<div class="sinaweibo shehuili">
<?php if(get_option('shehui')['xinlangurl'] == 0){
	echo "<li>";
	echo "<a href=";
	echo get_option('shehui')['xinlangurl'];
	echo ">";
	echo "<span class=qqshehui";
	echo "></span>";
	echo "</a>";
	echo "</li>";
}else{
	echo "";
}
?>
</div>


<div class="qqpic shehuili">
<?php if(get_option('shehui')['qqshowhidden'] == 0){
	echo "<li>";
	echo "<a href=";
	echo get_option('shehui')['qqlianjie'];
	echo ">";
	echo "<span class=qqshehui";
	echo "></span>";
	echo "</a>";
	echo "</li>";
}else{
	echo "";
}
?>
</div>
</div>
</div>

<div class="shicon">
</div>
</div>
<div class="leftbox">
<?php if ( have_posts() ) : while (have_posts()) : the_post(); ?>
<div class="leftwzbox">
<div class="wzbox">

<div class="Thumbs" id="thumb"><a href="<?php the_permalink();?>"><span class="thumbpic" style="display: none;"><?php echo excerpttitle(30);?> <p class="thumbimg"></p></span></a>
<a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><img src="<?php echo default_images(); ?>" alt="<?php the_title(); ?>"/><base target="_blank"></div></a>

	<li><a <?php echo linkover('color1');?> href="<?php the_permalink();?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><base target="_blank">
<h4><?php echo excerpttitle(50);?></h4></li>
</a>
<div class="Abstract"><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 300,"..."); ?>
</div>
<div class="wz-tags"><dd></dd>
	<span class="tagspic"></span><span><?php echo the_tags('标签：', ' ', '');?></span>
</div>
	<div class="thetime"><span></span>发布时间：<?php the_time( 'Y年n月j日' ); ?></div><div class="zuozhe"><span></span>作者：<?php the_author(); ?></div>
<div class="wz-db">
<a <?php echo linkover('color1');?> href="<?php the_permalink(); ?>"><base target="_blank"><p>更多阅读</p></a>
</div>
</div>
</div>
<?php endwhile; endif;?>
<?php echo LaoMo_pagenavi();?>
</div>
<div class="leftsidebar">
<div class="sidebar">
<?php get_sidebar(); ?>
</div>
</div>
</div>