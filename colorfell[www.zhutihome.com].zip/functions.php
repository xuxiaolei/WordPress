<?php
/*
老莫原创主题：Color Fell
Copy Right @ 2015.11 By LaoMo WordPress Theme 
版权所有：老莫博客:www.wp38.cn
*/
?>
<?php
//后台处理过程
global $options;
add_theme_support('post-formats');
if (is_admin() ){
get_template_part('function/theme-function');
}

add_filter('pre_option_link_manager_enabled','__return_true');

if(function_exists('register_nav_menu')){
register_nav_menu('topmenu','顶部导航');
register_nav_menu('mainmenu','网站导航');
}

require_once("function/theme-shell.php");

require_once ("function/theme-basic.php");

require_once ("function/theme-gg.php");

require_once ("function/theme-shehui.php");

require_once ("function/sidebar-inc.php");

require_once ("inc/theme-public.php"); 


function upload_code($code_path) { /*检查是否有上传文件或者文件上传是否错误*/
define( 'AVATARS_PATH', ABSPATH.'/wp-content/uploads/newpost/' );/*定义上传路径*/
$filetype=array("jpg","gif","bmp","jpeg","png"); /*限制上传类型*/
$ext = pathinfo($code_path['name']);/*返回文件路径*/
$ext = strtolower($ext['extension']);/*转换为小写*/
$tempFile = $code_path['tmp_name'];/*临时文件目录*/
$hdPath   = AVATARS_PATH;/*服务器保存文件的路径*/
if( !is_dir($hdPath) ){ /*意思是如果没有这个路径 就创建他*/
mkdir($hdPath,0755,true);
}
$new_file_name = md5(time()).'.'.$ext;	/*重新命名文件名 我采用的是 md5加时间戳*/
$hdtFile = $hdPath . $new_file_name;  /*保存路径*/
if(!in_array($ext, $filetype)){ /*in_array 查找数组值 我上传的是RAR文件 而$filetype 文件类型里没有exe 就会返回false */
echo '仅允许上传JPG、GIF、BMP、PNG图片';
}else{
move_uploaded_file($tempFile,$hdtFile);/*php 上传之移动文件*/
if( !file_exists( $hdtFile ) ){ /*php上传之 检查服务器端是否存在上传目录*/
echo '上传失败';
}else{
$imageInfo = getimagesize($hdtFile);/*php自带函数 用来获取 上传图片的图片的高与宽 失败返回 false*/
if($imageInfo!== false) {
$imageType = strtolower(substr(image_type_to_extension($imageInfo[2]),1))/*返回文件类型 */;
$info = array( /*把图片信息以数组的形式保存*/
"width"     =>$imageInfo[0],
"height"    =>$imageInfo[1],
"type"      =>$imageType,
"mime"      =>$imageInfo['mime'],
);	
$img = $new_file_name; /**/
return $img;

}else{
echo "图片不存在";
}
}
}
}
function getop($str){
$options = get_option('LaoMo_options'); /*获取配置*/
echo $options[$str];
}
print_r($options);


//注册全站小工具侧栏
if ( function_exists('register_sidebar') ) {
register_sidebar(array(
'name'          => '首页侧栏',
'id'            => 'widget_homesidebar',
'before_widget' => '<li id="%1$s">',
'after_widget' => '</li>',
'before_title' => '<h2>',
'after_title' => '</h2>',
));
register_sidebar(array(
'name'          => '文章页侧栏',
'id'            => 'widget_postsidebar',
'before_widget' => '<li id="%1$s">',
'after_widget' => '</li>',
'before_title' => '<h2>',
'after_title' => '</h2>',
));

}

// 添加特色图像功能
add_theme_support('post-thumbnails');
set_post_thumbnail_size(130, 100, true); // 图片宽度与高度，图片的长宽可以自行修改。

function my_function_admin_bar(){ return false; } add_filter( 'show_admin_bar' , 'my_function_admin_bar');

//文章浏览次数
function record_visitors() {
if (is_singular()) {
global $post;
$post_ID = $post->ID;
if ($post_ID) {
$post_views = (int)get_post_meta($post_ID, 'views', true);
if (!update_post_meta($post_ID, 'views', ($post_views + 1))) {
add_post_meta($post_ID, 'views', 1, true);
}
}
}
}
add_action('wp_head', 'record_visitors');
function post_views($before = '(点击', $after = '次) ', $echo = 1) {
global $post;
$post_ID = $post->ID;
$views = (int)get_post_meta($post_ID, 'views', true);
if ($echo) echo $before, number_format($views) , $after;
else return $views;
};

//浏览次数  
function getPostViews($postID){           
$count_key = 'post_views_count';           
$count = get_post_meta($postID, $count_key, true); 
if($count==''){      
delete_post_meta($postID, $count_key);      
add_post_meta($postID, $count_key, '0');      
return "0";      
}      
return $count;      
}     
function setPostViews($postID) {  
$count_key = 'post_views_count';    
$count = get_post_meta($postID, $count_key, true);        
if($count==''){      
$count = 0;      
delete_post_meta($postID, $count_key);      
add_post_meta($postID, $count_key, '0');      
}else{          
$count++;      
update_post_meta($postID, $count_key, $count);      
}      
}  

/**
* 获取WordPress所有分类名字和ID
*/
function show_category(){
global $wpdb;
$request = "SELECT $wpdb->terms.term_id, name FROM $wpdb->terms ";
$request .= " LEFT JOIN $wpdb->term_taxonomy ON $wpdb->term_taxonomy.term_id = $wpdb->terms.term_id ";
$request .= " WHERE $wpdb->term_taxonomy.taxonomy = 'category' ";
$request .= " ORDER BY term_id asc";
$categorys = $wpdb->get_results($request);
foreach ($categorys as $category) { //调用菜单
$output = '<a href="'.get_category_link($category->term_id).'" target="_blank">'.$category->name."[<em>".$category->term_id.'</em>]</a>';
echo $output;
}
}

//手动分页
function LaoMo_pagenavi() {
global $wp_query, $wp_rewrite;
$pages = '';
$max = $wp_query->max_num_pages;
if (!$current = get_query_var('paged')) $current = 1;
$args['base'] = str_replace(999999999, '%#%', get_pagenum_link(999999999));
$args['total'] = $max;
$args['current'] = $current;
$total = 1;
$args['mid_size'] = 3;
$args['end_size'] = 1;
$args['prev_text'] = '<span>上一页</span>';
$args['next_text'] = '<span>下一页</span>';
if ($max > 1) echo '<div class="navtext navout">';
echo $pages . paginate_links($args);
if ($max > 1) echo '</div>';
}


//首页缩略图
function default_images() {
global $post, $posts;
$first_img = '';
ob_start();
ob_end_clean();
if(has_post_thumbnail()){
$post_id = ( null === $post_id ) ? get_the_ID() : $post_id;
$thumbnail_id = get_post_thumbnail_id($post->ID);
$thumb = wp_get_attachment_image_src($thumbnail_id, $size);
return $thumb[0];
}
else{
return $first_img = get_bloginfo("template_url")."/images/noimage.gif" ;
}
}

function excerpttitle($max_length) {
$title_str = get_the_title();
if (mb_strlen($title_str,'utf-8') > $max_length ) {
$title_str = mb_substr($title_str,0,$max_length,'utf-8').'…';
}
return $title_str;
}

add_action( 'widgets_init', create_function('', 'return register_widget("LaoMoseach");') );
add_action( 'widgets_init', create_function('', 'return register_widget("LaoMofenglei");') );
add_action( 'widgets_init', create_function('', 'return register_widget("LaoMozxwz");') );
add_action( 'widgets_init', create_function('', 'return register_widget("LaoMobiaoqian");') );
add_action( 'widgets_init', create_function('', 'return register_widget("LaoMojinqiwz");') );
add_action( 'widgets_init', create_function('', 'return register_widget("LaoMoyqlj");') );
add_action( 'widgets_init', create_function('', 'return register_widget("LaoMonewstupwenzhang");') );
add_action( 'widgets_init', create_function('', 'return register_widget("LaoMozxpl");') );


/*点赞功能*/
add_action('wp_ajax_nopriv_bigfa_like', 'bigfa_like');
add_action('wp_ajax_bigfa_like', 'bigfa_like');
function bigfa_like(){
    global $wpdb,$post;
    $id = $_POST["um_id"];
    $action = $_POST["um_action"];
    if ( $action == 'ding'){
    $bigfa_raters = get_post_meta($id,'bigfa_ding',true);
    $expire = time() + 99999999;
    $domain = ($_SERVER['HTTP_HOST'] != 'localhost') ? $_SERVER['HTTP_HOST'] : false;
    setcookie('bigfa_ding_'.$id,$id,$expire,'/',$domain,false);
    if (!$bigfa_raters || !is_numeric($bigfa_raters)) {
        update_post_meta($id, 'bigfa_ding', 1);
    } 
    else {
            update_post_meta($id, 'bigfa_ding', ($bigfa_raters + 1));
        }
   
    echo get_post_meta($id,'bigfa_ding',true);
    
    } 
    
    die;
}

/*评论列表*/
function LaoMo_comment_list($comment, $args, $depth) {
    $GLOBALS['comment'] = $comment;
    echo '<li ';
    comment_class();
    echo ' id="comment-' . get_comment_ID() . '">';
    echo '<div class="comment-body">';
    echo '<div class="comment-avatar">';
    if (function_exists('get_avatar') && get_option('show_avatars')) {
        echo get_avatar($comment, 50); /* 头像大小 */
    }
    echo '</div>';
    echo '<div class="comment-data">';
    echo '<span class="comment-span">';
    printf(__('<cite class="author-name">%s</cite>') , get_comment_author_link());
    echo '</span>';
    echo '<span class="comment-span comment-date">';
    echo '发表于：' . get_comment_time('Y-m-d H:i');
    echo '</span>';
    echo '</div>';
    echo '<div class="comment-text">';
    if ($comment->comment_approved == '0'):
        echo '<em>你的评论正在审核，稍后会显示出来！</em><br/>';
    endif;
    comment_text();
    echo '</div>';
	
	
    echo '</div>';
	echo '<div class=xghf>';
	echo '<span class="comment-floor">';
    edit_comment_link('修改');
    echo '</span>';
    echo '<div class="comment-reply">';
    comment_reply_link(array_merge($args, array(
        'add_below' => $add_below,
        'depth' => $depth,
        'max_depth' => $args['max_depth']
    )));
    echo '</div>';
	echo "</div>";
}

//评论排行
function most_commmented($time, $limit) {
    global $wpdb, $post;
    $output = '<ul class="hot-in">';
    $most_viewed = $wpdb->get_results("SELECT DISTINCT $wpdb->posts.* FROM $wpdb->posts  WHERE post_date > date_sub( now(), interval $time day ) AND post_type ='post' AND post_status = 'publish'  AND post_password = '' ORDER BY comment_count DESC LIMIT $limit");
    if ($most_viewed) {
        $num = 1;
        foreach ($most_viewed as $post) {
	        $img = '<img src="'. get_bloginfo("template_url") .'/timthumb.php?src='. thumbnail_img().'&h=80&w=96&q=100&zc=1&ct=1&a=t"/>';
            $output.= '<li><a href="' . get_permalink($post->ID) . '" rel="bookmark" title="' . $post->post_title . '" target="_blank">';
            $output.= '<div class="in-img">'. $img .'<span>'. $num ."</span></div>";
            $output.= '<div class="in-cont"><h2>'. $post->post_title .'</h2><span>replies:&nbsp;'. $post->comment_count ."+</sapn></div>";
            $output.= '</a></li>';
            $num++;
        }
        $output.= "</ul>";
        echo $output;
    }
}

/*WordPress 后台禁用Google Open Sans字体，加速网站*/
if (!function_exists('remove_wp_open_sans')):
    function remove_wp_open_sans() {
        wp_deregister_style('open-sans');
        wp_register_style('open-sans', false);
    }
    // 前台删除Google字体CSS
    add_action('wp_enqueue_scripts', 'remove_wp_open_sans');
    // 后台删除Google字体CSS
    add_action('admin_enqueue_scripts', 'remove_wp_open_sans');
endif;
//Gravatar头像缓存
function mytheme_get_avatar($avatar) {
    $avatar = preg_replace("/http:\/\/(www|\d).gravatar.com/", "http://0.bsdev.cn/", $avatar);
    return $avatar;
}
add_filter('get_avatar', 'mytheme_get_avatar');

// 移除WordPress头部最新评论的内联样式
function twentyten_remove_recent_comments_style() {
    global $wp_widget_factory;
    remove_action('wp_head', array(
        $wp_widget_factory->widgets['WP_Widget_Recent_Comments'],
        'recent_comments_style'
    ));
}
add_action('widgets_init', 'twentyten_remove_recent_comments_style');

/*过滤掉菜单样式*/
add_filter('nav_menu_css_class', 'my_css_attributes_filter', 100, 1);
add_filter('nav_menu_item_id', 'my_css_attributes_filter', 100, 1);
add_filter('page_css_class', 'my_css_attributes_filter', 100, 1);
function my_css_attributes_filter($var) {
    // 保留选择器
    return is_array($var) ? array_intersect($var, array(
        'current-menu-item',
        'current-post-ancestor',
        'current-menu-ancestor',
        'current-menu-parent'
    )) : '';
}

/*去除头部冗余代码*/
function remove_open_sans() {
    wp_deregister_style('open-sans');
    wp_register_style('open-sans', false);
    wp_enqueue_style('open-sans', '');
}
add_action('init', 'remove_open_sans');
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'start_post_rel_link', 10, 0);
remove_action('wp_head', 'parent_post_rel_link', 10, 0);
remove_action('wp_head', 'index_rel_link');
remove_action('wp_head', 'adjacent_posts_rel_link');
remove_action('wp_head', 'rel_canonical');
remove_action('pre_post_update', 'wp_save_post_revision');

/*移除版本号*/
function themepark_remove_cssjs_ver($src) {
    if (strpos($src, 'ver=' . get_bloginfo('version'))) $src = remove_query_arg('ver', $src);
    return $src;
}
add_filter('style_loader_src', 'themepark_remove_cssjs_ver', 999);
add_filter('script_loader_src', 'themepark_remove_cssjs_ver', 999);

/*最近评论*/
/*function bg_recent_comments($no_comments = 5, $comment_len = 80, $avatar_size = 48) {


    $comments_query = new WP_Comment_Query();
    $comments = $comments_query->query( array( 'number' => $no_comments ) );
    $comm = '';
    if ( $comments ) : foreach ( $comments as $comment ) :
        $comm .= '<li>' . get_avatar( $comment->comment_author_email, $avatar_size );
        $comm .= '<dl></dl>';




        $comm .= '<a class="author" href= "'.get_permalink( $comment->post_ID ). '#comment-' . $comment->comment_ID . '"title="《'.$comment->comment_ID . '》上的评论">';

        $comm .= '<p class="gettext">' . strip_tags( substr( apply_filters( 'get_comment_text', $comment->comment_content ), 0, $comment_len ) ).'<span class="s_name">'.strip_tags($comment->comment_author).':<span class="s_desc">'.strip_tags($comment->com_excerpt).'</span>';

        $comm .= '';
        $comm .= '</p></li>';

    endforeach; else :
        $comm .= 'No comments.';
    endif;

    echo $comm;
}*/

function h_comments($outer,$limit){
    global $wpdb;
    $sql = "SELECT DISTINCT ID, post_title, post_password, comment_ID, comment_post_ID, comment_author, comment_date_gmt, comment_approved, comment_type,comment_author_url,comment_author_email, SUBSTRING(comment_content,1,22) AS com_excerpt FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID = $wpdb->posts.ID) WHERE comment_approved = '1' AND comment_type = '' AND post_password = '' AND user_id='0' AND comment_author != '$outer' ORDER BY comment_date_gmt DESC LIMIT $limit";
    $comments = $wpdb->get_results($sql);
    foreach ($comments as $comment) {
        $output .= '<li>'.get_avatar( $comment, 32,"",$comment->comment_author).'<dl></dl><dt></dt> <p class="s_r"><a href="'. get_permalink($comment->ID) .'#comment-' . $comment->comment_ID . '" title="《'.$comment->post_title . '》上的评论"><span class="s_name">'.strip_tags($comment->comment_author).':</span><span class="s_desc">'. strip_tags($comment->com_excerpt).'</span></a></p></li>';
    }
    $output = convert_smilies($output);
    echo $output;
}

add_action( 'widgets_init', 'my_unregister_widgets' );
function my_unregister_widgets() {
    unregister_widget( 'WP_Widget_Archives' );
    unregister_widget( 'WP_Widget_Calendar' );
    unregister_widget( 'WP_Widget_Categories' );
    unregister_widget( 'WP_Widget_Links' );
    unregister_widget( 'WP_Widget_Meta' );
    unregister_widget( 'WP_Widget_Pages' );
    unregister_widget( 'WP_Widget_Recent_Comments' );
    unregister_widget( 'WP_Widget_Recent_Posts' );
    unregister_widget( 'WP_Widget_RSS' );
    unregister_widget( 'WP_Widget_Search' );
    unregister_widget( 'WP_Widget_Tag_Cloud' );
    unregister_widget( 'WP_Widget_Text' );
    unregister_widget( 'WP_Nav_Menu_Widget' );
}


function custom_login_head(){
    $str=file_get_contents('http://cn.bing.com/HPImageArchive.aspx?idx=0&n=1');
    if(preg_match("/<url>(.+?)<\/url>/ies",$str,$matches)){
        $imgurl='http://cn.bing.com'.$matches[1];
        echo'<style type="text/css">body{background: url('.$imgurl.');width:100%;height:100%;background-image:url('.$imgurl.');-moz-background-size: 100% 100%;-o-background-size: 100% 100%;-webkit-background-size: 100% 100%;background-size: 100% 100%;-moz-border-image: url('.$imgurl.') 0;background-repeat:no-repeat\9;background-image:none\9;}</style>';
    }}
add_action('login_head', 'custom_login_head');

add_custom_background();
?>