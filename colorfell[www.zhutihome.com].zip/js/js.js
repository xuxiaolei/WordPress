/*缩略图效果*/
$(document).ready(function(){
            $('div#thumb').hover(function() {
                $(this).removeClass('.thumbpic');
                $("thumbpic").stop().animate({'width': '100%','':'','left':'0px'}, 400);
                $(this).find('img').stop().animate({'top': '0px','width':'100%'}, 400);
                $(this).find('p').stop().animate({});
                $(this).find('span').fadeIn(800).css({'background': '#4D61B3','color':'#fff','display':'block'});
                $(this).find('Abstract').fadeIn(300);
            },
        function(){
            $('.Thumbs').stop().animate({'width':'100%'},400);
            $(this).find('Abstract').hide();
            $(this).find('img').stop().animate({'top':'0px'},500);
            $(this).find('span').css({'background':'#4D61B3','color':'#fff'}).fadeOut(400);
        });
        });

