<div class="section-box">
	<h3 class="col-title"><?php echo zm_get_option('pany_contact_t'); ?></h3>
	<div class="pany-contact">
		<div class="pany-contact-main"><?php echo zm_get_option('pany_contact_w'); ?></div>
		<ul class="pany-contact-more">
			<li class="pany-more"><a href="<?php echo zm_get_option('pany_more_url'); ?>" rel="bookmark" target="_blank"><i class="fa fa-sticky-note-o"></i> 查看详细</a></li>
			<li class="contact-more"><a href="<?php echo  zm_get_option('pany_contact_url'); ?>" rel="bookmark" target="_blank"><i class="fa fa-phone"></i> 联系方式</a></li>
			<div class="clear"></div>
		</ul>
	</div>
	<div class="clear"></div>
</div>