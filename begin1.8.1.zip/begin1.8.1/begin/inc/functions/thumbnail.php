<?php
// 自动缩略图
//该解密由Xiao伟破解完成QQ：403641198 QQ群：11931589  
/*
*  在此顺便鄙视下2016年3月24日晚上认的QQ766533288 干儿子一下
*  别鸡巴买个插件，就说插件不能使用，插件和主题冲突，你怎么不说是你用的主题问题呢？
*  天天鸡巴没事给自己找爹搞的还以为不知道俺在哪鬼混射出来个怎么大个儿子。
*  你那么有本事，怎么不会去解决冲突问题吗？ 40块钱的东西看你鸡巴那样。
*  天天没事给自己找爹也不知道你亲爹怎么想的。
*  难道你亲爹告诉你叫你有事没事多给自己找几个爹吗？
*/
function zm_thumbnail() {
    global $post;
    if ( get_post_meta($post->ID, 'thumbnail', true) ) {
    	$image = get_post_meta($post->ID, 'thumbnail', true);
        echo '<a href="'.get_permalink().'"><img src=';
        echo $image;
        echo ' alt="'.$post->post_title .'" /></a>';
    } else {
	    if ( has_post_thumbnail() ) {
	        echo '<a href="'.get_permalink().'">';
	        the_post_thumbnail('content', array('alt' => get_the_title()));
	        echo '</a>';
		} else {
	        $content = $post->post_content;
	        preg_match_all('/<img.*?(?: |\\t|\\r|\\n)?src=[\'"]?(.+?)[\'"]?(?:(?: |\\t|\\r|\\n)+.*?)?>/sim', $content, $strResult, PREG_PATTERN_ORDER);
	        $n = count($strResult[1]);
	        if($n > 0){
				if (zm_get_option('timthumb')) {
					echo '<a href="'.get_permalink().'"><img src="'.get_template_directory_uri().'/timthumb.php?src='.$strResult[1][0].'&w='.zm_get_option('img_w').'&h='.zm_get_option('img_h').'&zc=1" alt="'.$post->post_title .'" /></a>';
				} else {
					echo '<a href="'.get_permalink().'"><img src="'.$strResult[1][0].'" alt="'.$post->post_title .'" /></a>';
				}
	        } else { 
				$random = mt_rand(1, 20);
				echo '<a href="'.get_permalink().'"><img src="'.get_template_directory_uri().'/img/random/'. $random .'.jpg" alt="'.$post->post_title .'" /></a>';
	        }
		}
	}
}

function zm_thumbnail_h() {
    global $post;
    if ( get_post_meta($post->ID, 'thumbnail', true) ) {
    	$image = get_post_meta($post->ID, 'thumbnail', true);
        echo '<a href="'.get_permalink().'"><img src="' . get_template_directory_uri() . '/img/loading.gif" data-echo=';
        echo $image;
        echo ' alt="'.$post->post_title .'" /></a>';
    } else {
	    if ( has_post_thumbnail() ) {
	        echo '<a href="'.get_permalink().'">';
	        the_post_thumbnail('content', array('alt' => get_the_title()));
	        echo '</a>';
		} else {
	        $content = $post->post_content;
	        preg_match_all('/<img.*?(?: |\\t|\\r|\\n)?src=[\'"]?(.+?)[\'"]?(?:(?: |\\t|\\r|\\n)+.*?)?>/sim', $content, $strResult, PREG_PATTERN_ORDER);
	        $n = count($strResult[1]);
	        if($n > 0){
				if (zm_get_option('timthumb')) {
					echo '<a href="'.get_permalink().'"><img src="' . get_template_directory_uri() . '/img/loading.gif" data-echo="'.get_template_directory_uri().'/timthumb.php?src='.$strResult[1][0].'&w='.zm_get_option('img_w').'&h='.zm_get_option('img_h').'&zc=1" alt="'.$post->post_title .'" /></a>';
				} else {
					echo '<a href="'.get_permalink().'"><img src="' . get_template_directory_uri() . '/img/loading.gif" data-echo="'.$strResult[1][0].'" alt="'.$post->post_title .'" /></a>';
	            }
	        } else { 
	        	$random = mt_rand(1, 20);
				echo '<a href="'.get_permalink().'"><img src="' . get_template_directory_uri() . '/img/loading.gif" data-echo="'.get_template_directory_uri().'/img/random/'. $random .'.jpg" alt="'.$post->post_title .'" /></a>';
	        }
		}
	}
}

function video_thumbnail() {
    global $post;
    $img = get_post_meta($post->ID, 'big', true);
    if ( get_post_meta($post->ID, 'small', true) ) {
    	$image = get_post_meta($post->ID, 'small', true);
        echo '<a class="videos" href="'.$img.'"><img src=';
        echo $image;
        echo ' alt="'.$post->post_title .'" /><i class="fa fa-play-circle-o"></i></a>';
    } else {
	    if ( has_post_thumbnail() ) {
	        echo '<a class="videos" href="'.$img.'">';
	        the_post_thumbnail('content', array('alt' => get_the_title()));
	        echo '<i class="fa fa-play-circle-o"></i></a>';
		}
	}
}

function videos_thumbnail() {
    global $post;
    if ( get_post_meta($post->ID, 'small', true) ) {
    	$image = get_post_meta($post->ID, 'small', true);
        echo '<a class="videos" href="'.get_permalink().'"><img src=';
        echo $image;
        echo ' alt="'.$post->post_title .'" /><i class="fa fa-play-circle-o"></i></a>';
    } else {
	    if ( has_post_thumbnail() ) {
	        echo '<a class="videos" href="'.get_permalink().'">';
	        the_post_thumbnail('content', array('alt' => get_the_title()));
	        echo '<i class="fa fa-play-circle-o"></i></a>';
		}
	}
}

function videos_thumbnail_h() {
    global $post;
    if ( get_post_meta($post->ID, 'small', true) ) {
    	$image = get_post_meta($post->ID, 'small', true);
        echo '<a class="videos" href="'.get_permalink().'"><img src="' . get_template_directory_uri() . '/img/loading.gif" data-echo=';
        echo $image;
        echo ' alt="'.$post->post_title .'" /><i class="fa fa-play-circle-o"></i></a>';
    } else {
	    if ( has_post_thumbnail() ) {
	        echo '<a class="videos" href="'.get_permalink().'">';
	        the_post_thumbnail('content', array('alt' => get_the_title()));
	        echo '<i class="icon-btnPlay"></i></a>';
		}
	}
}

function videor_thumbnail_h() {
    global $post;
    if ( get_post_meta($post->ID, 'small', true) ) {
    	$image = get_post_meta($post->ID, 'small', true);
        echo '<a class="videor" href="'.get_permalink().'"><img src="' . get_template_directory_uri() . '/img/loading.gif" data-echo=';
        echo $image;
        echo ' alt="'.$post->post_title .'" /><i class="fa fa-play-circle-o"></i></a>';
    } else {
	    if ( has_post_thumbnail() ) {
	        echo '<a class="videor" href="'.get_permalink().'">';
	        the_post_thumbnail('content', array('alt' => get_the_title()));
	        echo '<i class="icon-btnPlay"></i></a>';
		}
	}
}

function videor_thumbnail() {
    global $post;
    if ( get_post_meta($post->ID, 'small', true) ) {
    	$image = get_post_meta($post->ID, 'small', true);
        echo '<a class="videor" href="'.get_permalink().'"><img src=';
        echo $image;
        echo ' alt="'.$post->post_title .'" /><i class="fa fa-play-circle-o"></i></a>';
    } else {
	    if ( has_post_thumbnail() ) {
	        echo '<a class="videor" href="'.get_permalink().'">';
	        the_post_thumbnail('content', array('alt' => get_the_title()));
	        echo '<i class="icon-btnPlay"></i></a>';
		}
	}
}

function tao_thumbnail() {
		global $post;
		$url = get_post_meta($post->ID, 'taourl', true);
		if ( get_post_meta($post->ID, 'thumbnail', true) ) {
		$image = get_post_meta($post->ID, 'thumbnail', true);
		echo '<a href="'.esc_url( get_permalink() ).'"><img src=';
		echo $image;
		echo ' /></a>';
    } else {
	    $content = $post->post_content;
	    preg_match_all('/<img.*?(?: |\\t|\\r|\\n)?src=[\'"]?(.+?)[\'"]?(?:(?: |\\t|\\r|\\n)+.*?)?>/sim', $content, $strResult, PREG_PATTERN_ORDER);
	    $n = count($strResult[1]);
	    if($n > 0){
	        echo '<a href="'.esc_url( get_permalink() ).'"><img src="'.$strResult[1][0].'" alt="'.$post->post_title .'" /></a>';
	    }
	}
}

function tao_thumbnail_h() {
		global $post;
		$url = get_post_meta($post->ID, 'taourl', true);
		if ( get_post_meta($post->ID, 'thumbnail', true) ) {
		$image = get_post_meta($post->ID, 'thumbnail', true);
		echo '<a href="'.esc_url( get_permalink() ).'"><img src="' . get_template_directory_uri() . '/img/loading.gif" data-echo=';
		echo $image;
		echo ' /></a>';
    } else {
	    $content = $post->post_content;
	    preg_match_all('/<img.*?(?: |\\t|\\r|\\n)?src=[\'"]?(.+?)[\'"]?(?:(?: |\\t|\\r|\\n)+.*?)?>/sim', $content, $strResult, PREG_PATTERN_ORDER);
	    $n = count($strResult[1]);
	    if($n > 0){
	        echo '<a href="'.esc_url( get_permalink() ).'"><img src="' . get_template_directory_uri() . '/img/loading.gif" data-echo="'.$strResult[1][0].'" alt="'.$post->post_title .'" /></a>';
	    }
	}
}

// 所有图片
function all_img($soContent){
	$soImages = '~<img [^\>]*\ />~';
	preg_match_all( $soImages, $soContent, $thePics );
	$allPics = count($thePics);
	if( $allPics > 0 ){ 
		$count=0;
			foreach($thePics[0] as $v){
				 if( $count == 4 ){break;}
				 else { echo '<ul><div class="f4"><li class="format-img">',$v,'<div class="clear"></div></li></div></ul>'; }
				$count++;
			}
	}
}