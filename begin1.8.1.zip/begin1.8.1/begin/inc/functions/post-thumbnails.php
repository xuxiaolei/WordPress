<?php
add_theme_support( 'post-thumbnails' );
add_image_size( 'thumbnail', 200, 150, true );
?>