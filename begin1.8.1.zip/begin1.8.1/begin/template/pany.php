<?php get_header(); ?>
<style type="text/css">
#content {
    width: 100%;
	background: #fff;
    margin: 0 auto;
}
#primary {
	width: 100%;
	box-shadow: none;
}
#primary .page {
	background: transparent !important;
	padding: 0 !important;
	border: none !important;
	box-shadow: none !important;
}
.breadcrumb {
	display: none;
}
#slideshow {
/** width: 1080px; **/
	margin: 1px auto 0;
}
@media screen and (max-width: 900px) {
	.rslides_tabs {display: none;}
}
#menu-box {
 	transition-duration: .0s;
}
/** ���� **/
.nbs-flexisel-container {
    padding: 0;
	border: none;
	border-radius: 0;
	box-shadow: none;
}
/** ���� **/
#links {
	width: 1080px;
	margin: 0 auto;
	padding: 20px 0;
}
.link-f a {
	background: #fff;
	text-align: center;
	padding: 5px;
	display: block;
	white-space: nowrap;
	word-wrap: normal;
	text-overflow: ellipsis;
	overflow: hidden;
	border: 1px solid #fff;
	border-radius: 0;
	transition-duration: .5s;
	box-shadow: none;
}
@media screen and (max-width: 1080px) {
	#links {
		width: 100%;
	}
}
.ad-site {
	display: none;
}
</style>
<script type="text/javascript">
$(document).ready(function(a) {
    if (typeof scrollMonitor != 'undefined') {
        a(".pany-contact, .section-box, .section .xl2, .nbs-flexisel-container").each(function(i, el) {
            var ael = a(el),
            watcher = scrollMonitor.create(el, -100);
            ael.addClass('pany-hide');
            watcher.enterViewport(function(ev) {
                if (!ael.hasClass('pany-show')) {
                    ael.addClass('pany-show');
                }
            });
        });
    }
})
</script>
<div class="container">
	<?php if (zm_get_option('slider')) { ?>
	<div class="row">
		<div class="col-0">
			<div class="home-slider">
				<?php get_template_part( '/pany/home-slider' ); ?>
			</div>
		</div>
	</div>
	<?php } ?>

	<?php if (zm_get_option('pany_contact')) { ?>
	<div class="row">
		<div class="col-4">
			<div class="section">
				<?php get_template_part( '/pany/contact' ); ?>
				<div class="clear"></div>
			</div>
		</div>
	</div>
	<?php } ?>

	<?php if (zm_get_option('cat_a')) { ?>
	<div class="row">
		<div class="col-1">
			<div class="section">
				<?php get_template_part( '/pany/cat' ); ?>
				<div class="clear"></div>
			</div>
		</div>
	</div>
	<?php } ?>

	<?php if (zm_get_option('pany_custom')) { ?>
	<div class="row">
		<div class="col-2">
			<div class="section">
				<?php get_template_part( '/pany/custom' ); ?>
				<div class="clear"></div>
			</div>
		</div>
	</div>
	<?php } ?>

	<?php if (zm_get_option('pany_two_a')) { ?>
	<div class="row">
		<div class="col-1">
			<div class="section">
				<h3 class="col-title"><?php echo zm_get_option('pany_two_a_w'); ?></h3>
				<?php dynamic_sidebar( 'pany-two-a' ); ?>
				<div class="clear"></div>
			</div>
		</div>
	</div>
	<?php } ?>

	<?php if (zm_get_option('pany_two_b')) { ?>
	<div class="row">
		<div class="col-2">
			<div class="section">
				<h3 class="col-title"><?php echo zm_get_option('pany_two_b_w'); ?></h3>
				<?php dynamic_sidebar( 'pany-two-b' ); ?>
				<div class="clear"></div>
			</div>
		</div>
	</div>
	<?php } ?>

	<?php if (zm_get_option('pany_scrolling')) { ?>
	<div class="row">
		<div class="col-3">
			<div class="section">
				<?php get_template_part( '/pany/scrolling' ); ?>
			</div>
		</div>
	</div>
	<?php } ?>

	<?php if (zm_get_option('pany_two_c')) { ?>
	<div class="row">
		<div class="col-2">
			<div class="section">
				<h3 class="col-title"><?php echo zm_get_option('pany_two_c_w'); ?></h3>
				<?php dynamic_sidebar( 'pany-two-c' ); ?>
				<div class="clear"></div>
			</div>
		</div>
	</div>
	<?php } ?>

</div><!--  container end -->

<?php get_footer(); ?>